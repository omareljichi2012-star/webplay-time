(function () {
  'use strict';
  var SUPPORTED_LANGS = ['ru', 'en', 'uk'];
  var FALLBACK_LANG = 'en';
  var LS_KEY = 'push_subs';
  var STRINGS = {
    'btn.subscribe': {
      en: 'Subscribe to updates',
      ru: 'Подписаться на обновления',
      uk: 'Підписатись на оновлення',
    },
    'btn.subscribed': {
      en: 'Subscribed',
      ru: 'Вы подписаны',
      uk: 'Ви підписані',
    },
    'btn.subscribe.title': {
      en: 'Get push notifications about new chapters',
      ru: 'Получать push-уведомления о новых главах',
      uk: 'Отримувати push-сповіщення про нові глави',
    },
    'btn.unsubscribe.title': {
      en: 'Click to unsubscribe',
      ru: 'Нажмите для отписки',
      uk: 'Натисніть щоб відписатись',
    },
    'btn.error': {
      en: 'Error',
      ru: 'Ошибка',
      uk: 'Помилка',
    },
    'btn.loading': {
      en: 'Loading...',
      ru: 'Загрузка...',
      uk: 'Завантаження...',
    },
    'error.permission_denied': {
      en: 'Notifications blocked by browser',
      ru: 'Уведомления заблокированы браузером',
      uk: 'Сповіщення заблоковані браузером',
    },
    'error.not_supported': {
      en: 'Notifications not supported',
      ru: 'Уведомления не поддерживаются',
      uk: 'Сповіщення не підтримуються',
    },
  };
  function detectLang() {
    var raw = (document.documentElement.lang || '').toLowerCase().trim();
    var code = raw.substring(0, 2);
    return SUPPORTED_LANGS.indexOf(code) !== -1 ? code : FALLBACK_LANG;
  }
  function t(key) {
    var entry = STRINGS[key];
    if (!entry) return key;
    return entry[currentLang] || entry[FALLBACK_LANG] || key;
  }
  function cacheGet() {
    try {
      var raw = localStorage.getItem(LS_KEY);
      if (!raw) return [];
      var obj = JSON.parse(raw);
      if (obj.site !== SITE_ID) return [];
      return obj.ids || [];
    } catch (e) {
      return [];
    }
  }
  function cacheSet(ids) {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify({
        site: SITE_ID,
        ts: Date.now(),
        ids: ids,
      }));
    } catch (e) {}
  }
  var currentLang = detectLang();
  var CONFIG = window.PUSH_CONFIG;
  if (!CONFIG || !CONFIG.siteId || !CONFIG.sig || !CONFIG.apiBase) {
    return;
  }
  var API = CONFIG.apiBase;
  var SITE_ID = CONFIG.siteId;
  var SIG = CONFIG.sig;
  var ESIG_KEY = 'push_esig_' + SITE_ID;
  function esigGet() {
    try { return localStorage.getItem(ESIG_KEY) || ''; } catch (e) { return ''; }
  }
  function esigSet(sig) {
    try { localStorage.setItem(ESIG_KEY, sig); } catch (e) {}
  }
  var vapidPublicKey = null;
  var swRegistration = null;
  var pushSubscription = null;
  var localSubs = cacheGet();
  function updateAllButtons() {
    var buttons = document.querySelectorAll('.push-subscribe-btn');
    for (var i = 0; i < buttons.length; i++) {
      updateButton(buttons[i]);
    }
  }
  function updateButton(btn) {
    var postId = parseInt(btn.getAttribute('data-post-id'), 10);
    if (!postId) return;
    var isSubscribed = localSubs.indexOf(postId) !== -1;
    if (isSubscribed) {
      btn.classList.add('push-subscribed');
      btn.classList.remove('push-not-subscribed');
      btn.innerHTML = '<span class="push-icon">\uD83D\uDD14</span> ' + t('btn.subscribed');
      btn.title = t('btn.unsubscribe.title');
    } else {
      btn.classList.remove('push-subscribed');
      btn.classList.add('push-not-subscribed');
      btn.innerHTML = '<span class="push-icon">\uD83D\uDD15</span> ' + t('btn.subscribe');
      btn.title = t('btn.subscribe.title');
    }
  }
  function ensureReady() {
    if (swRegistration && pushSubscription) {
      return Promise.resolve();
    }
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      return Promise.reject(new Error(t('error.not_supported')));
    }
    // Загрузить vapidKey с сервера (один раз, только по клику)
    var keyPromise = vapidPublicKey
      ? Promise.resolve()
      : fetch(API + '/vapid-key')
          .then(function (resp) {
            if (!resp.ok) throw new Error('Push service unavailable (HTTP ' + resp.status + ')');
            return resp.json();
          })
          .then(function (data) {
            if (!data || !data.publicKey) throw new Error('Push service unavailable');
            vapidPublicKey = data.publicKey;
          });
    return keyPromise
      .then(function () {
        // swUrl: a site whose main worker also carries push registers that same URL, one worker per scope.
        return navigator.serviceWorker.register(CONFIG.swUrl || '/sw-push.js', { scope: '/' });
      })
      .then(function (reg) {
        swRegistration = reg;
        return navigator.serviceWorker.ready;
      })
      .then(function () {
        return swRegistration.pushManager.getSubscription();
      })
      .then(function (sub) {
        if (sub) {
          pushSubscription = sub;
          return;
        }
        return Notification.requestPermission().then(function (perm) {
          if (perm !== 'granted') {
            throw new Error(t('error.permission_denied'));
          }
          return swRegistration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
          });
        }).then(function (newSub) {
          pushSubscription = newSub;
        });
      });
  }
  // extra — доп. поля запроса (topic_sig для персонального топика новинок, batcave Sandev/Notify)
  function subscribeToSerial(postId, extra) {
    return ensureReady().then(function () {
      var subJSON = pushSubscription.toJSON();
      return fetch(API + '/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({}, extra || {}, {
          site_id: SITE_ID,
          post_id: postId,
          sig: SIG,
          lang: currentLang,
          subscription: {
            endpoint: subJSON.endpoint,
            keys: {
              p256dh: subJSON.keys.p256dh,
              auth: subJSON.keys.auth,
            },
          },
        })),
      });
    }).then(function (resp) {
      if (!resp.ok) {
        return resp.json().then(function (err) {
          throw new Error(err.error || 'HTTP ' + resp.status);
        });
      }
      return resp.json();
    }).then(function (data) {
      if (localSubs.indexOf(postId) === -1) {
        localSubs.push(postId);
      }
      cacheSet(localSubs);
      // Сохраняем персональный endpoint_sig для безопасного unsubscribe
      if (data && data.endpoint_sig) {
        esigSet(data.endpoint_sig);
      }
      return data;
    });
  }
  function unsubscribeFromSerial(postId) {
    return ensureReady().then(function () {
      var endpointSig = esigGet();
      var authPayload = endpointSig
        ? { endpoint_sig: endpointSig }
        : { sig: SIG };
      return fetch(API + '/unsubscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({
          site_id: SITE_ID,
          post_id: postId,
          endpoint: pushSubscription.endpoint,
        }, authPayload)),
      });
    }).then(function (resp) {
      if (!resp.ok) {
        return resp.json().then(function (err) {
          throw new Error(err.error || 'HTTP ' + resp.status);
        });
      }
      return resp.json();
    }).then(function (data) {
      localSubs = localSubs.filter(function (id) {
        return id !== postId;
      });
      cacheSet(localSubs);
      return data;
    });
  }
  function handleButtonClick(e) {
    var btn = e.target;
    while (btn && !btn.classList.contains('push-subscribe-btn')) {
      btn = btn.parentElement;
    }
    if (!btn) return;
    var postId = parseInt(btn.getAttribute('data-post-id'), 10);
    if (!postId) return;
    btn.disabled = true;
    btn.classList.add('push-loading');
    btn.innerHTML = '<span class="push-icon">\u23F3</span> ' + t('btn.loading');
    var isSubscribed = localSubs.indexOf(postId) !== -1;
    var promise = isSubscribed
      ? unsubscribeFromSerial(postId)
      : subscribeToSerial(postId);
    promise
      .then(function () {
        updateButton(btn);
      })
      .catch(function (err) {
        console.error('[Push] Action failed:', err);
        btn.innerHTML = '\u274C ' + t('btn.error');
        setTimeout(function () {
          updateButton(btn);
        }, 2000);
      })
      .finally(function () {
        btn.disabled = false;
        btn.classList.remove('push-loading');
      });
  }
  function urlBase64ToUint8Array(base64String) {
    var padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    var base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    var rawData = window.atob(base64);
    var outputArray = new Uint8Array(rawData.length);
    for (var i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }
  document.addEventListener('click', handleButtonClick);
  window.PushManager2 = {
    subscribe: subscribeToSerial,
    unsubscribe: unsubscribeFromSerial,
    isSubscribed: function (postId) {
      return localSubs.indexOf(postId) !== -1;
    },
    getSubscriptions: function () {
      return localSubs.slice();
    },
    getLang: function () {
      return currentLang;
    },
    t: t,
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', updateAllButtons);
  } else {
    updateAllButtons();
  }
})();
