/* echat voice messages: recording (hold + lock + swipe-cancel) and peak player */
(function () {
	'use strict';

	var MIN_DURATION_MS = 300;
	var MAX_DURATION_MS = 120 * 1000;
	var MAX_BYTES       = 1024 * 1024;
	var PEAKS_COUNT     = 32;
	var CANCEL_DX       = 80;
	var LOCK_DY         = 60;
	var RATES           = [1, 1.5, 2];

	var state = {
		recording: false,
		locked:    false,
		canceled:  false,
		mediaRecorder: null,
		chunks: [],
		stream: null,
		startTime: 0,
		timerId: 0,
		pointerStart: { x: 0, y: 0 },
		pointerReleased: false,
		mimeType: '',
		ext: 'webm'
	};

	var currentAudio = null;
	var currentVoice = null;

	function $(sel, root) { return (root || document).querySelector(sel); }
	function $$(sel, root) { return (root || document).querySelectorAll(sel); }

	function getRoom() {
		var active = $('.echat__room.active');
		return (active && active.getAttribute('data-room')) || 'main';
	}

	function pickMimeType() {
		if (typeof MediaRecorder === 'undefined') return null;
		var prefs = [
			['audio/webm;codecs=opus', 'webm'],
			['audio/webm',             'webm'],
			['audio/ogg;codecs=opus',  'ogg'],
			['audio/mp4',              'm4a']
		];
		for (var i = 0; i < prefs.length; i++) {
			if (MediaRecorder.isTypeSupported(prefs[i][0])) {
				return { mime: prefs[i][0], ext: prefs[i][1] };
			}
		}
		return null;
	}

	function fmtTime(ms) {
		var s = Math.max(0, Math.floor(ms / 1000));
		var m = Math.floor(s / 60);
		return m + ':' + (s % 60 < 10 ? '0' : '') + (s % 60);
	}

	function showToast(msg) {
		if (typeof DLEalert === 'function') {
			DLEalert(msg, typeof dle_info !== 'undefined' ? dle_info : 'Error');
		} else {
			window.alert(msg);
		}
	}

	/* ---------- recording ---------- */

	function showRecBar() {
		var bar = $('.echat__rec');
		if (bar) bar.style.display = 'flex';
		var mic = $('.echat__btn-mic');
		if (mic) mic.classList.add('recording');
	}

	function hideRecBar() {
		var bar = $('.echat__rec');
		if (bar) {
			bar.style.display = 'none';
			bar.classList.remove('locked');
		}
		var mic = $('.echat__btn-mic');
		if (mic) mic.classList.remove('recording');
		var stop = $('.echat__rec-stop');
		if (stop) stop.style.display = 'none';
	}

	function tickTimer() {
		var el = $('.echat__rec-timer');
		var ms = Date.now() - state.startTime;
		if (el) el.textContent = fmtTime(ms);
		if (ms >= MAX_DURATION_MS) {
			finishRecording(false);
		}
	}

	async function startRecording(ev) {
		if (state.recording) return;

		var picked = pickMimeType();
		if (!picked) {
			showToast('Voice recording is not supported by this browser');
			return;
		}
		if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
			showToast('Microphone is unavailable');
			return;
		}

		try {
			state.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
		} catch (err) {
			showToast('Microphone permission was denied');
			return;
		}

		state.mimeType = picked.mime;
		state.ext      = picked.ext;
		state.chunks   = [];
		state.canceled = false;
		state.locked   = false;
		state.recording = true;
		state.startTime = Date.now();
		state.pointerStart.x = ev.clientX || 0;
		state.pointerStart.y = ev.clientY || 0;

		try {
			state.mediaRecorder = new MediaRecorder(state.stream, {
				mimeType: state.mimeType,
				audioBitsPerSecond: 24000
			});
		} catch (e) {
			state.mediaRecorder = new MediaRecorder(state.stream, { mimeType: state.mimeType });
		}

		state.mediaRecorder.ondataavailable = function (e) {
			if (e.data && e.data.size > 0) state.chunks.push(e.data);
		};
		state.mediaRecorder.onstop = onRecorderStop;

		state.mediaRecorder.start();
		showRecBar();
		state.timerId = setInterval(tickTimer, 100);

		if (state.pointerReleased && !state.locked) {
			lockRecording();
		}
	}

	function finishRecording(cancel) {
		if (!state.recording) return;
		state.canceled = !!cancel;
		clearInterval(state.timerId);

		try { state.mediaRecorder.stop(); } catch (e) {}
	}

	function onRecorderStop() {
		state.recording = false;

		if (state.stream) {
			state.stream.getTracks().forEach(function (t) { t.stop(); });
			state.stream = null;
		}

		var duration = Date.now() - state.startTime;
		hideRecBar();

		if (state.canceled) {
			state.chunks = [];
			return;
		}

		if (duration < MIN_DURATION_MS) {
			showToast('Message is too short');
			state.chunks = [];
			return;
		}

		var blob = new Blob(state.chunks, { type: state.mimeType });
		state.chunks = [];

		if (blob.size > MAX_BYTES) {
			showToast('File is too large');
			return;
		}

		computePeaks(blob).then(function (peaks) {
			uploadVoice(blob, duration, peaks);
		});
	}

	/* ---------- peaks ---------- */

	function computePeaks(blob) {
		var Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx) return Promise.resolve(zeroPeaks());

		return blob.arrayBuffer().then(function (buf) {
			var ctx = new Ctx();
			return ctx.decodeAudioData(buf.slice(0)).then(function (audio) {
				var data = audio.getChannelData(0);
				var blockSize = Math.floor(data.length / PEAKS_COUNT) || 1;
				var peaks = [];
				var max = 0;
				for (var i = 0; i < PEAKS_COUNT; i++) {
					var sum = 0;
					var start = i * blockSize;
					var end = Math.min(start + blockSize, data.length);
					for (var j = start; j < end; j++) sum += data[j] * data[j];
					var rms = Math.sqrt(sum / Math.max(1, end - start));
					peaks.push(rms);
					if (rms > max) max = rms;
				}
				ctx.close && ctx.close();
				if (max <= 0) return zeroPeaks();
				return peaks.map(function (p) {
					return Math.max(8, Math.min(100, Math.round((p / max) * 100)));
				});
			}).catch(function () {
				ctx.close && ctx.close();
				return zeroPeaks();
			});
		}).catch(function () { return zeroPeaks(); });
	}

	function zeroPeaks() {
		var arr = []; for (var i = 0; i < PEAKS_COUNT; i++) arr.push(20);
		return arr;
	}

	/* ---------- upload ---------- */

	function uploadVoice(blob, durationMs, peaks) {
		var fd = new FormData();
		fd.append('file', blob, 'voice.' + state.ext);
		fd.append('duration_ms', String(Math.round(durationMs)));
		fd.append('peaks', JSON.stringify(peaks));
		fd.append('room', getRoom());
		if (typeof dle_login_hash !== 'undefined') fd.append('user_hash', dle_login_hash);
		if (typeof dle_skin       !== 'undefined') fd.append('skin',      dle_skin);

		var url = (typeof dle_root !== 'undefined' ? dle_root : '/') + 'engine/mods/echat/ajax_voice.php';

		fetch(url, { method: 'POST', body: fd, credentials: 'same-origin' })
			.then(function (r) { return r.json().catch(function () { return { error: 'Response error' }; }); })
			.then(function (data) {
				if (!data || data.error) {
					showToast((data && data.error) || 'Send error');
					return;
				}
				if (window.echat && typeof window.echat.startUpdate === 'function') {
					window.echat.startUpdate();
				}
			})
			.catch(function () { showToast('Network error'); });
	}

	/* ---------- pointer events ---------- */

	function lockRecording() {
		state.locked = true;
		var bar = $('.echat__rec'); if (bar) bar.classList.add('locked');
	}

	function onMicPointerDown(ev) {
		if (ev.button !== undefined && ev.button !== 0) return;
		ev.preventDefault();
		state.pointerReleased = false;
		startRecording(ev);

		document.addEventListener('pointermove', onPointerMove, true);
		document.addEventListener('pointerup',   onPointerUp,   true);
		document.addEventListener('pointercancel', onPointerCancel, true);
	}

	function onPointerMove(ev) {
		if (!state.recording || state.locked) return;
		var dx = state.pointerStart.x - (ev.clientX || 0);
		var dy = state.pointerStart.y - (ev.clientY || 0);

		if (dx > CANCEL_DX) {
			finishRecording(true);
			detachPointer();
			return;
		}
		if (dy > LOCK_DY) {
			lockRecording();
			detachPointer();
		}
	}

	function onPointerUp() {
		state.pointerReleased = true;
		if (state.locked) { detachPointer(); return; }
		if (state.recording) {
			if (Date.now() - state.startTime < MIN_DURATION_MS) {
				lockRecording();
			} else {
				finishRecording(false);
			}
		}
		detachPointer();
	}

	function onPointerCancel() {
		if (state.recording && !state.locked) finishRecording(true);
		detachPointer();
	}

	function detachPointer() {
		document.removeEventListener('pointermove', onPointerMove, true);
		document.removeEventListener('pointerup',   onPointerUp,   true);
		document.removeEventListener('pointercancel', onPointerCancel, true);
	}

	/* ---------- player ---------- */

	function ensureAudio() {
		if (!currentAudio) {
			currentAudio = new Audio();
			currentAudio.preload = 'metadata';
			currentAudio.addEventListener('timeupdate', onAudioProgress);
			currentAudio.addEventListener('ended', onAudioEnded);
			currentAudio.addEventListener('pause', onAudioEnded);
		}
		return currentAudio;
	}

	function onAudioProgress() {
		if (!currentVoice || !currentAudio.duration) return;
		var pct = currentAudio.currentTime / currentAudio.duration;
		var bars = currentVoice.querySelectorAll('.ec-voice__wave i');
		var threshold = Math.floor(pct * bars.length);
		bars.forEach(function (bar, idx) {
			bar.classList.toggle('played', idx < threshold);
		});
		var totalSec = Math.floor(currentAudio.duration);
		var curSec   = Math.floor(currentAudio.currentTime);
		var time = currentVoice.querySelector('.ec-voice__time');
		if (time) {
			time.textContent =
				Math.floor(curSec/60) + ':' + (curSec%60<10?'0':'') + (curSec%60) +
				' / ' +
				Math.floor(totalSec/60) + ':' + (totalSec%60<10?'0':'') + (totalSec%60);
		}
	}

	function onAudioEnded() {
		if (!currentVoice) return;
		var play = currentVoice.querySelector('.ec-voice__play');
		if (play) play.classList.remove('playing');
		if (currentAudio.ended) {
			var bars = currentVoice.querySelectorAll('.ec-voice__wave i');
			bars.forEach(function (b) { b.classList.remove('played'); });
		}
	}

	function togglePlay(voiceEl) {
		var url = voiceEl.getAttribute('data-url');
		if (!url) return;
		var audio = ensureAudio();

		if (currentVoice && currentVoice !== voiceEl) {
			audio.pause();
			currentVoice.querySelector('.ec-voice__play').classList.remove('playing');
		}

		if (audio.src !== url && !audio.src.endsWith(url)) {
			audio.src = url;
			audio.load();
		}
		currentVoice = voiceEl;

		if (audio.paused) {
			audio.play().then(function () {
				voiceEl.querySelector('.ec-voice__play').classList.add('playing');
			}).catch(function () { showToast('Playback failed'); });
		} else {
			audio.pause();
			voiceEl.querySelector('.ec-voice__play').classList.remove('playing');
		}
	}

	function seekTo(voiceEl, ev) {
		var audio = ensureAudio();
		if (currentVoice !== voiceEl || !audio.duration) return;
		var rect = ev.currentTarget.getBoundingClientRect();
		var pct = Math.max(0, Math.min(1, (ev.clientX - rect.left) / rect.width));
		audio.currentTime = pct * audio.duration;
	}

	function cycleRate(btn) {
		var cur = parseFloat(btn.getAttribute('data-rate') || '1');
		var idx = RATES.indexOf(cur);
		var next = RATES[(idx + 1) % RATES.length];
		btn.setAttribute('data-rate', String(next));
		btn.textContent = next + '×';
		var audio = ensureAudio();
		audio.playbackRate = next;
	}

	/* ---------- bind ---------- */

	function bind() {
		var mic = $('.echat__btn-mic');
		if (mic) {
			mic.addEventListener('pointerdown', onMicPointerDown);
			mic.addEventListener('contextmenu', function (e) { e.preventDefault(); });
		}

		var cancel = $('.echat__rec-cancel');
		if (cancel) cancel.addEventListener('click', function () {
			if (state.recording) finishRecording(true);
		});

		var stop = $('.echat__rec-stop');
		if (stop) stop.addEventListener('click', function () {
			if (state.recording) finishRecording(false);
		});

		var lock = $('.echat__rec-lock');
		if (lock) lock.addEventListener('click', function () {
			if (state.recording && !state.locked) {
				state.locked = true;
				var bar = $('.echat__rec'); if (bar) bar.classList.add('locked');
			}
		});

		document.addEventListener('click', function (ev) {
			var play = ev.target.closest && ev.target.closest('.ec-voice__play');
			if (play) {
				var v = play.closest('.ec-voice');
				if (v) togglePlay(v);
				return;
			}
			var rate = ev.target.closest && ev.target.closest('.ec-voice__rate');
			if (rate) {
				cycleRate(rate);
				return;
			}
		});

		document.addEventListener('click', function (ev) {
			var wave = ev.target.closest && ev.target.closest('.ec-voice__wave');
			if (wave) {
				var v = wave.closest('.ec-voice');
				if (v) seekTo(v, ev);
			}
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', bind);
	} else {
		bind();
	}
})();
