/* Чёткая обложка поверх страницы (<dialog>); без JS ссылка просто открывает картинку */
document.addEventListener('click', function (e) {
	var a = e.target.closest('.page__poster > a');
	if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey || typeof HTMLDialogElement !== 'function') return;
	e.preventDefault();
	var d = document.createElement('dialog'), img = new Image();
	d.className = 'poster-zoom';
	img.src = a.href;
	img.alt = a.querySelector('img').alt;
	d.appendChild(img);
	d.addEventListener('click', function () { d.close(); });
	d.addEventListener('close', function () { d.remove(); });
	document.body.appendChild(d);
	d.showModal();
});

const cl_app = Vue.createApp({
	data() {
		return Object.assign({
			page: 1,
			reverse: false,
			selected: [],
			currentAction: '',
			readed: {},
			favch: {},
			favch_busy: {},
			edit_id: 0,
			xhash: '',
			thumbs: [],
			// Вид списка выпусков (suggestion #224): 'list' или 'covers', помнится в браузере
			view: (function () { try { return localStorage.getItem('cl_view') === 'covers' ? 'covers' : 'list'; } catch (e) { return 'list'; } })(),
		}, window.__DATA__);
	},
	beforeMount() {
		$(document).on('dragover dragenter', '.cl__editUpload', function() {
			$(this).addClass('highlight');
		}).on('dragleave drop', '.cl__editUpload', function() {
			$(this).removeClass('highlight');
		})
	},
	computed: {
		thumbSet() {
			const s = {};
			for (const id of (this.thumbs || [])) s[id] = true;
			return s;
		},
		chaptersList() {
			let chapters = JSON.parse(JSON.stringify(this.chapters));
			if (this.reverse === true) chapters = chapters.reverse();
			chapters = chapters.slice((this.page - 1) * this.limit, this.page * this.limit);
			return chapters;
		},
		readProgress() {
			if (!this.readed || !this.chapters.length) return 0;
			let readed = [];
			for (let i in this.readed) {
				if (this.readed[i]) readed.push(i);
			}
			return Math.floor(readed.length / this.chapters.length * 100);
		},
	},
	methods: {
		sendAjax(action, data, callback, failed) {
			data.news_id = this.news_id;
			sendAjax(action, data, callback, failed);
		},
		getTitle(...title) {
			title = title.filter(word => word.length);
			return title.join(' / ');
		},
		getSafeTitle(...title) {
			title = title.filter(word => word.length);
			return encodeURIComponent(title.join('_'));
		},
		getLink(chapter) {
			return '/reader/' + this.news_id + '/' + chapter.id + this.xhash;
		},
		isReaded(id) {
			return this.readed[id];
		},
		setView(v) {
			this.view = v === 'covers' ? 'covers' : 'list';
			try { localStorage.setItem('cl_view', this.view); } catch (e) {}
		},
		hasThumb(id) {
			return !!this.thumbSet[id];
		},
		thumbUrl(id) {
			return '/uploads/chthumbs/' + Math.floor(id / 1000) + '/' + id + '.webp';
		},
		toggleReverse() {
			this.reverse = !this.reverse;
			this.page = 1;
		},
		isFav(id) {
			return this.favch[id] !== undefined;
		},
		toggleFav(id) {
			if (dle_group == 5) {
				DLEalert(this.favch_guest || 'Available to registered users only', dle_info);
				return;
			}
			if (this.favch_busy[id]) return;
			this.favch_busy[id] = true;
			const done = () => { delete this.favch_busy[id]; };
			this.sendAjax('favchapters/toggle', {chapter_id: id, user_hash: dle_login_hash}, d => {
				done();
				if (d.data.active) this.favch[id] = '';
				else delete this.favch[id];
			}, done);
		},
		toggleReaded(id) {
			if (dle_group == 5) {
				DLEalert('Available to registered users only', 'Error');
			} else {
				this.sendAjax('readed/toggleReaded', {id: id}, d => {
					this.sendAjax('follow/setReaded', {id: id});
					this.readed[id] = d.data;
					let posi = this.getChapterIndexById(id);
					if (posi > -1) this.chapters[posi].is_new = false;
				});
			}
		},
		setAllReaded() {
			this.sendAjax('readed/readedAll', {}, d => {
				this.sendAjax('follow/setPostReaded', {});
				for (let v of this.chapters) {
					this.readed[v.id] = true;
					v.is_new = false;
				}
			});
		},
		setAllUnReaded() {
			this.sendAjax('readed/unreadedAll', {}, d => {
				for (let v of this.chapters) {
					this.readed[v.id] = false;
				}
			});
		},
		selectAll() {
			let c = this.selected.length;
			this.selected = [];
			if (c != this.chaptersList.length) {
				for (let v of this.chaptersList) {
					if (v.allow_edit) this.selected.push(v.id);
				}
			}
		},
		// getDownloadLink() removed together with the server-side archive endpoint:
		// the per-chapter button opens the bulk dialog (data-bulkdl-trigger).
		getChapterIndexById(id) {
			for (let i in this.chapters) {
				if (this.chapters[i].id == id) return i;
			}
			return -1;
		},
		deleteChapter(id) {
			DLEconfirm('Delete this issue?', 'Confirm', () => {
				this.sendAjax('chapters/deleteChapter', {id: id}, d => {
					let posi = this.getChapterIndexById(id);
					if (posi > -1) this.chapters.splice(posi, 1);
					if (this.edit_id == id) this.closeForm();
				});
			})
		},
		deleteSelected() {
			DLEconfirm('Delete <b>' + this.selected.length + '</b> selected issue(s)? This cannot be undone.', 'Confirm', () => {
				this.sendAjax('chapters/deleteSelected', {selected: this.selected}, d => {
					this.selected = [];
					for (let id of d.data) {
						let posi = this.getChapterIndexById(id);
						if (posi > -1) this.chapters.splice(posi, 1);
					}
					DLEalert('Selected issues deleted', 'Done');
				});
			});
		},
		startEdit(id) {
			if (id != this.edit_id) {
				this.currentAction = 'edit';
				this.edit_id = id;
				$('html,body').animate({scrollTop: $('.cl__actions').offset().top});
			} else {
				this.closeForm();
			}
		},
		closeForm() {
			this.edit_id = 0;
			this.currentAction = '';
		},
		showAddForm() {
			if (this.currentAction == 'edit' && !this.edit_id) {
				this.closeForm();
			} else {
				this.currentAction = 'edit';
				this.edit_id = 0;
			}
		},
		showGrab() {
			if (this.currentAction == 'grab') {
				this.closeForm();
			} else {
				this.currentAction = 'grab';
			}
		},
		showSort() {
			if (this.currentAction == 'sort') {
				this.closeForm();
			} else {
				this.currentAction = 'sort';
			}
		},
	},


	components: {
		navigation: {
			// Постраничная навигация
			template: '#navigation_tpl',
			props: {
				page_num: Number,
				count: Number,
				limit: Number,
				range: {
					type: Number,
					default: 5
				},
			},
			data() {
				return {
					page_count: 1,
					pages: [],
					shift: {from: 0,to: 0},
				};
			},
			beforeMount() {
				this.page_count = Math.ceil(this.count / this.limit);
				this.calcShifts();
			},
			watch: {
				page_num: function(newVal, oldVal) {
					if (newVal != oldVal) this.calcShifts();
				}
			},
			methods: {
				calcShifts() {
					if (this.page_count <= 2) return;
					this.pages = [];
					this.shift.from = this.page_num - this.range;
					
					this.shift.to = this.page_num + this.range;
					this.shift.to<this.range*2&&(this.shift.to=this.range*2);

					if (this.shift.to >= this.page_count - 2) {
						this.shift.to = this.page_count - 1;
						if (this.shift.from > 3) {
							let from = this.page_count - this.range*2 + 1;
							from<this.shift.from&&(this.shift.from=from);
						}
					}
					this.shift.from<=3&&(this.shift.from=2);
					for (let i = this.shift.from; i <= this.shift.to; i++) {
						this.pages.push(i);
					}
				},
				setPage(p) {
					this.$parent.page = p;
				}
			},
		},




		edit: {
			//Форма добавления и редактирования выпуска
			template: '#edit_tpl',
			props: {
				id: {
					type: Number,
					default: 0
				},
			},
			data() {
				return {
					title: '',
					title_en: '',
					date: '',
					images: [],
					upload_list: [],
					is_loading: false,
				};
			},
			watch: {
				id: function(newVal) {
					this.getFormContents(newVal);
				}
			},
			beforeMount() {
				this.getFormContents(this.id);
			},
			methods: {
				getFormContents(id) {
					if (id) {
						this.$parent.sendAjax('chapters/edit', {id: id}, d => {
							Object.assign(this.$data, d.data);

							setTimeout(() => Sortable.create(document.querySelector('.cl__editImages')));

							//setTimeout(() => $(".cl__editImages").sortable());

						}, () => {
							this.$parent.closeForm();
						});
					} else {
						Object.assign(this.$data, this.$options.data());
					}
				},
				onFileChange(e) {
					this.upload_list = e.target.files || e.dataTransfer.files;
					console.log(this.upload_list);
				},
				formatSize(bytes) {
					var k = 1024;
					var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
					var i = Math.floor(Math.log(bytes) / Math.log(k));
					if(bytes === 0) return "0 bytes";
					return Math.round(bytes / Math.pow(k, i), 2) + ' ' + sizes[i];
				},
				expandImage(src) {
					$('body').css({overflow: 'hidden'});
					$('body').append('<div class="cl__imageExpander"><img src="' + src + '"></div>');
					$('.cl__imageExpander').click(function(){
						$(this).remove();
						$('body').css({overflow: 'auto'});
					});
				},
				confirmDelete() {
					this.$parent.deleteChapter(this.id);
				},
				deleteAllImages() {
					for (img of this.images) {
						img.disabled = true;
					}
				}
			},
		},




		grab: {
			template: '#grab_tpl',
			data() {
				return {
					is_working: false,
					srclist: [],
					chapters: '',
					worklist: [],
				};
			},
			beforeMount() {
				this.$parent.sendAjax('chapters/grabList', {}, d => {
					this.srclist = d.data;
				}, () => {
					this.$parent.closeForm();
				});
			},
			methods: {
				grabChapters(link) {
					this.$parent.sendAjax('chapters/grabChapters', {link: link}, d => {
						this.chapters = d.data.join("\n");
					});
				},
				startGrab() {
					if (this.chapters && !this.is_working) {
						this.is_working = true;
						this.worklist = this.chapters.split("\n");
						this.grabItem();
					} else {
						DLEalert('The address list is empty', 'Warning');
					}
				},
				stopTasks() {
					this.$parent.sendAjax('chapters/stopTasks', {}, d => DLEalert('Stopped', 'Done'));
				},
				startTasks() {
					this.$parent.sendAjax('chapters/startTasks', {}, d => DLEalert('Started', 'Done'));
				},
				addTasks() {
					if (this.chapters) {
						this.$parent.sendAjax('chapters/addTasks', {list: this.chapters}, d => {
							this.chapters = '';
							DLEalert('Task list queued', 'Done');
						});
					} else {
						DLEalert('The address list is empty', 'Warning');
					}
				},
				clearTasks() {
					DLEconfirm('Clear the whole task list?', 'Confirm', () => {
						this.$parent.sendAjax('chapters/clearTasks', {}, d => {
							DLEalert('Task list cleared', 'Done');
						});
					});
				},
				grabItem() {
					if (!this.worklist.length) {
						this.is_working = false;
						DLEalert('Chapter list processed', 'Done')
						return;
					}

					this.$parent.chapters.unshift({
						'title': 'Loading...',
						'title_en': 'Please Wait',
						'date': 'processing',
						'posi': '??',
						'pages': '??',
					});

					if (this.worklist[0]) {
						this.$parent.sendAjax('chapters/grabChapter', {link: this.worklist[0]}, d => {
							this.worklist = this.worklist.slice(1);
							this.$parent.chapters.shift();
							this.$parent.chapters.unshift(d.data);
							this.grabItem();
						}, () => {
							this.is_working = false;
						});
					} else {
						this.worklist = this.worklist.slice(1);
						this.grabItem();
					}
				},
			},
		},




		sort: {
			template: '#sort_tpl',
			data() {
				return {
					is_working: false,
					chapters: [],
					sortable: null,
					mass: {
						from: 1,
						to: 1,
						at: 1,
						after: 1,
					}
				};
			},
			beforeMount() {
				this.chapters = JSON.parse(JSON.stringify(this.$parent.chapters));
			},
			mounted() {
				setTimeout(() => {
					this.sortable = Sortable.create(document.querySelector('.comix-sort-list'), {
						ghostClass: "sortable-placeholder"
					});
				});
			},
			methods: {
				saveSort(close) {
					let neworder = [];
					for (let elm of this.sortable.el.childNodes) {
						if (elm.id) {
							let id = elm.id.match(/csid-(\d+)/);
							if (id && id[1]) {
								neworder.push(parseInt(id[1]));
							}
						}
					}
					this.$parent.sendAjax('chapters/setSort', {sort: neworder.join(',')}, d => {
						this.$parent.chapters = d.data;
						for (i of d.data) {
							this.chapters.find(v => {return v.id == i.id}).posi = i.posi;
						}
						close&&this.$parent.closeForm();
					});
				},
				massSort() {
					this.$parent.sendAjax('chapters/massSort', this.mass, d => {
						this.$parent.chapters = d.data;
						this.chapters = d.data;
						this.$parent.closeForm();
					});
				},
			},
		},

	},
}).mount('.comix__fullstory');






/* Закладки */
Vue.createApp({
	data() {
		return Object.assign({
		}, window.favorites);
	},
	methods: {
		remove() {
			sendAjax('favorites/delete', {news_id: this.news_id}, d => {
				this.active = '';
			});
		},
		add(folder) {
			if (folder != this.active) {
				sendAjax('favorites/add', {news_id: this.news_id, folder: folder}, d => {
					this.active = folder;
				});
			}
		},

	},
}).mount('#fullstory__favorites');
