/* Закладка «? Help» справа вместо всплывающего окна «Hello, newcomer» (06.11.2026).
   Окно на весь экран при первом визите закрывало карточку пришедшим из поиска; владелец выбрал закладку.
   Содержимое берётся из скрытого #welcomeFaqNotify в main.tpl (текст правится там). Стили — css/templates.css (.bm*).
   localStorage: welcome_faq_v1 — уже видел (без «выглядывания»), help_tab_off — посетитель скрыл закладку
   (FAQ остаётся в подвале). Откат: main.tpl.bak.helptab-20261106. */
(function () {
	var SKIP = ['/community/', '/patron', '/mychapters', '/repair', '/reader/', '/addnews', '/user/'];
	var p = location.pathname, i;
	if (document.querySelector('.uprofile')) return;
	for (i = 0; i < SKIP.length; i++) { if (p.indexOf(SKIP[i]) === 0) return; }
	var store = {
		get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
		set: function (k) { try { localStorage.setItem(k, '1'); } catch (e) {} }
	};
	if (store.get('help_tab_off')) return;
	var src = document.querySelector('#welcomeFaqNotify .un-box');
	if (!src) return;

	var wrap = document.createElement('div');
	wrap.className = 'bm';

	var tab = document.createElement('button');
	tab.type = 'button';
	tab.className = 'bm-tab';
	tab.setAttribute('aria-expanded', 'false');
	tab.setAttribute('aria-controls', 'bmPage');
	var q = document.createElement('span'); q.className = 'bm-q'; q.textContent = '?';
	var t = document.createElement('span'); t.className = 'bm-t'; t.textContent = 'Help';
	tab.appendChild(q); tab.appendChild(t);

	var page = document.createElement('div');
	page.className = 'bm-page';
	page.id = 'bmPage';
	page.setAttribute('role', 'dialog');
	page.setAttribute('aria-label', 'Quick help');
	var title = src.querySelector('.un-t');
	if (title) title.textContent = 'New here? Quick help';
	page.appendChild(src);

	var off = document.createElement('button');
	off.type = 'button';
	off.className = 'bm-off';
	off.textContent = "Don't show this tab again";
	var offNote = document.createElement('p');
	offNote.className = 'bm-off-note';
	offNote.textContent = 'The FAQ link stays at the bottom of every page.';
	src.appendChild(off);
	src.appendChild(offNote);

	wrap.appendChild(tab);
	wrap.appendChild(page);
	var shade = document.createElement('div');
	shade.className = 'bm-shade';
	document.body.appendChild(shade);
	document.body.appendChild(wrap);

	function set(open) {
		wrap.classList.toggle('open', open);
		shade.classList.toggle('on', open);
		tab.setAttribute('aria-expanded', open ? 'true' : 'false');
		t.textContent = open ? 'Close' : 'Help';
	}
	tab.addEventListener('click', function () { set(!wrap.classList.contains('open')); });
	shade.addEventListener('click', function () { set(false); });
	page.addEventListener('click', function (e) { if (e.target.closest('[data-un-close]')) set(false); });
	document.addEventListener('keydown', function (e) {
		if ((e.key === 'Escape' || e.keyCode === 27) && wrap.classList.contains('open')) { set(false); tab.focus(); }
	});
	off.addEventListener('click', function () {
		store.set('help_tab_off');
		wrap.remove();
		shade.remove();
	});

	// Первый визит: один раз чуть выглянуть из края, чтобы закладку заметили.
	if (!store.get('welcome_faq_v1')) {
		wrap.classList.add('peek');
		store.set('welcome_faq_v1');
	}
})();
