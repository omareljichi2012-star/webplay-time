// Sandev/Passkey — WebAuthn client (delegated handlers for cloned DLE login popup)
(function () {
  'use strict';

  var API = '/engine/plugins/Sandev/Passkey/ajax.php';
  var state = {
    supported: false,
    testMode: true,
    testCookie: 'passkey_test_admin',
    ready: false
  };

  function getCookie(name) {
    var safe = name.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
    var m = document.cookie.match('(^|;)\\s*' + safe + '\\s*=\\s*([^;]+)');
    return m ? decodeURIComponent(m[2]) : '';
  }

  function csrfToken(root) {
    if (root && root.dataset && root.dataset.csrf) return root.dataset.csrf;
    if (window.dle_login_hash) return window.dle_login_hash;
    var hidden = document.querySelector('input[name="dle_login_hash"], input[name="dle_allow_hash"]');
    return hidden ? hidden.value : '';
  }

  function showMsg(scope, text, type) {
    var msg = null;
    var node = scope;
    while (node && node !== document.body) {
      msg = node.querySelector ? node.querySelector('[data-passkey-msg]') : null;
      if (msg) break;
      node = node.parentNode;
    }
    if (!msg) return;
    msg.textContent = text;
    msg.className = 'sandev-passkey-msg sandev-passkey-msg--' + (type || 'success');
    msg.hidden = false;
  }

  function hideMsg(scope) {
    var msg = scope && scope.querySelector ? scope.querySelector('[data-passkey-msg]') : null;
    if (msg) msg.hidden = true;
  }

  function api(action, options) {
    options = options || {};
    return fetch(API + '?action=' + encodeURIComponent(action), {
      method: options.method || 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: options.body ? JSON.stringify(options.body) : undefined
    }).then(function (response) {
      return response.json().catch(function () { return null; }).then(function (data) {
        if (!data) throw new Error('bad_json');
        if (!data.ok) {
          var err = new Error(data.error || 'request_failed');
          err.payload = data;
          throw err;
        }
        return data.data || {};
      });
    });
  }

  function base64UrlToBuffer(value) {
    var pad = '='.repeat((4 - value.length % 4) % 4);
    var base64 = (value + pad).replace(/-/g, '+').replace(/_/g, '/');
    var raw = atob(base64);
    var out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out.buffer;
  }

  function bufferToBase64Url(buffer) {
    var bytes = new Uint8Array(buffer);
    var str = '';
    for (var i = 0; i < bytes.length; i++) str += String.fromCharCode(bytes[i]);
    return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
  }

  function prepareCreateOptions(options) {
    options.challenge = base64UrlToBuffer(options.challenge);
    options.user.id = base64UrlToBuffer(options.user.id);
    (options.excludeCredentials || []).forEach(function (cred) {
      cred.id = base64UrlToBuffer(cred.id);
    });
    return options;
  }

  function prepareGetOptions(options) {
    options.challenge = base64UrlToBuffer(options.challenge);
    (options.allowCredentials || []).forEach(function (cred) {
      cred.id = base64UrlToBuffer(cred.id);
    });
    return options;
  }

  function credentialToJSON(credential, kind) {
    var json = {
      id: credential.id,
      rawId: bufferToBase64Url(credential.rawId),
      type: credential.type,
      response: {}
    };
    if (kind === 'create') {
      json.response.clientDataJSON = bufferToBase64Url(credential.response.clientDataJSON);
      json.response.attestationObject = bufferToBase64Url(credential.response.attestationObject);
      if (credential.response.getTransports) {
        try { json.response.transports = credential.response.getTransports(); } catch (_) {}
      }
    } else {
      json.response.clientDataJSON = bufferToBase64Url(credential.response.clientDataJSON);
      json.response.authenticatorData = bufferToBase64Url(credential.response.authenticatorData);
      json.response.signature = bufferToBase64Url(credential.response.signature);
      json.response.userHandle = credential.response.userHandle ? bufferToBase64Url(credential.response.userHandle) : '';
    }
    return json;
  }

  function clientContext() {
    // Платформа и браузер: по ним видно, чей менеджер паролей отказал —
    // AAGUID при неудачном входе недоступен, ключ ведь не получен.
    var ua = navigator.userAgent || '';
    var platform = 'other';
    if (/iPhone|iPad|iPod/i.test(ua)) platform = 'iOS';
    else if (/Android/i.test(ua)) platform = 'Android';
    else if (/Windows/i.test(ua)) platform = 'Windows';
    else if (/Macintosh|Mac OS X/i.test(ua)) platform = 'macOS';
    else if (/Linux|X11/i.test(ua)) platform = 'Linux';

    var browser = 'other';
    var m;
    if (/SamsungBrowser/i.test(ua)) { browser = 'Samsung'; m = ua.match(/SamsungBrowser\/(\d+)/); }
    else if (/YaBrowser/i.test(ua)) { browser = 'Yandex'; m = ua.match(/YaBrowser\/(\d+)/); }
    else if (/OPR|Opera/i.test(ua)) { browser = 'Opera'; m = ua.match(/OPR\/(\d+)/); }
    else if (/Edg\//i.test(ua)) { browser = 'Edge'; m = ua.match(/Edg\/(\d+)/); }
    else if (/Firefox/i.test(ua)) { browser = 'Firefox'; m = ua.match(/Firefox\/(\d+)/); }
    else if (/Chrome/i.test(ua)) { browser = 'Chrome'; m = ua.match(/Chrome\/(\d+)/); }
    else if (/Safari/i.test(ua)) { browser = 'Safari'; m = ua.match(/Version\/(\d+)/); }
    if (m && m[1]) browser += m[1];

    var pwa = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) ? '/pwa' : '';
    return platform + '/' + browser + pwa;
  }

  function reportClientError(stage, error) {
    // Ошибки navigator.credentials живут только в браузере — шлём их в аудит,
    // иначе «не могу войти» невозможно диагностировать.
    if (!error || error.payload || error.expected) return;   // серверные и ожидаемые не логируем
    var name = error.name || 'UnknownError';
    // Обрыв fetch при уходе со страницы и отмена — не диагностика, а шум.
    if (name === 'TypeError' || name === 'AbortError' || name === 'NetworkError') return;
    // bad_json = ответ пришёл не JSON (гард/кеш/обрыв) — транспорт, не WebAuthn.
    if (String(error.message || '') === 'bad_json') return;
    // Голый TypeError почти всегда «Failed to fetch» — без текста он бесполезен.
    if (name === 'TypeError' || name === 'Error' || name === 'UnknownError') {
      name += ':' + String(error.message || '').replace(/[^A-Za-z0-9 _.-]/g, '').slice(0, 30);
    }
    try {
      fetch(API + '?action=client_error', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stage: stage,
          name: String(name).slice(0, 60),
          ctx: clientContext()
        }),
        keepalive: true
      }).catch(function () {});
    } catch (_) {}
  }

  function errorText(error) {
    var code = error && error.name ? error.name : '';
    var server = error && error.payload ? error.payload.error : '';
    if (error && error.expected && error.message) code = error.message;
    var map = {
      no_passkey_for_account: 'This account has no passkey. Sign in with a password or by email, then add a passkey in your profile.',
      NotAllowedError: 'No passkey found on this device, or the prompt was dismissed. Sign in with a password, or add a passkey in your profile.',
      OperationError: 'This device could not provide a passkey. Sign in with a password or by email.',
      NotReadableError: 'The device could not open the passkey. Sign in with a password or by email.',
      InvalidStateError: 'This passkey is already registered or not available on this device.',
      NotSupportedError: 'This browser does not support Passkey.',
      SecurityError: 'Passkey only works over HTTPS.',
      csrf_invalid: 'Your session has expired. Refresh the page.',
      attestation_failed: 'Could not activate Passkey.',
      not_authenticated: 'You need to be logged in.',
      challenge_expired: 'The operation timed out. Please try again.',
      credential_exists: 'This passkey is already in use by another account.',
      max_credentials_reached: 'Limit of 10 passkeys reached.',
      credential_not_found: 'There is no passkey for this account on this device.',
      rate_limited: 'Too many attempts. Please try again later.',
      passkey_only_requires_recovery: 'Passkey-only requires a verified email, 2 passkeys, or 5 backup codes.',
      last_passkey_delete_denied: 'Disable Passkey-only mode first.',
      recovery_code_invalid: 'Invalid backup code or already used.'
    };
    return map[server] || map[code] || (error && error.payload && error.payload.message) || 'Operation failed.';
  }

  function setBusy(btn, busy, text) {
    if (!btn) return;
    if (busy) {
      btn.dataset.originalHtml = btn.innerHTML;
      btn.disabled = true;
      btn.textContent = text || 'Please wait…';
    } else {
      btn.disabled = false;
      if (Object.prototype.hasOwnProperty.call(btn.dataset, 'originalHtml')) {
        btn.innerHTML = btn.dataset.originalHtml;
        delete btn.dataset.originalHtml;
      }
    }
  }

  function showWizard() {
    return new Promise(function (resolve, reject) {
      var step = 0;
      var name = defaultDeviceName();
      var steps = [
        {
          icon: 'fa-key',
          title: 'What is a Passkey?',
          html: '<p>Passkey is passwordless login. Instead of remembering passwords, you use the device biometrics or PIN.</p><ul><li>Nothing to remember</li><li>Cannot be stolen by phishing</li><li>Works on phone and computer</li></ul>'
        },
        {
          icon: 'fa-shield-alt',
          title: 'Why is this safe?',
          html: '<p>The secret key stays on your device. Only the public key is stored on the server, and it is useless for login on its own.</p><p>Even if the database leaks, a passkey does not become a password.</p>'
        },
        {
          icon: 'fa-check',
          title: 'Ready to activate?',
          html: '<p>Click "Activate" and confirm with your biometrics or PIN. For extra safety, add a second passkey on another device later.</p><label class="sandev-passkey-name"><span>Device name</span><input type="text" data-passkey-name maxlength="64" value="' + escapeHtml(name) + '"></label>'
        }
      ];

      var modal = document.createElement('div');
      modal.className = 'sandev-passkey-modal';
      modal.innerHTML = '<div class="sandev-passkey-dialog" role="dialog" aria-modal="true">' +
        '<div class="sandev-passkey-dialog__bar"><div class="sandev-passkey-dots"></div><button type="button" class="sandev-passkey-close" data-close><span class="fal fa-times"></span></button></div>' +
        '<div class="sandev-passkey-dialog__body"></div></div>';
      document.body.appendChild(modal);

      function render() {
        var dots = modal.querySelector('.sandev-passkey-dots');
        dots.innerHTML = steps.map(function (_, i) { return '<span class="' + (i === step ? 'is-active' : '') + '"></span>'; }).join('');
        var s = steps[step];
        var body = modal.querySelector('.sandev-passkey-dialog__body');
        body.innerHTML = '<div class="sandev-passkey-step-icon"><span class="fal ' + s.icon + '"></span></div>' +
          '<h3>' + s.title + '</h3>' + s.html +
          '<div class="sandev-passkey-dialog__actions">' +
          (step > 0 ? '<button type="button" class="sandev-passkey-btn sandev-passkey-btn--secondary" data-prev>Back</button>' : '') +
          '<button type="button" class="sandev-passkey-btn" data-next>' + (step === steps.length - 1 ? 'Activate' : 'Next') + '</button>' +
          '</div>';
      }

      function close(reason) {
        modal.remove();
        if (reason) reject(new Error(reason));
      }

      modal.addEventListener('click', function (e) {
        var target = e.target.closest('button');
        if (!target) return;
        if (target.hasAttribute('data-close')) {
          close('cancelled');
        } else if (target.hasAttribute('data-prev')) {
          step = Math.max(0, step - 1);
          render();
        } else if (target.hasAttribute('data-next')) {
          if (step < steps.length - 1) {
            step += 1;
            render();
          } else {
            var input = modal.querySelector('[data-passkey-name]');
            var finalName = input && input.value.trim() ? input.value.trim() : name;
            modal.remove();
            resolve(finalName);
          }
        }
      });

      render();
    });
  }

  function showRecoveryCodes(codes) {
    var modal = document.createElement('div');
    modal.className = 'sandev-passkey-modal';
    modal.innerHTML = '<div class="sandev-passkey-dialog" role="dialog" aria-modal="true">' +
      '<div class="sandev-passkey-dialog__bar"><div></div><button type="button" class="sandev-passkey-close" data-close disabled><span class="fal fa-times"></span></button></div>' +
      '<div class="sandev-passkey-dialog__body">' +
      '<div class="sandev-passkey-step-icon"><span class="fal fa-exclamation-triangle"></span></div>' +
      '<h3>Save your backup codes</h3>' +
      '<p>These codes are shown once. Old backup codes no longer work.</p>' +
      '<div class="sandev-passkey-codes">' + codes.map(function (code) { return '<span>' + escapeHtml(code) + '</span>'; }).join('') + '</div>' +
      '<div class="sandev-passkey-dialog__actions"><button type="button" class="sandev-passkey-btn sandev-passkey-btn--secondary" data-copy>Copy</button><button type="button" class="sandev-passkey-btn sandev-passkey-btn--secondary" data-download>Download .txt</button></div>' +
      '<label class="sandev-passkey-confirm"><input type="checkbox" data-confirm><span>I have saved the codes in a safe place</span></label>' +
      '<div class="sandev-passkey-dialog__actions"><button type="button" class="sandev-passkey-btn" data-done disabled>Close</button></div>' +
      '</div></div>';
    document.body.appendChild(modal);

    var text = codes.join('\n');
    modal.addEventListener('change', function (e) {
      if (e.target.matches('[data-confirm]')) {
        modal.querySelector('[data-done]').disabled = !e.target.checked;
        modal.querySelector('[data-close]').disabled = !e.target.checked;
      }
    });
    modal.addEventListener('click', function (e) {
      var btn = e.target.closest('button');
      if (!btn) return;
      if (btn.matches('[data-close], [data-done]') && !btn.disabled) {
        modal.remove();
      } else if (btn.matches('[data-copy]')) {
        navigator.clipboard && navigator.clipboard.writeText(text);
      } else if (btn.matches('[data-download]')) {
        var blob = new Blob([text + '\n'], { type: 'text/plain;charset=utf-8' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'com-x-passkey-backup-codes.txt';
        a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
      }
    });
  }

  function enroll(scope) {
    var root = scope && scope.closest ? (scope.closest('.js-passkey-profile') || scope) : document.body;
    var btn = scope && scope.matches && scope.matches('button') ? scope : null;
    return showWizard().then(function (name) {
      setBusy(btn, true, 'Activating…');
      return api('enroll_options', { body: { dle_login_hash: csrfToken(root) } }).then(function (options) {
        return navigator.credentials.create({ publicKey: prepareCreateOptions(options) });
      }).then(function (credential) {
        return api('enroll_verify', {
          body: {
            dle_login_hash: csrfToken(root),
            credential_name: name,
            attestation: credentialToJSON(credential, 'create')
          }
        });
      }).then(function () {
        showMsg(root, 'Passkey activated.', 'success');
        loadProfile(root);
      });
    }).catch(function (err) {
      if (err.message !== 'cancelled') {
        reportClientError('enroll', err);
        showMsg(root, errorText(err), 'error');
      }
    }).finally(function () {
      setBusy(btn, false);
    });
  }

  function login(scope) {
    var wrap = scope && scope.closest ? scope.closest('.login, .login-cloned, body') : document.body;
    var input = wrap ? wrap.querySelector('input[name="login_name"]') : null;
    var username = input && input.value ? input.value.trim() : '';
    var btn = scope && scope.matches && scope.matches('button') ? scope : null;
    setBusy(btn, true, 'Signing in…');
    hideMsg(wrap || document.body);

    api('login_options', { body: { username: username } }).then(function (options) {
      // Логин введён, а ключей у аккаунта нет — системное окно показывать незачем,
      // человек всё равно получит отказ без объяснений.
      var hasCreds = options.allowCredentials && options.allowCredentials.length > 0;
      if (username && !hasCreds) {
        var noKey = new Error('no_passkey_for_account');
        noKey.expected = true;
        throw noKey;
      }
      return navigator.credentials.get({ publicKey: prepareGetOptions(options) });
    }).then(function (credential) {
      return api('login_verify', { body: { assertion: credentialToJSON(credential, 'get') } });
    }).then(function (data) {
      window.location.href = data.redirect_to || '/';
    }).catch(function (err) {
      reportClientError('login', err);
      showMsg(wrap || document.body, errorText(err), 'error');
    }).finally(function () {
      setBusy(btn, false);
    });
  }

  function recoveryCodeLogin(scope) {
    var wrap = scope && scope.closest ? scope.closest('.login, .login-cloned, .sandev-passkey-login, body') : document.body;
    var usernameInput = wrap ? wrap.querySelector('input[name="login_name"]') : null;
    var codeInput = wrap ? wrap.querySelector('[data-passkey-recovery-code]') : null;
    var username = usernameInput && usernameInput.value ? usernameInput.value.trim() : '';
    var code = codeInput && codeInput.value ? codeInput.value.trim() : '';
    var btn = scope && scope.matches && scope.matches('button') ? scope : null;

    if (!username) {
      showMsg(wrap || document.body, 'Enter your username or email.', 'error');
      if (usernameInput) usernameInput.focus();
      return;
    }
    if (!code) {
      showMsg(wrap || document.body, 'Enter the backup code.', 'error');
      if (codeInput) codeInput.focus();
      return;
    }

    setBusy(btn, true, 'Verifying…');
    hideMsg(wrap || document.body);
    api('recovery_code_use', { body: { username: username, code: code } }).then(function (data) {
      window.location.href = data.redirect_to || '/';
    }).catch(function (err) {
      showMsg(wrap || document.body, errorText(err), 'error');
    }).finally(function () {
      setBusy(btn, false);
    });
  }

  function loadProfile(root) {
    root = root || document.querySelector('.js-passkey-profile');
    if (!root) return Promise.resolve();
    return api('credentials_list', { method: 'GET' }).then(function (data) {
      renderProfile(root, data);
    }).catch(function (err) {
      showMsg(root, errorText(err), 'error');
    });
  }

  function renderProfile(root, data) {
    var list = root.querySelector('[data-passkey-list]');
    var toggle = root.querySelector('[data-passkey-only]');
    var status = root.querySelector('[data-passkey-codes-status]');
    if (toggle) {
      toggle.checked = !!data.passkey_only;
      // Гейт тот же, что на сервере: без ключа режим запирает аккаунт наглухо.
      var keys = (data.credentials || []).length;
      var codes = data.recovery_codes_remaining || 0;
      var blockReason = '';
      if (keys < 1) blockReason = 'Add a passkey first';
      else if (keys < 2 && codes < 5) blockReason = 'Needs a second passkey or 5 backup codes';
      toggle.disabled = !data.passkey_only && blockReason !== '';
      var note = root.querySelector('[data-passkey-only-note]');
      if (note) {
        note.textContent = toggle.disabled ? blockReason : '';
        note.hidden = !toggle.disabled;
      }
    }
    if (status) {
      status.textContent = data.recovery_codes_remaining > 0
        ? 'Status: ' + data.recovery_codes_remaining + ' of 10 unused'
        : 'Status: not generated';
    }
    if (!list) return;
    if (!data.credentials || !data.credentials.length) {
      list.innerHTML = '<div class="sandev-passkey-empty">No passkeys yet.</div>';
      return;
    }
    list.innerHTML = data.credentials.map(function (item) {
      return '<div class="sandev-passkey-item" data-passkey-id="' + item.id + '">' +
        '<div><div class="sandev-passkey-item__name"><span class="fal fa-key"></span> ' + escapeHtml(item.name || 'My Passkey') + '</div>' +
        '<div class="sandev-passkey-item__meta">Created: ' + escapeHtml(item.created_at || '-') + '<br>Last used: ' + escapeHtml(item.last_used_at || 'never') + '</div></div>' +
        '<div class="sandev-passkey-item__actions">' +
        '<button type="button" class="sandev-passkey-btn sandev-passkey-btn--secondary" data-passkey-rename title="Rename"><span class="fal fa-pen"></span></button>' +
        '<button type="button" class="sandev-passkey-btn sandev-passkey-btn--danger" data-passkey-delete title="Delete"><span class="fal fa-trash-alt"></span></button>' +
        '</div></div>';
    }).join('');
  }

  function renameCredential(btn) {
    var root = btn.closest('.js-passkey-profile');
    var item = btn.closest('[data-passkey-id]');
    if (!root || !item) return;
    var current = item.querySelector('.sandev-passkey-item__name');
    var name = window.prompt('New passkey name', current ? current.textContent.replace(/^\s*/, '').trim() : '');
    if (!name) return;
    setBusy(btn, true, '');
    api('credential_rename', {
      body: { dle_login_hash: csrfToken(root), credential_id: Number(item.dataset.passkeyId), new_name: name }
    }).then(function () {
      showMsg(root, 'Passkey renamed.', 'success');
      loadProfile(root);
    }).catch(function (err) {
      showMsg(root, errorText(err), 'error');
    }).finally(function () {
      setBusy(btn, false);
    });
  }

  function deleteCredential(btn) {
    var root = btn.closest('.js-passkey-profile');
    var item = btn.closest('[data-passkey-id]');
    if (!root || !item) return;
    if (!window.confirm('Delete this passkey?')) return;
    setBusy(btn, true, '');
    api('credential_delete', {
      body: { dle_login_hash: csrfToken(root), credential_id: Number(item.dataset.passkeyId) }
    }).then(function () {
      showMsg(root, 'Passkey deleted.', 'success');
      loadProfile(root);
    }).catch(function (err) {
      showMsg(root, errorText(err), 'error');
    }).finally(function () {
      setBusy(btn, false);
    });
  }

  function togglePasskeyOnly(input) {
    var root = input.closest('.js-passkey-profile');
    var enabled = input.checked;
    input.disabled = true;
    api('passkey_only_toggle', {
      body: { dle_login_hash: csrfToken(root), enabled: enabled }
    }).then(function () {
      showMsg(root, enabled ? 'Passkey-only enabled.' : 'Passkey-only disabled.', 'success');
      loadProfile(root);
    }).catch(function (err) {
      input.checked = !enabled;
      showMsg(root, errorText(err), 'error');
    }).finally(function () {
      input.disabled = false;
    });
  }

  function generateCodes(btn) {
    var root = btn.closest('.js-passkey-profile');
    if (!root) return;
    if (!window.confirm('Generate new backup codes? The old ones will stop working.')) return;
    setBusy(btn, true, 'Generating…');
    api('recovery_codes_generate', {
      body: { dle_login_hash: csrfToken(root) }
    }).then(function (data) {
      showRecoveryCodes(data.recovery_codes || []);
      loadProfile(root);
    }).catch(function (err) {
      showMsg(root, errorText(err), 'error');
    }).finally(function () {
      setBusy(btn, false);
    });
  }

  function defaultDeviceName() {
    var ua = navigator.userAgent || '';
    if (/iPhone/i.test(ua)) return 'iPhone';
    if (/iPad/i.test(ua)) return 'iPad';
    if (/Android/i.test(ua)) return 'Android';
    if (/Mac/i.test(ua)) return 'MacBook';
    if (/Windows/i.test(ua)) return 'Windows PC';
    return 'My Passkey';
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function (ch) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[ch];
    });
  }

  function updateVisibility() {
    var gate = state.ready && (!state.testMode || getCookie(state.testCookie) === '1');
    var visible = gate && state.supported;
    document.querySelectorAll('[data-passkey-ui]').forEach(function (node) {
      node.hidden = !visible;
    });
    document.querySelectorAll('[data-passkey-recovery-ui]').forEach(function (node) {
      node.hidden = !gate;
    });
    if (visible) {
      document.querySelectorAll('.js-passkey-profile').forEach(function (node) {
        if (!node.dataset.loaded) {
          node.dataset.loaded = '1';
          loadProfile(node);
        }
      });
    }
  }

  var conditionalAbort = null;
  var conditionalStarted = false;

  function visibleLoginField() {
    var fields = document.querySelectorAll('input[autocomplete~="webauthn"]');
    for (var i = 0; i < fields.length; i++) {
      if (fields[i].offsetParent !== null) return true;
    }
    return false;
  }

  function startConditionalLogin() {
    if (conditionalStarted) return;
    // Autofill-вариант: браузер сам показывает passkey в подсказках поля логина.
    // Без него на Android приходится угадывать, какую кнопку жать.
    if (!window.PublicKeyCredential || !PublicKeyCredential.isConditionalMediationAvailable) {
      return;
    }
    if (!visibleLoginField()) {
      return;
    }
    conditionalStarted = true;

    PublicKeyCredential.isConditionalMediationAvailable().then(function (available) {
      if (!available) return;

      return api('login_options', { body: { username: '' } }).then(function (options) {
        if (conditionalAbort) conditionalAbort.abort();
        conditionalAbort = new AbortController();

        return navigator.credentials.get({
          publicKey: prepareGetOptions(options),
          mediation: 'conditional',
          signal: conditionalAbort.signal
        });
      }).then(function (credential) {
        if (!credential) return;
        return api('login_verify', { body: { assertion: credentialToJSON(credential, 'get') } })
          .then(function (data) { window.location.href = data.redirect_to || '/'; });
      });
    }).catch(function (err) {
      // Conditional-флоу крутится в фоне у всех посетителей: его отказы
      // («нет ключа», «браузер не умеет») — норма, а не сбой входа.
      if (!err || ['AbortError', 'NotAllowedError', 'NotSupportedError',
                   'NotReadableError', 'OperationError', 'InvalidStateError',
                   'TypeError', 'SecurityError'].indexOf(err.name) !== -1) return;
      reportClientError('login', err);
    });
  }

  function detectSupport() {
    if (!window.PublicKeyCredential || !navigator.credentials || !window.isSecureContext) {
      return Promise.resolve(false);
    }
    return Promise.resolve(true);
  }

  function setup() {
    Promise.all([
      detectSupport(),
      fetch(API + '?action=config', { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
        .then(function (r) { return r.json(); })
        .catch(function () { return null; })
    ]).then(function (res) {
      state.supported = !!res[0];
      if (res[1] && res[1].ok && res[1].data) {
        state.testMode = !!res[1].data.test_mode;
        state.testCookie = res[1].data.test_mode_cookie || state.testCookie;
        // Pickup CSRF token for guests where main.tpl did not emit it
        if (res[1].data.dle_login_hash && !window.dle_login_hash) {
          window.dle_login_hash = res[1].data.dle_login_hash;
        }
      }
      state.ready = true;
      updateVisibility();
      // Conditional стартуем не на каждой странице, а когда форма входа видна:
      // иначе challenge пишется в БД на каждый визит любого гостя.
      if (state.supported && visibleLoginField()) startConditionalLogin();
    });
  }

  document.addEventListener('click', function (e) {
    var target = e.target.closest('[data-passkey-login], [data-passkey-code-login], [data-passkey-enroll], [data-passkey-rename], [data-passkey-delete], [data-passkey-codes-generate]');
    if (!target) return;
    e.preventDefault();
    if (target.hasAttribute('data-passkey-login')) login(target);
    else if (target.hasAttribute('data-passkey-code-login')) recoveryCodeLogin(target);
    else if (target.hasAttribute('data-passkey-enroll')) enroll(target);
    else if (target.hasAttribute('data-passkey-rename')) renameCredential(target);
    else if (target.hasAttribute('data-passkey-delete')) deleteCredential(target);
    else if (target.hasAttribute('data-passkey-codes-generate')) generateCodes(target);
  }, true);

  document.addEventListener('change', function (e) {
    if (e.target && e.target.matches('[data-passkey-only]')) {
      togglePasskeyOnly(e.target);
    }
  }, true);

  document.addEventListener('click', function (e) {
    var node = e.target;
    while (node && node !== document.body) {
      if (node.classList && node.classList.contains('js-show-login')) {
        setTimeout(updateVisibility, 50);
        setTimeout(updateVisibility, 200);
        setTimeout(startConditionalLogin, 250);
        break;
      }
      node = node.parentNode;
    }
  }, true);

  window.SandevPasskey = {
    enroll: enroll,
    login: login,
    recoveryCodeLogin: recoveryCodeLogin,
    showWizard: showWizard,
    showRecoveryCodes: showRecoveryCodes,
    _base64UrlDecode: base64UrlToBuffer,
    _base64UrlEncode: bufferToBase64Url,
    _csrfToken: csrfToken,
    _fetch: api
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setup);
  } else {
    setup();
  }
})();
