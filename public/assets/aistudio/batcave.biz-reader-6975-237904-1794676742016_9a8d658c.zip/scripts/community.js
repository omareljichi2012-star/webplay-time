/* Community Contributors — count-up + scroll reveal. Progressive enhancement:
   final numbers already present in HTML, motion is additive. */
(function () {
	'use strict';
	var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	if (reduce || !('IntersectionObserver' in window)) return;

	function countUp(el) {
		var target = parseInt(el.getAttribute('data-countup'), 10);
		if (!isFinite(target) || target <= 0) return;
		var dur = 900, start = null;
		el.textContent = '0';
		function step(ts) {
			if (start === null) start = ts;
			var p = Math.min((ts - start) / dur, 1);
			var eased = 1 - Math.pow(1 - p, 3);
			el.textContent = Math.round(target * eased).toString();
			if (p < 1) requestAnimationFrame(step);
			else el.textContent = target.toString();
		}
		requestAnimationFrame(step);
	}

	var numObserver = new IntersectionObserver(function (entries, obs) {
		entries.forEach(function (e) {
			if (e.isIntersecting) { countUp(e.target); obs.unobserve(e.target); }
		});
	}, { threshold: 0.4 });
	document.querySelectorAll('[data-countup]').forEach(function (el) { numObserver.observe(el); });

	document.querySelectorAll('.hof').forEach(function (root) {
		root.classList.add('is-reveal');
		var items = root.querySelectorAll('.hof__podium-slot, .hof__row, .hof__feed-row');
		var revObserver = new IntersectionObserver(function (entries, obs) {
			entries.forEach(function (e) {
				if (!e.isIntersecting) return;
				var i = parseInt(e.target.getAttribute('data-rev') || '0', 10);
				setTimeout(function () { e.target.classList.add('is-shown'); }, Math.min(i * 45, 400));
				obs.unobserve(e.target);
			});
		}, { threshold: 0.15 });
		items.forEach(function (el, i) { el.setAttribute('data-rev', i); revObserver.observe(el); });
		// Safety net: never leave content permanently hidden if the observer
		// misses (background tab, layout shift). Reveals anything still pending.
		setTimeout(function () {
			items.forEach(function (el) { el.classList.add('is-shown'); });
		}, 2600);
	});
})();
