/**
 * HEADER-v2 — выдвижная панель кнопки «продолжить чтение».
 *
 * Сама кнопка остаётся обычной ссылкой и ведёт прямо в последнюю главу —
 * панель раскрывается только стрелкой, чтобы основной сценарий был в один клик.
 *
 * Откат: убрать <script> из main.tpl. Разметка без JS остаётся рабочей ссылкой.
 */
(function () {
	'use strict';

	var wrap = document.querySelector('.header__continue-wrap');
	if (!wrap) return;

	var btn  = wrap.querySelector('.js-continue-toggle');
	var drop = wrap.querySelector('.header__continue-drop');
	if (!btn || !drop) return;

	function open() {
		drop.hidden = false;
		wrap.classList.add('is-open');
		btn.setAttribute('aria-expanded', 'true');
	}

	function close() {
		drop.hidden = true;
		wrap.classList.remove('is-open');
		btn.setAttribute('aria-expanded', 'false');
	}

	btn.addEventListener('click', function (e) {
		e.preventDefault();
		e.stopPropagation();
		if (drop.hidden) open(); else close();
	});

	// Клик вне панели закрывает её, клик внутри — нет
	document.addEventListener('click', function (e) {
		if (drop.hidden) return;
		if (!wrap.contains(e.target)) close();
	});

	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape' && !drop.hidden) close();
	});

	// Только смена ориентации. Слушать resize нельзя: мобильные браузеры шлют его
	// при скролле (сворачивание адресной строки) и при открытии клавиатуры —
	// панель закрывалась бы сама собой.
	window.addEventListener('orientationchange', close);
})();

/**
 * HEADER-v2 — поиск, выезжающий поверх разделов (десктоп ≥1221, см. header-v2.css §6b).
 *
 * Кнопка видна только на десктопе; ниже поле стоит в шапке всегда, и этот код
 * ничего не делает. Выпадающие подсказки DLE (#searchsuggestions) живут в body —
 * клик по ним не считается кликом «мимо».
 */
(function () {
	'use strict';

	var slot   = document.querySelector('.header__nav-slot');
	if (!slot) return;
	var toggle = slot.querySelector('.js-search-toggle');
	var input  = slot.querySelector('#story');
	if (!toggle || !input) return;

	function isOpen() { return slot.classList.contains('is-search-open'); }

	function open() {
		slot.classList.add('is-search-open');
		toggle.setAttribute('aria-expanded', 'true');
		toggle.setAttribute('aria-label', 'Close search');
		input.focus();
	}

	function close(returnFocus) {
		slot.classList.remove('is-search-open');
		toggle.setAttribute('aria-expanded', 'false');
		toggle.setAttribute('aria-label', 'Open search');
		if (returnFocus) toggle.focus();
	}

	toggle.addEventListener('click', function (e) {
		e.preventDefault();
		if (isOpen()) close(true); else open();
	});

	// Клик мимо закрывает только пустое поле: набранный запрос не теряем
	document.addEventListener('click', function (e) {
		if (!isOpen() || input.value.trim() !== '') return;
		if (slot.contains(e.target)) return;
		var sugg = document.getElementById('searchsuggestions');
		if (sugg && sugg.contains(e.target)) return;
		close(false);
	});

	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape' && isOpen()) close(true);
	});
})();
