/* 05.11.2026. Колесо мыши над полем type=number в фокусе: Chrome 147–149 менял число и
   одновременно прокручивал страницу (crbug 508306805), 150+ — при пассивном wheel-слушателе выше.
   Снимаем фокус — число не меняется, страница прокручивается как обычно. */
document.addEventListener('wheel', function (e) {
  var el = document.activeElement;
  if (el && el.type === 'number' && (el === e.target || el.matches(':hover'))) el.blur();
}, { passive: true, capture: true });
