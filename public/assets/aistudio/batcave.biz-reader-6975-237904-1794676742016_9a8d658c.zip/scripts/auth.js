// Sandev/Auth — Magic Link client (event-delegation: works for cloned DLE popups)
(function () {
  'use strict';

  var COOLDOWN_MS = 60 * 1000;
  var lastSentAt = 0;
  var ADMIN_COOKIE = 'magic_test_admin';

  function getCookie(name) {
    var m = document.cookie.match('(^|;)\\s*' + name.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') + '\\s*=\\s*([^;]+)');
    return m ? decodeURIComponent(m[2]) : '';
  }

  // Lazy-fetch dle_login_hash from server when not exposed by main.tpl (e.g. guest 401 page).
  // Result is cached on window.dle_login_hash so subsequent calls return immediately.
  var csrfPromise = null;
  function ensureCsrf() {
    if (window.dle_login_hash) return Promise.resolve(window.dle_login_hash);
    if (csrfPromise) return csrfPromise;
    csrfPromise = boot().then(function (d) { return d.dle_login_hash || ''; });
    return csrfPromise;
  }

  // Вопрос приходит вместе с csrf-токеном и рисуется сразу при раскрытии формы.
  // Ответ сверяется с подписанным токеном, а не с сессией: слот в сессии один,
  // и второй запрос его перезаписывал — на экране оставался прежний вопрос.
  var bootPromise = null;
  function boot() {
    if (bootPromise) return bootPromise;
    // Уникальный параметр обязателен: прокси кэширует ответ по URL и иначе
    // раздаёт всем один вопрос с чужим csrf-хешем.
    var bust = '&_=' + Date.now() + '.' + Math.random().toString(36).slice(2);
    bootPromise = fetch('/engine/plugins/Sandev/Auth/ajax.php?action=csrf' + bust,
                        { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json().catch(function () { return null; }); })
      .then(function (d) { return (d && d.ok && d.data) ? d.data : {}; })
      .catch(function () { return {}; });
    return bootPromise;
  }

  // Поле вопроса вставляется перед кнопкой отправки, токен держим на форме.
  function renderQuestion(form, question, token) {
    if (!form || !question || form.querySelector('.sandev-auth-magic__question')) return;
    if (token) form.dataset.qToken = token;

    var label = document.createElement('label');
    label.className = 'sandev-auth-magic__question';

    var cap = document.createElement('span');
    cap.textContent = question;

    var input = document.createElement('input');
    input.type = 'text';
    input.name = 'question_answer';
    input.required = true;
    input.autocomplete = 'off';
    input.className = 'sandev-auth-magic__input';

    label.appendChild(cap);
    label.appendChild(input);

    var btn = form.querySelector('button[type="submit"]');
    if (btn && btn.parentNode === form) form.insertBefore(label, btn);
    else form.appendChild(label);
  }

  function fillQuestion(form) {
    if (!form) return;
    boot().then(function (d) { renderQuestion(form, d.question, d.question_token); });
  }

  // Скрыть / показать все .sandev-auth-magic блоки в зависимости от test-mode + cookie
  function applyVisibility() {
    var wraps = document.querySelectorAll('.sandev-auth-magic');
    if (!wraps.length) return;
    var hasCookie = getCookie(ADMIN_COOKIE) === '1';
    for (var i = 0; i < wraps.length; i++) {
      var w = wraps[i];
      if (w.dataset.testMode === '1') {
        w.style.display = hasCookie ? '' : 'none';
      } else {
        w.style.display = '';
      }
    }
  }

  function showMsg(form, text, type) {
    var msg = form.parentNode && form.parentNode.parentNode
      ? form.parentNode.parentNode.querySelector('.sandev-auth-magic__msg')
      : null;
    if (!msg) {
      // fallback: search up tree
      var node = form.parentNode;
      while (node && node !== document.body) {
        msg = node.querySelector ? node.querySelector('.sandev-auth-magic__msg') : null;
        if (msg) break;
        node = node.parentNode;
      }
    }
    if (!msg) return;
    msg.textContent = text;
    msg.className = 'sandev-auth-magic__msg sandev-auth-magic__msg--' + type;
    msg.hidden = false;
  }

  function hideMsg(form) {
    showMsg(form, '', 'success');
    // и сразу скрыть
    var node = form.parentNode;
    while (node && node !== document.body) {
      var m = node.querySelector ? node.querySelector('.sandev-auth-magic__msg') : null;
      if (m) { m.hidden = true; break; }
      node = node.parentNode;
    }
  }

  // Ленивая подгрузка Turnstile api.js (render=explicit). Дедуп: переиспользует уже
  // вставленный тег (напр. со страницы регистрации). Resolve(true) когда window.turnstile готов.
  var tsScriptPromise = null;
  function ensureTurnstileScript() {
    if (typeof window.turnstile !== 'undefined') return Promise.resolve(true);
    if (tsScriptPromise) return tsScriptPromise;
    tsScriptPromise = new Promise(function (resolve) {
      function poll(tries) {
        if (typeof window.turnstile !== 'undefined') return resolve(true);
        if (tries <= 0) return resolve(false);
        setTimeout(function () { poll(tries - 1); }, 100);
      }
      var existing = document.querySelector('script[src*="turnstile/v0/api.js"]');
      if (existing) { poll(50); return; }
      var s = document.createElement('script');
      s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      s.async = true; s.defer = true;
      s.onload = function () { poll(50); };
      s.onerror = function () { resolve(false); };
      document.head.appendChild(s);
    });
    return tsScriptPromise;
  }

  // Auto-render (фон): рендерим виджет заранее (managed, interaction-only) — токен готовится
  // в фоне и кладётся в holder._token. На сабмите берём готовый токен. Так надёжнее, чем
  // execution:'execute' (который у нас не догенерял токен → turnstile_failed у всех).
  function prepareWidget(holder) {
    if (!holder || typeof window.turnstile === 'undefined' || holder._wid != null) return;
    holder._token = '';
    holder._ready = new Promise(function (resolve) { holder._resolve = resolve; });
    try {
      holder._wid = window.turnstile.render(holder, {
        sitekey: holder.getAttribute('data-sitekey'),
        action: holder.getAttribute('data-action') || 'magiclink',
        appearance: 'interaction-only',
        callback: function (t) { holder._token = t || ''; if (holder._resolve) { holder._resolve(holder._token); holder._resolve = null; } },
        'error-callback': function () { holder._token = ''; if (holder._resolve) { holder._resolve(''); holder._resolve = null; } },
        'expired-callback': function () { holder._token = ''; try { window.turnstile.reset(holder._wid); } catch (_) {} }
      });
    } catch (_) {}
  }

  // Прогрев формы: грузим скрипт и рендерим её виджет (вызывать, когда форма видима).
  function warm(form) {
    if (!form) return;
    ensureTurnstileScript().then(function (ready) {
      if (ready && typeof window.turnstile !== 'undefined') prepareWidget(form.querySelector('.cf-turnstile'));
    });
  }

  // На сабмите: вернуть готовый токен (ждём фоновую проверку до ~8с).
  // null => виджета/скрипта нет на странице (сервер решает fail-open).
  function turnstileToken(form) {
    var holder = form.querySelector('.cf-turnstile');
    if (!holder) return Promise.resolve(null);
    return ensureTurnstileScript().then(function (ready) {
      if (!ready || typeof window.turnstile === 'undefined') return null;
      prepareWidget(holder);
      if (holder._token) return holder._token;
      return Promise.race([
        holder._ready || Promise.resolve(''),
        new Promise(function (res) { setTimeout(function () { res(holder._token || ''); }, 8000); })
      ]);
    });
  }

  // Токен одноразовый — после использования сбрасываем виджет, чтобы подготовить новый.
  function resetWidget(form) {
    var holder = form && form.querySelector('.cf-turnstile');
    if (!holder || holder._wid == null || typeof window.turnstile === 'undefined') return;
    try { window.turnstile.reset(holder._wid); } catch (_) {}
    holder._token = '';
    holder._ready = new Promise(function (resolve) { holder._resolve = resolve; });
  }

  function handleSubmit(form) {
    var now = Date.now();
    if (now - lastSentAt < COOLDOWN_MS) {
      var left = Math.ceil((COOLDOWN_MS - (now - lastSentAt)) / 1000);
      showMsg(form, 'Please wait ' + left + ' seconds before trying again.', 'warn');
      return;
    }

    var email = (form.email && form.email.value ? form.email.value : '').trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showMsg(form, 'Enter a valid email.', 'error');
      return;
    }

    // Honeypot — read hidden field value (must be empty for humans)
    var honeypot = (form.website && form.website.value ? form.website.value : '');

    var btn = form.querySelector('button[type="submit"]');
    var originalText = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = 'Checking…'; }
    hideMsg(form);

    var answerEl = form.elements['question_answer'];
    var answer = answerEl ? answerEl.value.trim() : '';
    if (!answer) {
      showMsg(form, 'Please answer the check question.', 'error');
      if (btn) { btn.disabled = false; btn.textContent = originalText; }
      return;
    }

    boot().then(function (d) {
      // Хеш берём из ответа сервера: движок считает его по другой формуле,
      // когда у посетителя есть cookie прошлых входов.
      var csrf = d.dle_login_hash || '';
      if (!csrf) {
        var hidden = document.querySelector('input[name="dle_login_hash"]');
        if (hidden) csrf = hidden.value;
      }
      if (btn) btn.textContent = 'Sending…';
      return fetch('/engine/plugins/Sandev/Auth/ajax.php?action=send', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email, dle_login_hash: csrf, website: honeypot,
                             question_answer: answer, question_token: form.dataset.qToken || '' })
    })
      .then(function (r) { return r.json().catch(function () { return null; }); })
      .then(function (data) {
        if (!data) {
          showMsg(form, 'The server returned an invalid response. Please try again later.', 'error');
          return;
        }
        if (data.ok) {
          lastSentAt = Date.now();
          showMsg(form, (data.data && data.data.message) || 'Link sent.', 'success');
          form.email.value = '';
        } else {
          var errMap = {
            'csrf_invalid':       'Your session has expired. Refresh the page.',
            'rate_limited':       'Too many attempts. Please try again in an hour.',
            'invalid_email':      'Invalid email format.',
            'feature_disabled':   'Passwordless login is temporarily disabled.',
            'feature_in_test':    'Passwordless login is in test mode (admin only).',
            'https_required':     'This feature only works over HTTPS.',
            'method_not_allowed': 'Invalid request method.',
            'invalid_json':       'Invalid data format.',
            'turnstile_failed':   'Verification failed. Please try again.'
          };
          showMsg(form, errMap[data.error] || data.message || 'Something went wrong.', 'error');
        }
      })
      .catch(function () {
        showMsg(form, 'Network error. Check your connection.', 'error');
      })
      .finally(function () {
        if (btn) { btn.disabled = false; btn.textContent = originalText; }
        resetWidget(form);  // токен одноразовый — готовим свежий для следующей попытки
      });
    });
  }

  // Event-delegation на document — ловит submit на ЛЮБОЙ форме .sandev-auth-magic-form,
  // включая клонированные DLE-popup'ы.
  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || !form.classList || !form.classList.contains('sandev-auth-magic-form')) return;
    e.preventDefault();
    handleSubmit(form);
  }, true);

  // Accordion-toggle для compact UX (форма свёрнута до клика).
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.classList || !t.classList.contains('js-sandev-auth-toggle')) return;
    e.preventDefault();
    var wrap = t.closest('.sandev-auth-magic');
    if (!wrap) return;
    var expand = wrap.querySelector('.sandev-auth-magic__expand');
    if (!expand) return;
    if (expand.hidden) {
      expand.hidden = false;
      fillQuestion(expand.querySelector('.sandev-auth-magic-form'));  // вопрос виден до нажатия
      t.classList.add('sandev-auth-magic__toggle--open');
      var input = expand.querySelector('input[name="email"]');
      if (input) setTimeout(function () { try { input.focus(); } catch (_) {} }, 0);
    } else {
      expand.hidden = true;
      t.classList.remove('sandev-auth-magic__toggle--open');
    }
  }, true);

  // Переключение экранов попапа: основная форма логин/пароль <-> альтернативные способы.
  document.addEventListener('click', function (e) {
    var t = e.target && e.target.closest ? e.target.closest('.js-auth-show-alt, .js-auth-back') : null;
    if (!t) return;
    e.preventDefault();
    var box = t.closest('.login') || t.closest('.login-box') || document;
    var primary = box.querySelector('.js-auth-view-primary');
    var alt = box.querySelector('.js-auth-view-alt');
    if (!primary || !alt) return;
    var toAlt = t.classList.contains('js-auth-show-alt');
    primary.hidden = toAlt;
    alt.hidden = !toAlt;
    if (toAlt) warm(alt.querySelector('.sandev-auth-magic-form'));  // прогрев Turnstile при показе альтернатив
  }, true);

  // Применяем visibility при загрузке и при клике на login-toggle (DLE клонирует popup тогда).
  function setup() {
    applyVisibility();
    // Прогрев видимых форм (напр. standalone login-страница, где форма не в аккордеоне)
    var forms = document.querySelectorAll('.sandev-auth-magic-form');
    for (var i = 0; i < forms.length; i++) {
      if (forms[i].offsetParent !== null) warm(forms[i]);
    }
    // DLE клонирует popup при клике на .js-show-login — повторяем visibility на каждом клике
    document.addEventListener('click', function (e) {
      var t = e.target;
      while (t && t !== document.body) {
        if (t.classList && t.classList.contains('js-show-login')) {
          // Даём DOM время отрендерить клон, потом применяем visibility
          setTimeout(applyVisibility, 50);
          setTimeout(applyVisibility, 200);
          break;
        }
        t = t.parentNode;
      }
    }, true);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setup);
  } else {
    setup();
  }
})();


/* --- Notice: mail providers that currently reject our mail ----------------
   Microsoft (hotmail/outlook/live/msn) blocks our sending IPs (S3140) and
   Apple (icloud/me/mac) rejects via Proofpoint, so a confirmation or sign-in
   link sent there never arrives. We warn while the user types and never block
   submission. The same handler catches common domain typos, which otherwise
   turn into hard bounces and hurt sender reputation. */
(function () {
  'use strict';

  var MS_PREFIX = /^(hotmail|outlook|live|msn)\./;
  var APPLE = { 'icloud.com': 1, 'me.com': 1, 'mac.com': 1 };
  var TYPOS = {
    'gmail.con': 'gmail.com', 'gmail.co': 'gmail.com', 'gmail.cm': 'gmail.com',
    'gmai.com': 'gmail.com', 'gmial.com': 'gmail.com', 'gmaill.com': 'gmail.com',
    'hotmial.com': 'hotmail.com', 'hotmai.com': 'hotmail.com', 'outlok.com': 'outlook.com',
    'yaho.com': 'yahoo.com', 'yahoo.con': 'yahoo.com', 'iclod.com': 'icloud.com',
    'mai.ru': 'mail.ru', 'mail.ur': 'mail.ru', 'yandex.ur': 'yandex.ru',
    'ranbler.ru': 'rambler.ru', 'protonmai.com': 'protonmail.com'
  };
  var TEXT = {
    blocked: 'Mail to Hotmail, Outlook, Live and iCloud is not being delivered right now — the link will not arrive. Please use another address (Gmail, Yahoo, Proton).',
    typo: 'Did you mean %s?'
  };

  var NOTE_CLASS = 'sd-mail-note';
  var timer = null;

  function domainOf(value) {
    var v = String(value || '').trim().toLowerCase();
    var at = v.lastIndexOf('@');
    return at > 0 ? v.slice(at + 1) : '';
  }

  function verdict(domain) {
    if (!domain) return null;
    if (TYPOS[domain]) return { kind: 'tip', text: TEXT.typo.replace('%s', TYPOS[domain]) };
    if (MS_PREFIX.test(domain)) return { kind: 'warn', text: TEXT.blocked };
    if (APPLE[domain]) return { kind: 'warn', text: TEXT.blocked };
    return null;
  }

  function noteFor(input, create) {
    var next = input.nextElementSibling;
    if (next && next.classList && next.classList.contains(NOTE_CLASS)) return next;
    if (!create) return null;
    var el = document.createElement('div');
    el.className = NOTE_CLASS;
    el.setAttribute('role', 'status');
    input.insertAdjacentElement('afterend', el);
    return el;
  }

  function render(input) {
    var v = verdict(domainOf(input.value));
    var note = noteFor(input, !!v);
    if (!note) return;
    if (!v) { note.remove(); return; }
    note.textContent = v.text;
    note.className = NOTE_CLASS + ' ' + NOTE_CLASS + '--' + v.kind;
  }

  function isEmailInput(el) {
    return el && el.tagName === 'INPUT' && el.name === 'email';
  }

  document.addEventListener('input', function (e) {
    if (!isEmailInput(e.target)) return;
    clearTimeout(timer);
    var input = e.target;
    timer = setTimeout(function () { render(input); }, 400);
  });

  document.addEventListener('blur', function (e) {
    if (isEmailInput(e.target)) render(e.target);
  }, true);
})();
