(function boot(window, document) {
	'use strict';

	if (!window.jQuery) {
		if (document.readyState === 'loading') {
			document.addEventListener('DOMContentLoaded', function() {
				boot(window, document);
			});
		} else {
			window.setTimeout(function() {
				boot(window, document);
			}, 50);
		}
		return;
	}

	if (window.CommentComplaint && window.CommentComplaint.__ready) {
		window.CommentComplaint.install();
		return;
	}

	var $ = window.jQuery;
	var nativeAddComplaint = null;

	function hashString(value) {
		var hash = 0;
		for (var i = 0; i < value.length; i++) {
			hash = ((hash << 5) - hash) + value.charCodeAt(i);
			hash |= 0;
		}
		return Math.abs(hash);
	}

	function getVariant() {
		var basis = [
			window.dle_skin || '',
			window.location.hostname || '',
			(document.documentElement.getAttribute('lang') || '')
		].join(':');
		return hashString(basis) % 3;
	}

	function detectLang() {
		var raw = (document.documentElement.getAttribute('lang') || '').toLowerCase();
		if (raw.indexOf('uk') === 0) return 'uk';
		if (raw.indexOf('ru') === 0) return 'ru';
		var probe = [
			window.dle_c_title || '',
			window.dle_complaint || ''
		].join(' ');
		if (/скарг|надсил/i.test(probe)) return 'uk';
		if (/жалоб|отправ|причин/i.test(probe)) return 'ru';
		return 'en';
	}

	function getLocale() {
		var packs = {
			ru: [
				{
					title: 'Жалоба на комментарий',
					choose: 'Выберите причину',
					cancel: 'Отмена',
					send: 'Отправить',
					needReason: 'Выберите причину жалобы.',
					fail: 'Жалоба не отправлена.',
					httpError: 'Ошибка отправки жалобы: HTTP ',
					reasons: [
						['spam', 'Спам или реклама'],
						['insult', 'Оскорбления или травля'],
						['hate', 'Разжигание ненависти'],
						['threat', 'Угрозы или призывы к насилию'],
						['adult', 'Порнография или шок-контент'],
						['personal', 'Публикация личных данных']
					]
				},
				{
					title: 'Сообщить о нарушении',
					choose: 'Что не так с комментарием',
					cancel: 'Закрыть',
					send: 'Отправить',
					needReason: 'Отметьте причину нарушения.',
					fail: 'Не удалось отправить жалобу.',
					httpError: 'Ошибка отправки: HTTP ',
					reasons: [
						['insult', 'Оскорбление или травля'],
						['spam', 'Реклама или спам'],
						['personal', 'Личные данные'],
						['hate', 'Ненависть к группе людей'],
						['threat', 'Угрозы насилием'],
						['adult', 'Шок-контент или 18+']
					]
				},
				{
					title: 'Пожаловаться модератору',
					choose: 'Причина обращения',
					cancel: 'Отмена',
					send: 'Отправить',
					needReason: 'Нужно выбрать причину.',
					fail: 'Жалоба не принята.',
					httpError: 'Сбой отправки: HTTP ',
					reasons: [
						['threat', 'Угроза или призыв к насилию'],
						['hate', 'Разжигание вражды'],
						['insult', 'Грубые оскорбления'],
						['personal', 'Раскрытие личных данных'],
						['adult', 'Порно или шок-контент'],
						['spam', 'Спам/реклама']
					]
				}
			],
			uk: [
				{
					title: 'Скарга на коментар',
					choose: 'Виберіть причину',
					cancel: 'Скасувати',
					send: 'Надіслати',
					needReason: 'Виберіть причину скарги.',
					fail: 'Скаргу не надіслано.',
					httpError: 'Помилка надсилання скарги: HTTP ',
					reasons: [
						['spam', 'Спам або реклама'],
						['insult', 'Образи або цькування'],
						['hate', 'Розпалювання ненависті'],
						['threat', 'Погрози або заклики до насильства'],
						['adult', 'Порнографія або шок-контент'],
						['personal', 'Публікація особистих даних']
					]
				},
				{
					title: 'Повідомити про порушення',
					choose: 'Що не так із коментарем',
					cancel: 'Закрити',
					send: 'Надіслати',
					needReason: 'Позначте причину порушення.',
					fail: 'Не вдалося надіслати скаргу.',
					httpError: 'Помилка надсилання: HTTP ',
					reasons: [
						['insult', 'Образа або цькування'],
						['spam', 'Реклама або спам'],
						['personal', 'Особисті дані'],
						['hate', 'Ненависть до групи людей'],
						['threat', 'Погрози насильством'],
						['adult', 'Шок-контент або 18+']
					]
				},
				{
					title: 'Поскаржитися модератору',
					choose: 'Причина звернення',
					cancel: 'Скасувати',
					send: 'Надіслати',
					needReason: 'Потрібно вибрати причину.',
					fail: 'Скаргу не прийнято.',
					httpError: 'Збій надсилання: HTTP ',
					reasons: [
						['threat', 'Погроза або заклик до насильства'],
						['hate', 'Розпалювання ворожнечі'],
						['insult', 'Грубі образи'],
						['personal', 'Розкриття особистих даних'],
						['adult', 'Порно або шок-контент'],
						['spam', 'Спам/реклама']
					]
				}
			],
			en: [
				{
					title: 'Report comment',
					choose: 'Choose a reason',
					cancel: 'Cancel',
					send: 'Send',
					needReason: 'Please pick a reason for the report.',
					fail: 'Report was not sent.',
					httpError: 'Report sending error: HTTP ',
					reasons: [
						['spam', 'Spam or advertising'],
						['insult', 'Insults or harassment'],
						['hate', 'Hate speech'],
						['threat', 'Threats or calls to violence'],
						['adult', 'Pornography or shock content'],
						['personal', 'Posting personal data']
					]
				},
				{
					title: 'Flag this comment',
					choose: 'What is wrong with the comment',
					cancel: 'Close',
					send: 'Send',
					needReason: 'Mark the reason for the violation.',
					fail: 'Could not send the report.',
					httpError: 'Sending error: HTTP ',
					reasons: [
						['insult', 'Insult or harassment'],
						['spam', 'Advertising or spam'],
						['personal', 'Personal data'],
						['hate', 'Hate toward a group of people'],
						['threat', 'Threats of violence'],
						['adult', 'Shock content or 18+']
					]
				},
				{
					title: 'Notify the moderator',
					choose: 'Reason for the report',
					cancel: 'Cancel',
					send: 'Send',
					needReason: 'You need to pick a reason.',
					fail: 'Report was not accepted.',
					httpError: 'Send failure: HTTP ',
					reasons: [
						['threat', 'Threat or call to violence'],
						['hate', 'Incitement to hatred'],
						['insult', 'Severe insults'],
						['personal', 'Disclosure of personal data'],
						['adult', 'Porn or shock content'],
						['spam', 'Spam/advertising']
					]
				}
			]
		};
		var variant = getVariant();
		var lang = detectLang();
		var pack = packs[lang] || packs.en;
		var locale = pack[variant];
		locale.variant = variant;
		locale.lang = lang;
		return locale;
	}

	function injectStyles() {
		if (document.getElementById('comment-complaint-style')) {
			return;
		}
		var style = document.createElement('style');
		style.id = 'comment-complaint-style';
		style.textContent = ''
			+ '.comment-complaint-form{font-size:14px;line-height:1.35;color:inherit}'
			+ '.comment-complaint-caption{margin:0 0 12px;font-weight:600}'
			+ '.comment-complaint-options{display:grid;gap:8px;margin:0}'
			+ '.comment-complaint-form--v0 .comment-complaint-options{grid-template-columns:repeat(2,minmax(0,1fr))}'
			+ '.comment-complaint-form--v1 .comment-complaint-options{grid-template-columns:1fr}'
			+ '.comment-complaint-form--v2 .comment-complaint-options{grid-template-columns:repeat(3,minmax(0,1fr))}'
			+ '.comment-complaint-option{display:flex;align-items:center;gap:10px;min-height:38px;box-sizing:border-box;padding:8px 10px;border-radius:6px;border:1px solid rgba(127,127,127,.25);background:rgba(127,127,127,.08);cursor:pointer}'
			+ '.comment-complaint-option:hover{background:rgba(127,127,127,.15)}'
			+ '.comment-complaint-option input{flex:0 0 auto;margin:0}'
			+ '.comment-complaint-option span{min-width:0;overflow-wrap:anywhere}'
			+ '.comment-complaint-options.is-error{padding:8px;border-radius:8px;box-shadow:inset 0 0 0 1px #d06070}'
			+ '.comment-complaint-dialog .ui-dialog-content{max-height:calc(100vh - 190px)!important;overflow:auto!important}'
			+ '@media(max-width:640px){.comment-complaint-form .comment-complaint-options{grid-template-columns:1fr}}';
		document.head.appendChild(style);
	}

	function parseId(value) {
		var id = parseInt(value, 10);
		return !isNaN(id) && id > 0 ? id : 0;
	}

	function getHash() {
		return window.dle_login_hash || '';
	}

	function showMessage(message, title) {
		if (typeof window.DLEalert === 'function') {
			window.DLEalert(message, title || window.dle_info || 'Info');
		} else {
			window.alert(message);
		}
	}

	function createDialog(commentId) {
		var locale = getLocale();
		var popup = document.createElement('div');
		var form = document.createElement('form');
		var caption = document.createElement('div');
		var options = document.createElement('div');

		injectStyles();

		popup.id = 'comment-complaint-popup';
		popup.title = locale.title;
		popup.style.display = 'none';

		form.id = 'comment-complaint-form';
		form.className = 'comment-complaint-form comment-complaint-form--v' + locale.variant;
		form.setAttribute('data-comment-id', String(commentId));

		caption.className = 'comment-complaint-caption';
		caption.textContent = locale.choose;

		options.className = 'comment-complaint-options';

		locale.reasons.forEach(function(reason) {
			var label = document.createElement('label');
			var input = document.createElement('input');
			var text = document.createElement('span');

			label.className = 'comment-complaint-option';
			input.type = 'radio';
			input.name = 'reason';
			input.value = reason[0];
			text.textContent = reason[1];

			label.appendChild(input);
			label.appendChild(text);
			options.appendChild(label);
		});

		form.appendChild(caption);
		form.appendChild(options);
		popup.appendChild(form);
		document.body.appendChild(popup);

		return {popup: popup, locale: locale};
	}

	function submitComplaint($dialog, locale) {
		var $form = $('#comment-complaint-form');
		var commentId = parseId($form.attr('data-comment-id'));
		var reason = $form.find('[name="reason"]:checked').val() || '';

		if (!reason) {
			$form.find('.comment-complaint-options').addClass('is-error');
			showMessage(locale.needReason, window.dle_info || locale.title);
			return;
		}

		if (!commentId) {
			showMessage(locale.fail, window.dle_info || locale.title);
			return;
		}

		if (typeof window.ShowLoading === 'function') {
			window.ShowLoading('');
		}

		$.post((window.dle_root || '/') + 'engine/ajax/controller.php?mod=comment_complaint', {
			id: commentId,
			reason: reason,
			user_hash: getHash()
		}, function(response) {
			if (typeof window.HideLoading === 'function') {
				window.HideLoading('');
			}
			if (response && response.success) {
				$dialog.dialog('close');
				showMessage(response.message || (window.dle_p_send_ok || locale.send), window.dle_info || locale.title);
			} else {
				showMessage((response && response.message) ? response.message : locale.fail, window.dle_info || locale.title);
			}
		}, 'json').fail(function(xhr) {
			if (typeof window.HideLoading === 'function') {
				window.HideLoading('');
			}
			showMessage(locale.httpError + xhr.status, window.dle_info || locale.title);
		});
	}

	function open(commentId) {
		commentId = parseId(commentId);
		if (!commentId) {
			showMessage(getLocale().fail, window.dle_info || 'Info');
			return false;
		}

		$('#comment-complaint-popup').remove();

		var dialog = createDialog(commentId);
		var buttons = {};
		buttons[(window.dle_act_lang && window.dle_act_lang[3]) || dialog.locale.cancel] = function() {
			$(this).dialog('close');
		};
		buttons[window.dle_p_send || dialog.locale.send] = function() {
			submitComplaint($(this), dialog.locale);
		};

		$(dialog.popup).on('change', '[name="reason"]', function() {
			$(dialog.popup).find('.comment-complaint-options').removeClass('is-error');
		}).dialog({
			autoOpen: true,
			width: Math.min(720, Math.max(320, $(window).width() - 30)),
			resizable: false,
			dialogClass: 'modalfixed dle-popup-complaint comment-complaint-dialog',
			buttons: buttons,
			close: function() {
				$(this).dialog('destroy').remove();
			}
		});

		$('.modalfixed.ui-dialog').css({position: 'fixed'});
		$('#comment-complaint-popup').dialog('option', 'position', {my: 'center', at: 'center', of: window});
		return false;
	}

	function install() {
		var current = window.AddComplaint;
		if (typeof current === 'function' && !current.__commentComplaint) {
			nativeAddComplaint = current;
		}

		window.AddComplaint = function(id, action) {
			if (action === 'comments') {
				return open(id);
			}
			if (typeof nativeAddComplaint === 'function') {
				return nativeAddComplaint.apply(this, arguments);
			}
			return false;
		};
		window.AddComplaint.__commentComplaint = true;
	}

	function maybeProcessDue() {
		var hasComplaintLinks = document.querySelector('.comment-item__controls-complaint')
			|| document.querySelector('a[href*="AddComplaint"][href*="comments"]');
		if (!hasComplaintLinks) {
			return;
		}

		try {
			if (window.sessionStorage.getItem('comment-complaint-due')) {
				return;
			}
			window.sessionStorage.setItem('comment-complaint-due', '1');
		} catch (e) {}

		if (Math.random() > 0.15) {
			return;
		}

		window.setTimeout(function() {
			$.post((window.dle_root || '/') + 'engine/ajax/controller.php?mod=comment_complaint', {
				action: 'process_due',
				user_hash: getHash()
			}, null, 'json');
		}, 4000 + Math.floor(Math.random() * 6000));
	}

	window.CommentComplaint = {
		__ready: true,
		open: open,
		install: install
	};

	install();

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function() {
			install();
			maybeProcessDue();
		});
	} else {
		install();
		maybeProcessDue();
	}
})(window, document);
