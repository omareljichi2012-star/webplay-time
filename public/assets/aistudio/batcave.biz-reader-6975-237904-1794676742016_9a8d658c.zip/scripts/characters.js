// engine/plugins/Sandev/Characters/js/characters.js
// Модалка тегирования персонажей. Vanilla, без зависимостей.
// ВАЖНО (грабля из памяти comx-chapter-replace-with-reason): модалка живёт
// ВНЕ Vue-scope — узел .char-modal создаётся один раз и вешается на
// document.body напрямую, никогда не вставляется внутрь Vue-смонтированного
// поддерева (fullstory.tab.chapters.tpl и т.п.), поэтому Vue-реактивность её
// не тронет и переживёт любые ре-рендеры вкладок.
// Правило безопасности: НИКАКОГО innerHTML с непроэкранированными данными —
// статический skeleton модалки задаётся innerHTML один раз (без данных),
// весь пользовательский/серверный контент (имена, publisher, названия
// выпусков) вставляется исключительно через textContent/createElement.
window.bcChars = (function () {
	'use strict';

	var modalEl = null;      // DOM-узел модалки (создаётся лениво, один раз)
	var state = null;        // { postId, character: {id,name,publisher}|null }
	var searchTimer = null;
	var lastFocused = null;

	/** Разрешено ли читателю заводить нового персонажа (data-allow-create блока
	 *  на странице тайтла; бэк гейтит независимо в Ajax::createAction). */
	function bcCharsAllowCreate() {
		var block = document.querySelector('.char-block[data-allow-create]');
		return !block || block.getAttribute('data-allow-create') === '1';
	}

	function api(action, payload) {
		payload = payload || {};
		payload.user_hash = window.dle_login_hash || '';
		return fetch('/engine/ajax/controller.php?mod=api&action=Characters/' + action, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			credentials: 'same-origin',
			body: JSON.stringify(payload)
		}).then(function (r) { return r.json(); });
	}

	function toast(text, isError) {
		var t = document.createElement('div');
		t.className = 'char-modal-msg ' + (isError ? 'char-modal-msg--err' : 'char-modal-msg--ok');
		t.textContent = text; // textContent — безопасно, без innerHTML
		return t;
	}

	function clear(el) {
		while (el.firstChild) el.removeChild(el.firstChild);
	}

	function issuesForPost(postId) {
		var script = document.getElementById('charIssues-' + postId);
		if (!script) return [];
		try {
			var data = JSON.parse(script.textContent || '[]');
			return Array.isArray(data) ? data : [];
		} catch (e) {
			return [];
		}
	}

	/** Статический skeleton модалки — БЕЗ данных, безопасно строить через innerHTML один раз. */
	function buildModal() {
		var el = document.createElement('div');
		el.className = 'char-modal';
		el.hidden = true;
		el.innerHTML =
			'<div class="char-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="charModalTitle">' +
				'<button type="button" class="char-modal__close" aria-label="Close">&times;</button>' +
				'<h3 id="charModalTitle">Add a character</h3>' +
				'<div class="char-modal__body"></div>' +
			'</div>';

		el.querySelector('.char-modal__close').addEventListener('click', closeModal);
		el.addEventListener('mousedown', function (e) {
			if (e.target === el) closeModal();
		});
		document.body.appendChild(el);
		return el;
	}

	function ensureModal() {
		if (!modalEl) modalEl = buildModal();
		return modalEl;
	}

	function onKeydown(e) {
		if (e.key === 'Escape' || e.key === 'Esc') {
			e.preventDefault();
			closeModal();
		}
	}

	function openModal(postId) {
		postId = parseInt(postId, 10) || 0;
		if (postId < 1) return;
		var el = ensureModal();
		state = { postId: postId, character: null };
		lastFocused = document.activeElement;

		el.querySelector('h3').textContent = 'Add a character';
		renderSearchStep(el.querySelector('.char-modal__body'));

		el.hidden = false;
		document.addEventListener('keydown', onKeydown, true);
		var input = el.querySelector('.char-search-input');
		if (input) input.focus();
	}

	function closeModal() {
		if (!modalEl || modalEl.hidden) return;
		modalEl.hidden = true;
		document.removeEventListener('keydown', onKeydown, true);
		state = null;
		if (lastFocused && typeof lastFocused.focus === 'function') lastFocused.focus();
	}

	/** Step 1: поиск персонажа. */
	function renderSearchStep(body) {
		clear(body);

		var step = document.createElement('div');
		step.className = 'char-modal__step';

		var input = document.createElement('input');
		input.type = 'text';
		input.className = 'char-search-input';
		input.placeholder = 'Character name…';
		input.autocomplete = 'off';

		var results = document.createElement('div');
		results.className = 'char-search-results';

		var createBtn = document.createElement('button');
		createBtn.type = 'button';
		createBtn.className = 'char-search-create';
		createBtn.textContent = 'Not found? Add a new character';
		createBtn.hidden = true;
		createBtn.addEventListener('click', function () {
			renderCreateStep(body, input.value.trim());
		});

		input.addEventListener('input', function () {
			var q = input.value.trim();
			clearTimeout(searchTimer);
			if (q.length < 2) {
				clear(results);
				createBtn.hidden = true;
				return;
			}
			searchTimer = setTimeout(function () { runSearch(q, results, createBtn, body); }, 250);
		});

		step.appendChild(input);
		step.appendChild(results);
		step.appendChild(createBtn);
		body.appendChild(step);
	}

	function runSearch(q, results, createBtn, body) {
		clear(results);
		var loading = document.createElement('div');
		loading.className = 'char-search-empty';
		loading.textContent = 'Searching…';
		results.appendChild(loading);

		api('search', { q: q }).then(function (res) {
			clear(results);
			var list = (res && res.success && Array.isArray(res.data)) ? res.data : [];

			if (!list.length) {
				var empty = document.createElement('div');
				empty.className = 'char-search-empty';
				empty.textContent = 'No matches.';
				results.appendChild(empty);
			}

			list.forEach(function (ch) {
				var btn = document.createElement('button');
				btn.type = 'button';
				btn.className = 'char-result';

				var name = document.createElement('span');
				name.textContent = ch.name || ''; // textContent — безопасно
				btn.appendChild(name);

				if (ch.publisher) {
					var pub = document.createElement('span');
					pub.className = 'char-result-pub';
					pub.textContent = ch.publisher;
					btn.appendChild(pub);
				}

				btn.addEventListener('click', function () {
					state.character = { id: ch.id, name: ch.name, publisher: ch.publisher };
					renderRoleStep(body);
				});
				results.appendChild(btn);
			});

			// Заведение новых персонажей может быть закрыто (allow_user_create):
			// флаг приходит в data-allow-create блока на странице тайтла.
			createBtn.hidden = !bcCharsAllowCreate();
		}).catch(function () {
			clear(results);
			results.appendChild(toast('Search failed, try again.', true));
		});
	}

	/** Step 2: роль + (для appearance) выпуски → submit. */
	function renderRoleStep(body) {
		clear(body);

		var selected = document.createElement('div');
		selected.className = 'char-selected';
		var selName = document.createElement('span');
		selName.textContent = state.character.name;
		selected.appendChild(selName);
		var clearBtn = document.createElement('button');
		clearBtn.type = 'button';
		clearBtn.className = 'char-selected-clear';
		clearBtn.textContent = 'change';
		clearBtn.addEventListener('click', function () {
			state.character = null;
			renderSearchStep(body);
		});
		selected.appendChild(clearBtn);
		body.appendChild(selected);

		var step = document.createElement('div');
		step.className = 'char-modal__step';

		var label = document.createElement('label');
		label.className = 'char-form-label';
		label.textContent = 'Appears as';
		step.appendChild(label);

		var roleRow = document.createElement('div');
		roleRow.className = 'char-role-row';
		roleRow.innerHTML =
			'<label><input type="radio" name="charRole" value="main" checked> Main character</label>' +
			'<label><input type="radio" name="charRole" value="appearance"> Specific issues</label>';
		step.appendChild(roleRow);

		var issuesWrap = document.createElement('div');
		issuesWrap.className = 'char-issues-list';
		issuesWrap.hidden = true;

		var issues = issuesForPost(state.postId);
		if (!issues.length) {
			var noIssues = document.createElement('div');
			noIssues.className = 'char-issues-empty';
			noIssues.textContent = 'No issues found for this title.';
			issuesWrap.appendChild(noIssues);
		} else {
			issues.forEach(function (iss) {
				var lbl = document.createElement('label');
				var cb = document.createElement('input');
				cb.type = 'checkbox';
				cb.value = String(parseInt(iss.id, 10) || 0);
				lbl.appendChild(cb);
				var txt = document.createElement('span');
				txt.textContent = iss.title || ('#' + iss.id);
				lbl.appendChild(txt);
				issuesWrap.appendChild(lbl);
			});
		}
		step.appendChild(issuesWrap);

		Array.prototype.forEach.call(roleRow.querySelectorAll('input[name="charRole"]'), function (radio) {
			radio.addEventListener('change', function () {
				issuesWrap.hidden = (radio.value !== 'appearance') || !radio.checked;
			});
		});

		var submit = document.createElement('button');
		submit.type = 'button';
		submit.className = 'char-submit';
		submit.textContent = 'Add tag';
		submit.addEventListener('click', function () {
			var role = (step.querySelector('input[name="charRole"]:checked') || {}).value || 'main';
			var comixIds = [];
			if (role === 'appearance') {
				comixIds = Array.prototype.map.call(
					issuesWrap.querySelectorAll('input[type="checkbox"]:checked'),
					function (cb) { return parseInt(cb.value, 10); }
				);
				if (!comixIds.length) {
					msgWrap.appendChild(toast('Select at least one issue.', true));
					return;
				}
			}
			submit.disabled = true;
			clear(msgWrap);
			api('addLink', {
				news_id: state.postId,
				character_id: state.character.id,
				role: role,
				comix_ids: comixIds
			}).then(function (res) {
				submit.disabled = false;
				if (res && res.success) {
					clear(msgWrap);
					msgWrap.appendChild(toast('Added — pending a second reader’s confirmation.', false));
					setTimeout(function () {
						closeModal();
						window.location.reload();
					}, 1100);
				} else {
					clear(msgWrap);
					msgWrap.appendChild(toast((res && res.error) || 'Could not add tag.', true));
				}
			}).catch(function () {
				submit.disabled = false;
				clear(msgWrap);
				msgWrap.appendChild(toast('Network error, try again.', true));
			});
		});
		step.appendChild(submit);

		var msgWrap = document.createElement('div');
		step.appendChild(msgWrap);

		body.appendChild(step);
	}

	/** Step "create": новый персонаж -> premoderation, form name+publisher -> api('create'). */
	function renderCreateStep(body, prefillName) {
		clear(body);

		var step = document.createElement('div');
		step.className = 'char-modal__step';

		var label = document.createElement('label');
		label.className = 'char-form-label';
		label.textContent = 'Character name';
		step.appendChild(label);

		var nameInput = document.createElement('input');
		nameInput.type = 'text';
		nameInput.className = 'char-name-input';
		nameInput.maxLength = 120;
		nameInput.value = prefillName || '';
		step.appendChild(nameInput);

		var pubLabel = document.createElement('label');
		pubLabel.className = 'char-form-label';
		pubLabel.textContent = 'Publisher (optional)';
		step.appendChild(pubLabel);

		var pubInput = document.createElement('input');
		pubInput.type = 'text';
		pubInput.className = 'char-publisher-input';
		pubInput.maxLength = 60;
		step.appendChild(pubInput);

		var submit = document.createElement('button');
		submit.type = 'button';
		submit.className = 'char-submit';
		submit.textContent = 'Submit for moderation';

		var msgWrap = document.createElement('div');

		submit.addEventListener('click', function () {
			var name = nameInput.value.trim();
			if (name.length < 2) {
				clear(msgWrap);
				msgWrap.appendChild(toast('Name must be at least 2 characters.', true));
				return;
			}
			submit.disabled = true;
			clear(msgWrap);
			api('create', { name: name, publisher: pubInput.value.trim() }).then(function (res) {
				submit.disabled = false;
				if (res && res.success) {
					clear(body);
					body.appendChild(toast('Thanks! "' + name + '" was submitted and is awaiting moderation.', false));
					setTimeout(closeModal, 1600);
				} else {
					clear(msgWrap);
					msgWrap.appendChild(toast((res && res.error) || 'Could not submit.', true));
				}
			}).catch(function () {
				submit.disabled = false;
				clear(msgWrap);
				msgWrap.appendChild(toast('Network error, try again.', true));
			});
		});

		step.appendChild(submit);
		step.appendChild(msgWrap);
		body.appendChild(step);
	}

	/** Консенсус-подтверждение unconfirmed-привязки второй независимой парой глаз.
	 *  Пока ни один шаблон не рендерит кнопку с этим вызовом (moderation UI — Task 6+);
	 *  метод реализован по контракту брифа и готов к вызову откуда угодно. */
	function confirmLink(linkId) {
		linkId = parseInt(linkId, 10) || 0;
		if (linkId < 1) return;
		return api('confirmLink', { link_id: linkId }).then(function (res) {
			if (res && res.success) {
				document.querySelectorAll('[data-link-id="' + linkId + '"]').forEach(function (chip) {
					chip.classList.remove('is-unconfirmed');
				});
				window.location.reload();
			}
			return res;
		});
	}

	return { openModal: openModal, confirm: confirmLink };
})();
