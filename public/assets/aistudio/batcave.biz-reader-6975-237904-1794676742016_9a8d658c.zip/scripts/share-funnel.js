(function () {
	'use strict';

	var ctxKey = 'batcave_share_folder_ctx';
	var openKeyPrefix = 'batcave_share_open_';
	var readKeyPrefix = 'batcave_share_reader_';

	function getUrl(value) {
		try {
			return new URL(value || window.location.href, window.location.origin);
		} catch (e) {
			return null;
		}
	}

	function folderIdFromPath(pathname) {
		var match = String(pathname || '').match(/^\/folder\/(\d+)\/?$/);
		return match ? parseInt(match[1], 10) : 0;
	}

	function readerPartsFromPath(pathname) {
		var match = String(pathname || '').match(/^\/reader\/(\d+)\/([^/?#]+)/);
		if (!match) return null;
		return {
			post_id: parseInt(match[1], 10) || 0,
			chapter_id: match[2]
		};
	}

	function getContext() {
		try {
			var ctx = JSON.parse(sessionStorage.getItem(ctxKey) || 'null');
			if (!ctx || !ctx.folder_id || Date.now() - ctx.ts > 86400000) return null;
			return ctx;
		} catch (e) {
			return null;
		}
	}

	function setContext(folderId) {
		var ctx = {folder_id: folderId, ts: Date.now()};
		try {
			sessionStorage.setItem(ctxKey, JSON.stringify(ctx));
		} catch (e) {}
		return ctx;
	}

	function sendEvent(data) {
		var url = (window.dle_root || '/') + 'engine/ajax/controller.php?mod=folder';
		data.method = 'shareEvent';
		if (navigator.sendBeacon && window.FormData) {
			var fd = new FormData();
			Object.keys(data).forEach(function (key) { fd.append(key, data[key]); });
			if (navigator.sendBeacon(url, fd)) return;
		}
		if (window.fetch && window.URLSearchParams) {
			var body = new URLSearchParams();
			Object.keys(data).forEach(function (key) { body.append(key, data[key]); });
			fetch(url, {
				method: 'POST',
				headers: {'Content-Type': 'application/x-www-form-urlencoded'},
				credentials: 'same-origin',
				body: body.toString(),
				keepalive: true
			}).catch(function () {});
		}
	}

	function track(event, folderId, target, href, itemId) {
		if (!folderId) return;
		sendEvent({
			event: event,
			folder_id: folderId,
			target: target,
			item_id: itemId || 0,
			url: href || window.location.href
		});
	}

	function trackReaderOpen(ctx, reader, href) {
		if (!ctx || !reader || !ctx.folder_id || !reader.post_id) return;
		var key = readKeyPrefix + ctx.folder_id + '_' + reader.post_id + '_' + reader.chapter_id;
		try {
			if (sessionStorage.getItem(key)) return;
			sessionStorage.setItem(key, '1');
		} catch (e) {}
		track('share_read_click', ctx.folder_id, 'reader', href, reader.post_id);
	}

	function getShareUrl(button, folderId) {
		var raw = button.getAttribute('data-folder-url') || ('/folder/' + folderId + '/?src=share_folder');
		var url = getUrl(raw);
		if (!url) return '';
		if (!url.searchParams.get('src')) {
			url.searchParams.set('src', 'share_folder');
		}
		return url.href;
	}

	function copyText(text, done) {
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(function () {
				done && done();
			}).catch(function () {
				fallbackCopyText(text);
				done && done();
			});
			return;
		}
		fallbackCopyText(text);
		done && done();
	}

	function fallbackCopyText(text) {
		var ta = document.createElement('textarea');
		ta.value = text;
		ta.style.position = 'fixed';
		ta.style.opacity = '0';
		document.body.appendChild(ta);
		ta.select();
		try {
			document.execCommand('copy');
		} catch (e) {}
		document.body.removeChild(ta);
	}

	function markShared(button) {
		var oldTitle = button.getAttribute('title') || 'Share';
		button.setAttribute('title', 'Copied');
		window.setTimeout(function () {
			button.setAttribute('title', oldTitle);
		}, 1600);
	}

	function initShareButtons() {
		document.addEventListener('click', function (event) {
			var button = event.target && event.target.closest ? event.target.closest('[data-folder-share]') : null;
			if (!button) return;

			var folderId = parseInt(button.getAttribute('data-folder-id'), 10) || 0;
			var href = getShareUrl(button, folderId);
			if (!folderId || !href) return;

			event.preventDefault();
			event.stopPropagation();

			var title = button.getAttribute('data-folder-title') || document.title;
			var text = button.getAttribute('data-folder-descr') || title;
			if (navigator.share) {
				navigator.share({title: title, text: text, url: href}).then(function () {
					track('share_click', folderId, 'native', href, 0);
				}).catch(function (err) {
					if (err && err.name === 'AbortError') return;
					copyText(href, function () {
						track('share_click', folderId, 'copy', href, 0);
						markShared(button);
					});
				});
				return;
			}

			copyText(href, function () {
				track('share_click', folderId, 'copy', href, 0);
				markShared(button);
			});
		}, true);
	}

	function initOpenTracking() {
		var current = getUrl();
		if (!current || current.searchParams.get('src') !== 'share_folder') return;

		var folderId = folderIdFromPath(current.pathname);
		if (!folderId) return;

		setContext(folderId);
		var key = openKeyPrefix + folderId;
		try {
			if (sessionStorage.getItem(key)) return;
			sessionStorage.setItem(key, '1');
		} catch (e) {}
		track('share_open', folderId, 'open', current.href, 0);
	}

	function initReaderLoadTracking() {
		var current = getUrl();
		if (!current) return;

		var reader = readerPartsFromPath(current.pathname);
		if (!reader) return;

		trackReaderOpen(getContext(), reader, current.href);
	}

	function initClickTracking() {
		document.addEventListener('click', function (event) {
			var link = event.target && event.target.closest ? event.target.closest('a[href]') : null;
			if (!link) return;

			var href = getUrl(link.getAttribute('href'));
			if (!href || href.origin !== window.location.origin) return;

			var current = getUrl();
			var folderId = current ? folderIdFromPath(current.pathname) : 0;
			if (folderId && current.searchParams.get('src') === 'share_folder') {
				var item = link.closest('[data-folder-item-id]');
				if (item) {
					track('share_item_click', folderId, 'item', href.href, item ? parseInt(item.getAttribute('data-folder-item-id'), 10) || 0 : 0);
				}
				return;
			}

			var ctx = getContext();
			var reader = readerPartsFromPath(href.pathname);
			if (ctx && reader) {
				trackReaderOpen(ctx, reader, href.href);
			}
		}, true);
	}

	initOpenTracking();
	initReaderLoadTracking();
	initClickTracking();
	initShareButtons();
})();
