/* Sandev/Streak — popup logic. Vanilla JS, no jQuery. */
(function () {
    'use strict';

    var POPUP_ID = 'streak-popup';
    var MIN_VISIBLE = 3;
    var pop;

    function getPopup() {
        if (!pop) pop = document.getElementById(POPUP_ID);
        return pop;
    }

    function fillPopup(data) {
        var p = getPopup();
        if (!p) return;
        var cur  = (data && typeof data.current === 'number') ? data.current : 0;
        var best = (data && typeof data.best    === 'number') ? data.best    : 0;
        var showCurrent = cur >= MIN_VISIBLE;
        var showRecord = best >= MIN_VISIBLE;
        var curRow = p.querySelector('[data-role="cur-row"]');
        var recordHead = p.querySelector('[data-role="record-head"]');
        var bestRow = p.querySelector('[data-role="best-row"]');

        p.querySelector('[data-role="cur"]').textContent  = showCurrent ? cur : '—';
        p.querySelector('[data-role="best"]').textContent = showRecord ? best : '—';
        p.querySelector('[data-role="best-head"]').textContent = showRecord ? best : '—';

        if (curRow) curRow.hidden = !showCurrent;
        if (recordHead) recordHead.hidden = showCurrent || !showRecord;
        if (bestRow) bestRow.hidden = !showCurrent || !showRecord;
    }

    function positionUnder(target) {
        var p = getPopup(); if (!p) return;
        var r = target.getBoundingClientRect();
        var scrollY = window.pageYOffset || document.documentElement.scrollTop;
        var scrollX = window.pageXOffset || document.documentElement.scrollLeft;
        p.style.top  = (r.bottom + scrollY + 6) + 'px';
        var left = r.left + scrollX;
        var maxLeft = (document.documentElement.clientWidth - 290) + scrollX;
        if (left > maxLeft) left = maxLeft;
        if (left < 8 + scrollX) left = 8 + scrollX;
        p.style.left = left + 'px';
    }

    function openPopup(target) {
        var raw  = target.getAttribute('data-streak');
        var data = null;
        if (raw) { try { data = JSON.parse(raw); } catch (_) { data = null; } }

        var p = getPopup(); if (!p) return;
        fillPopup(data);
        p.hidden = false;
        positionUnder(target);

        if (!data) {
            var uid = target.getAttribute('data-user-id');
            if (uid) {
                fetch('/engine/plugins/Sandev/Streak/ajax.php?action=details&user_id=' + encodeURIComponent(uid), {credentials: 'same-origin'})
                    .then(function (r) { return r.json(); })
                    .then(function (j) { if (j && j.success) fillPopup(j); })
                    .catch(function () {});
            }
        }
    }

    function closePopup() {
        var p = getPopup(); if (p) p.hidden = true;
    }

    document.addEventListener('click', function (e) {
        var t = e.target;
        while (t && t !== document) {
            if (t.classList && (t.classList.contains('user-streak') || t.classList.contains('js-streak-trigger'))) {
                e.preventDefault();
                e.stopPropagation();
                openPopup(t);
                return;
            }
            if (t.id === POPUP_ID) return;
            t = t.parentNode;
        }
        closePopup();
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closePopup();
    });

    window.addEventListener('resize', closePopup);
})();
