(function () {
	'use strict';

	// Real endpoint (verified Task 6): api.php alone does not bootstrap DLE — requests
	// must go through the controller.php AJAX dispatcher with mod=api.
	var api = '/engine/ajax/controller.php?mod=api&action=reviews/';

	function post(action, data) {
		// Токен сессии: сервер с 21.09.2026 проверяет его на всех мутирующих
		// действиях. Тело уходит как JSON, а engine/ajax/api.php раскладывает его
		// в $_POST — поэтому токен кладём в тело, отдельный заголовок не нужен.
		var payload = {};
		for (var k in data) if (Object.prototype.hasOwnProperty.call(data, k)) payload[k] = data[k];
		payload.user_hash = (typeof dle_login_hash !== 'undefined') ? dle_login_hash : '';

		return fetch(api + action, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(payload)
		}).then(function (r) { return r.json(); });
	}

	function escapeHtml(s) {
		return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}

	// Lightweight success/error toast (no dependency). Auto-dismisses.
	function rvToast(message, type) {
		var t = document.createElement('div');
		t.className = 'rv-toast rv-toast--' + (type || 'success');
		t.setAttribute('role', 'status');
		t.textContent = message;
		document.body.appendChild(t);
		requestAnimationFrame(function () { t.classList.add('is-in'); });
		setTimeout(function () {
			t.classList.remove('is-in');
			setTimeout(function () { t.remove(); }, 300);
		}, 2600);
	}

	// Star widget 1-5. Glyph is ALWAYS ★ — fill state is a CSS class (is-on),
	// so the selected rating stays visibly GOLD instead of silently "disappearing".
	function setStarsOn(el, cur) {
		el.querySelectorAll('.rv-star').forEach(function (st) {
			st.classList.toggle('is-on', +st.dataset.v <= cur);
		});
	}
	function buildStars(el) {
		if (el.dataset.built) return;
		el.dataset.built = '1';
		var cur = +el.dataset.score || 0;
		for (var i = 1; i <= 5; i++) {
			var s = document.createElement('span');
			s.className = 'rv-star';
			s.dataset.v = i;
			s.textContent = '★';
			el.appendChild(s);
		}
		setStarsOn(el, cur);
		el.addEventListener('click', function (e) {
			if (!e.target.dataset.v) return;
			cur = +e.target.dataset.v;
			el.dataset.score = cur;
			setStarsOn(el, cur);
			el.dispatchEvent(new CustomEvent('rv-score-change'));
		});
	}
	document.querySelectorAll('.rv-stars').forEach(buildStars);

	// Live counter + submit gating
	function refreshCounter(form) {
		var textarea = form.querySelector('textarea');
		var counter = form.querySelector('.rv-counter');
		var starsEl = form.querySelector('.rv-stars');
		var submitBtn = form.querySelector('.rv-submit');
		if (!textarea || !counter || !starsEl || !submitBtn) return;

		// Зеркалит серверный validateBody: нормализация whitespace → счёт по контенту + разнообразию слов.
		var norm = textarea.value.replace(/\r\n?/g, '\n').replace(/[ \t ]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
		var len = norm.length;
		var max = +counter.dataset.max || Infinity;
		var minContent = +counter.dataset.minContent || +counter.dataset.min || 0;
		var minWords = +counter.dataset.minWords || 0;
		var score = +starsEl.dataset.score || 0;

		var contentLen = norm.replace(/\s+/g, '').length;
		var words = norm ? norm.split(/\s+/) : [];
		var distinct = {}, distinctCount = 0;
		words.forEach(function (w) { var k = w.toLowerCase(); if (!distinct[k]) { distinct[k] = 1; distinctCount++; } });

		var okContent = contentLen >= minContent;
		var okWords = distinctCount >= minWords;
		var reviewMin = +counter.dataset.review || 0;
		var kindLen = norm.replace(/>!|!</g, '').length;
		// мягкое зеркало серверного TextGuard::findLink — сервер всё равно отклонит
		var hasLink = /(?:https?:\/\/|www\.|t\s*\.\s*me|vk\s*\.\s*com|discord\s*\.\s*gg|[a-z0-9-]+\.(?:ru|com|net|org|io|cc|biz|xyz)(?![a-z0-9]))/i.test(norm);

		counter.classList.remove('rv-counter--short', 'rv-counter--review');
		if (hasLink) {
			counter.textContent = 'remove the link or website address — they are not allowed';
			counter.classList.add('rv-counter--short');
		} else if (!okContent) {
			counter.textContent = 'short take: write a little more';
			counter.classList.add('rv-counter--short');
		} else if (!okWords) {
			counter.textContent = 'Add a bit more detail (' + distinctCount + '/' + minWords + ' words)';
			counter.classList.add('rv-counter--short');
		} else if (reviewMin && kindLen < reviewMin) {
			counter.textContent = 'Short take · ' + (reviewMin - kindLen) + ' chars to a review';
		} else {
			counter.textContent = 'Review ✓ · ' + len + ' / ' + max;
			counter.classList.add('rv-counter--review');
		}

		submitBtn.disabled = !(okContent && okWords && !hasLink && len <= max && score >= 1);
	}

	document.querySelectorAll('.rv-form').forEach(function (f) {
		var textarea = f.querySelector('textarea');
		var starsEl = f.querySelector('.rv-stars');
		if (textarea) textarea.addEventListener('input', function () { refreshCounter(f); });
		if (starsEl) starsEl.addEventListener('rv-score-change', function () { refreshCounter(f); });
		refreshCounter(f);
	});

	// Spoiler button: wraps the selected textarea text in >! … !< markers.
	// No selection → inserts an empty >!!< pair and places the caret between the markers.
	document.querySelectorAll('.rv-spoiler-btn').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var form = btn.closest('.rv-form');
			var textarea = form ? form.querySelector('textarea') : null;
			if (!textarea) return;

			var start = textarea.selectionStart;
			var end = textarea.selectionEnd;
			var val = textarea.value;
			var selected = val.slice(start, end);
			// без выделения ничего не вставляем: пустая пара >!!< оседала в текстах (аудит 01.10.2026)
			if (!selected.trim()) {
				var fnote = form.querySelector('.rv-note');
				if (fnote) fnote.textContent = 'Select the text you want to hide under a spoiler';
				textarea.focus();
				return;
			}

			var inserted = '>!' + selected + '!<';
			textarea.value = val.slice(0, start) + inserted + val.slice(end);

			var caret = start + inserted.length;
			textarea.focus();
			textarea.setSelectionRange(caret, caret);

			textarea.dispatchEvent(new Event('input', { bubbles: true }));
		});
	});

	// Modal open/close
	document.querySelectorAll('.rv-open-modal').forEach(function (btn) {
		// Модалка — sibling внутри .reviews-block (кнопка может быть вложена в .rv-cta),
		// поэтому ищем в пределах всего блока, а не относительно parentElement.
		var ownerBlock = btn.closest('.reviews-block');
		var modal = ownerBlock ? ownerBlock.querySelector('.rv-modal') : null;
		if (!modal) return;
		var form = modal.querySelector('.rv-form');
		var starsEl = modal.querySelector('.rv-stars');
		var textarea = modal.querySelector('textarea');

		function open() {
			if (starsEl) buildStars(starsEl);
			modal.hidden = false;
			document.documentElement.classList.add('rv-noscroll');
			document.body.classList.add('rv-noscroll');
			if (form) refreshCounter(form);
			if (textarea) textarea.focus(); else if (starsEl) starsEl.focus();
		}
		function close() {
			modal.hidden = true;
			document.documentElement.classList.remove('rv-noscroll');
			document.body.classList.remove('rv-noscroll');
			btn.focus();
		}

		btn.addEventListener('click', open);
		modal.querySelectorAll('[data-close]').forEach(function (el) {
			el.addEventListener('click', close);
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && !modal.hidden) close();
		});

		modal._rvClose = close;
	});

	// Submit / edit review
	document.querySelectorAll('.rv-form').forEach(function (f) {
		f.addEventListener('submit', function (e) {
			e.preventDefault();
			var block = f.closest('.reviews-block');
			var news = block ? +block.dataset.news : 0;
			var starsEl = f.querySelector('.rv-stars');
			var score = starsEl ? (+starsEl.dataset.score || 0) : 0;
			var body = f.querySelector('textarea').value;
			var note = f.querySelector('.rv-note');
			var submitBtn = f.querySelector('.rv-submit');
			var action = f.dataset.mode === 'edit' ? 'edit' : 'submit';
			var hpEl = f.querySelector('.rv-hp');
			var hpVal = hpEl ? hpEl.value : '';
			var renderedTs = f.dataset.rendered || 0;

			if (!score) {
				if (note) note.textContent = 'Pick a rating first';
				return;
			}

			if (submitBtn) submitBtn.disabled = true;
			post(action, { news_id: news, score: score, body: body, hp: hpVal, ts: +renderedTs }).then(function (res) {
				if (res.error) {
					if (submitBtn) submitBtn.disabled = false;
					if (note) note.textContent = res.error;
					return;
				}
				var status = res.data && res.data.status;
				if (f.dataset.mode !== 'edit') f.dataset.mode = 'edit';
				if (submitBtn) submitBtn.disabled = false;
				// Close the form modal, then confirm with a green toast.
				var modalEl = f.closest('.rv-modal');
				if (modalEl && typeof modalEl._rvClose === 'function') modalEl._rvClose();
				if (status === 'pending') {
					rvToast(((res.data && res.data.kind === 'short') ? 'Short take' : 'Review') + ' submitted — pending moderation.', 'success');
				} else {
					rvToast(((res.data && res.data.kind === 'short') ? 'Short take' : 'Review') + ' published — thanks!', 'success');
					setTimeout(function () { location.reload(); }, 900);
				}
			}, function () {
				if (submitBtn) submitBtn.disabled = false;
				if (note) note.textContent = 'Network error, please try again';
			});
		});
	});

	// Delete own review
	document.querySelectorAll('.rv-delete').forEach(function (btn) {
		btn.addEventListener('click', function () {
			if (!confirm('Delete your review? This cannot be undone.')) return;
			var block = btn.closest('.reviews-block');
			var news = block ? +block.dataset.news : 0;
			var form = btn.closest('.rv-form');
			var note = form ? form.querySelector('.rv-note') : null;

			btn.disabled = true;
			post('delete', { news_id: news }).then(function (res) {
				if (res.error) {
					btn.disabled = false;
					if (note) note.textContent = res.error;
					return;
				}
				location.reload();
			}, function () {
				btn.disabled = false;
				if (note) note.textContent = 'Network error, please try again';
			});
		});
	});

	// Moderation: approve / reject pending reviews (moderator-only, server-rendered)
	document.querySelectorAll('.rv-modqueue').forEach(function (queue) {
		queue.addEventListener('click', function (e) {
			var b = e.target.closest('.rv-approve, .rv-reject');
			if (!b || b.disabled) return;
			var item = b.closest('.rv-moditem');
			var id = item ? +item.dataset.id : 0;
			if (!id) return;
			var isReject = b.classList.contains('rv-reject');
			var payload = { review_id: id };
			if (isReject) {
				var reason = prompt('Reason for rejection (optional, sent to the author):', '');
				if (reason === null) return; // отмена
				payload.reason = reason;
			}
			b.disabled = true;
			post(isReject ? 'reject' : 'approve', payload).then(function (res) {
				if (res.error) { b.disabled = false; rvToast(res.error, 'error'); return; }
				rvToast(isReject ? 'Review rejected' : 'Review approved', 'success');
				if (item) item.remove();
				var head = queue.querySelector('.rv-modqueue__head');
				var left = queue.querySelectorAll('.rv-moditem').length;
				if (head) head.textContent = 'Pending moderation (' + left + ')';
				if (left === 0) queue.remove();
			}, function () {
				b.disabled = false;
				rvToast('Network error, please try again', 'error');
			});
		});
	});

	// Helpfulness votes
	document.querySelectorAll('.rv-list').forEach(function (list) {
		list.addEventListener('click', function (e) {
			var b = e.target.closest('.rv-vote');
			if (!b || b.disabled) return;
			var item = b.closest('.rv-item');
			var id = +item.dataset.id;
			var vote = +b.dataset.vote;

			b.disabled = true;
			post('vote', { review_id: id, vote: vote }).then(function (res) {
				b.disabled = false;
				if (res.error) { return; }
				var up = item.querySelector('.rv-up span');
				var down = item.querySelector('.rv-down span');
				if (up) up.textContent = res.data.votes_up;
				if (down) down.textContent = res.data.votes_down;
			}, function () {
				b.disabled = false;
			});
		});
	});

	// Open the review modal (if available in this block) and optionally preselect a score.
	// Reused by the cross-page hash handler (#writereview[-N]) and the fullstory quick-rate stars.
	function openModalWithScore(block, score) {
		if (!block) return false;
		var openBtn = block.querySelector('.rv-open-modal');
		if (!openBtn) return false;
		openBtn.click();
		if (score) {
			var modal = block.querySelector('.rv-modal');
			var starsEl = modal ? modal.querySelector('.rv-stars') : null;
			if (starsEl) {
				buildStars(starsEl);
				var v = Math.max(1, Math.min(5, +score || 0));
				starsEl.dataset.score = v;
				setStarsOn(starsEl, v);
				starsEl.dispatchEvent(new CustomEvent('rv-score-change'));
			}
		}
		return true;
	}

	// Cross-page hash handoff: reader end-of-comic CTA links to
	// data.post_link + '#writereview' or '#writereview-N' (star N clicked).
	function handleReviewHash() {
		var hash = window.location.hash || '';
		if (hash.indexOf('#writereview') !== 0) return;
		var block = document.querySelector('.reviews-block');
		if (!block) return;
		var m = hash.match(/^#writereview-(\d{1,2})$/);
		var score = m ? +m[1] : undefined;
		if (!openModalWithScore(block, score)) {
			block.scrollIntoView();
		}
	}
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', handleReviewHash);
	} else {
		handleReviewHash();
	}

	// Spoiler reveal: click or Enter/Space on a rendered .rv-spoiler toggles the reveal state.
	// Delegated once on document — covers spoilers rendered server-side in any .reviews-block.
	document.addEventListener('click', function (e) {
		var sp = e.target.closest('.rv-spoiler');
		if (sp) sp.classList.toggle('revealed');
	});
	document.addEventListener('keydown', function (e) {
		if (e.key !== 'Enter' && e.key !== ' ') return;
		var sp = e.target.closest && e.target.closest('.rv-spoiler');
		if (!sp) return;
		e.preventDefault();
		sp.classList.toggle('revealed');
	});

	// Fullstory quick-rate stars row (.rv-quickrate): clicking a star opens the modal preselected.
	document.querySelectorAll('.reviews-block').forEach(function (block) {
		var quick = block.querySelector('.rv-quickrate');
		if (!quick) return;
		quick.addEventListener('click', function (e) {
			var el = e.target.closest('[data-score]');
			if (!el || !quick.contains(el)) return;
			openModalWithScore(block, parseInt(el.dataset.score, 10));
		});
	});

	// Homepage tab switch
	var grid = document.getElementById('rvh-grid');
	document.querySelectorAll('.rvh-tab').forEach(function (t) {
		t.addEventListener('click', function () {
			if (t.classList.contains('is-active')) return;
			document.querySelectorAll('.rvh-tab').forEach(function (x) { x.classList.remove('is-active'); });
			t.classList.add('is-active');

			post('hot', { period: t.dataset.period }).then(function (res) {
				if (res.error || !grid || !Array.isArray(res.data)) return;
				grid.innerHTML = '';
				res.data.forEach(function (it) {
					var a = document.createElement('a');
					a.className = 'rvh-card';
					a.href = '/' + (it.news_id | 0) + '-' + escapeHtml(it.alt_name || '') + '.html#reviews';

					var title = document.createElement('div');
					title.className = 'rvh-title';
					title.textContent = it.title || '';

					var meta = document.createElement('div');
					meta.className = 'rvh-meta';
					meta.textContent = '★ ' + (it.score | 0) + '/5 · ▲' + (it.votes_up | 0);

					var snippet = document.createElement('div');
					snippet.className = 'rvh-snippet';
					snippet.textContent = String(it.body || '').slice(0, 160) + '…';

					var author = document.createElement('div');
					author.className = 'rvh-author';
					author.textContent = '— ' + (it.name || 'user');

					a.appendChild(title);
					a.appendChild(meta);
					a.appendChild(snippet);
					a.appendChild(author);
					grid.appendChild(a);
				});
			});
		});
	});
})();
