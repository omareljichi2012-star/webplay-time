/**
 * Block user — персональный чёрный список.
 *
 * Кнопка одна на всех поверхностях (профиль, комментарии, рецензии), состояние
 * определяет сервер, поэтому клиент только шлёт имя и разбирает ответ.
 */
(function () {
	'use strict';

	function setButtonState(button, blocked) {
		var icon = button.querySelector('.fal');

		button.classList.toggle('is-active', blocked);
		button.title = blocked ? 'Unblock user' : 'Block user';
		button.setAttribute('aria-label', button.title);

		if (icon) {
			icon.classList.toggle('fa-user-check', blocked);
			icon.classList.toggle('fa-user-slash', !blocked);
		}

		var label = button.querySelector('.js-ignore-label');
		if (label) label.textContent = blocked ? 'Unblock' : 'Block';
	}

	document.addEventListener('click', function (event) {
		var button = event.target.closest('.js-ignore-toggle');
		if (!button) return;

		event.preventDefault();
		if (button.dataset.loading === '1') return;

		var name = button.dataset.ignoreName || '';
		var userHash = button.dataset.userHash || '';
		if (!name || !userHash || typeof window.sendAjax !== 'function') return;

		// Спрашиваем в обе стороны. Разблокировку раньше пропускали как безобидную,
		// но в списке с поиском и свёрткой по «Unblock» легко промахнуться, а
		// человек молча возвращается во все ленты.
		var isBlocked = button.classList.contains('is-active');
		var row = button.closest('[data-ignore-row]');
		// Строка в разделе знает уровень: у «everywhere» снятие вернёт не только ЛС.
		var everywhere = !row || !row.querySelector('.ignl__scope--pm');

		var question = isBlocked
			? (everywhere
				? 'Unblock ' + name + '? Their comments, reviews and messages will be visible again.'
				: 'Unblock ' + name + '? They will be able to send you private messages again.')
			: 'Block ' + name + '? You will no longer see their comments, reviews and messages.';

		if (!window.confirm(question)) return;

		button.dataset.loading = '1';
		button.classList.add('is-loading');

		window.sendAjax('Ignore/toggle', {
			name: name,
			user_hash: userHash,
			// откуда нажали — чтобы в списке было видно, где ставилась блокировка
			source: button.dataset.ignoreSource || ''
		}, function (response) {
			var data = response.data || {};

			button.dataset.loading = '';
			button.classList.remove('is-loading');
			setButtonState(button, !!data.blocked);

			// В списке «Blocked users» строка после разблокировки должна уйти:
			// иначе на месте останется кнопка, повторный клик по которой
			// молча заблокирует человека обратно.
			if (row && !data.blocked) {
				row.classList.add('is-removing');
				row.addEventListener('transitionend', function () { row.remove(); });
				setTimeout(function () { if (row.parentNode) row.remove(); }, 300);

				var list = document.querySelector('.ignl__list');
				if (list && !list.querySelector('[data-ignore-row]')) {
					var section = document.getElementById('blocklist');
					if (section) section.remove();
				}
				return;
			}

			// В ленте комментариев одной перерисовки кнопки мало: заблокированный
			// пропадает вместе с веткой, а его ответы поднимаются на уровень выше.
			// Эту раскладку считает сервер, поэтому перечитываем страницу.
			if (data.blocked && button.closest('.comment-item__controls')) {
				window.location.reload();
			}
		}, function () {
			button.dataset.loading = '';
			button.classList.remove('is-loading');
		});
	});

	/**
	 * Блок комментариев на главной приходит из общего HTML-кэша, одинакового для
	 * всех зрителей, — отфильтровать его на сервере нельзя, не обнулив кэш всем
	 * остальным. Поэтому карточки заблокированных снимаются здесь, по списку,
	 * который отдал inline_list.php.
	 */
	function hideCachedComments() {
		var names = window.dleIgnoreNames;
		if (!names || !names.length) return;

		var blocked = Object.create(null);
		for (var i = 0; i < names.length; i++) {
			blocked[String(names[i]).toLowerCase()] = true;
		}

		var nodes = document.querySelectorAll('[data-comm-author]');
		for (var j = 0; j < nodes.length; j++) {
			// Гостей пропускаем, как это делают все серверные фильтры: имя гостя
			// не уникально и может совпасть с логином зарегистрированного.
			if (nodes[j].getAttribute('data-comm-guest') === '1') continue;

			var author = (nodes[j].getAttribute('data-comm-author') || '').toLowerCase();
			if (blocked[author]) nodes[j].remove();
		}
	}

	/* Длинный список: «показать все» и поиск по имени. Оба работают на уже
	   отданной разметке — лишних запросов к серверу нет. */
	document.addEventListener('click', function (event) {
		var more = event.target.closest('[data-ignore-more]');
		if (!more) return;

		event.preventDefault();
		var list = document.querySelector('.ignl__list');
		if (list) list.classList.remove('is-collapsed');
		more.remove();
	});

	document.addEventListener('input', function (event) {
		var field = event.target.closest('.ignl__search');
		if (!field) return;

		var query = field.value.trim().toLowerCase();
		var list  = document.querySelector('.ignl__list');
		if (!list) return;

		// При поиске свёртка мешает: искомое может быть за десятым.
		if (query) list.classList.remove('is-collapsed');

		var rows = list.querySelectorAll('[data-ignore-row]');
		var found = 0;
		for (var i = 0; i < rows.length; i++) {
			var name = (rows[i].getAttribute('data-ignore-row') || '').toLowerCase();
			var hit  = !query || name.indexOf(query) !== -1;
			rows[i].classList.toggle('is-hidden', !hit);
			if (hit) found++;
		}

		var empty = list.parentNode.querySelector('.ignl__empty');
		if (!found && !empty) {
			empty = document.createElement('div');
			empty.className = 'ignl__empty';
			empty.textContent = 'Nobody matches that name.';
			list.parentNode.insertBefore(empty, list.nextSibling);
		} else if (found && empty) {
			empty.remove();
		}
	});

	/* Пункт «Чёрный список» в модальном меню ведёт на {profile-link}#blocklist.
	   Если человек уже на своём профиле, браузер только прокручивает к якорю без
	   перезагрузки, и модальное окно с затемнением остаётся открытым. Закрываем его
	   родным обработчиком сайта (клик по .login__close делегирован на document)
	   и прокручиваем к разделу сами. С другой страницы — обычный переход. */
	function isSamePage(url) {
		var norm = function (path) {
			path = String(path).replace(/\+/g, ' ');
			try { path = decodeURIComponent(path); } catch (e) {}
			return path.toLowerCase().replace(/\/+$/, '');
		};
		return url.origin === location.origin
			&& norm(url.pathname) === norm(location.pathname)
			&& url.search === location.search;
	}

	document.addEventListener('click', function (event) {
		var link = event.target.closest('a[href*="#blocklist"]');
		if (!link || event.defaultPrevented || event.button !== 0
			|| event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;

		var url;
		try { url = new URL(link.getAttribute('href'), location.href); } catch (e) { return; }
		if (!isSamePage(url)) return;

		event.preventDefault();

		var close = document.querySelector('.login-cloned .login__close') || document.querySelector('.login__close');
		if (close) close.click();

		var section = document.getElementById('blocklist');
		if (section) {
			if (window.history && history.replaceState) history.replaceState(null, '', '#blocklist');
			section.scrollIntoView({ behavior: 'smooth', block: 'start' });
		}
	});

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', hideCachedComments);
	} else {
		hideCachedComments();
	}
})();
