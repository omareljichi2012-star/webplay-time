/* Общие обработчики скина Default (batcave): действия по data-атрибутам вместо onclick в разметке,
   поля BB-редактора, флажок спойлера, клавиатура для role="button". Вызывают те же функции, что и прежний onclick. */
(function () {
	/* closest() без полифила: старые браузеры его не знают */
	function closest(el, sel) {
		var m = el && (el.matches || el.webkitMatchesSelector || el.msMatchesSelector);
		while (el && el.nodeType === 1) {
			if (m.call(el, sel)) return el;
			el = el.parentNode;
		}
		return null;
	}

	function call(name) {
		var args = [].slice.call(arguments, 1);
		if (typeof window[name] === 'function') return window[name].apply(window, args);
	}

	function method(obj, name) {
		var o = window[obj], args = [].slice.call(arguments, 2);
		if (o && typeof o[name] === 'function') return o[name].apply(o, args);
	}

	function data(el, name) {
		return el.getAttribute('data-' + name);
	}

	/* Действия. true — отменить действие браузера по умолчанию (как прежний return false). */
	var actions = {
		'vote': function () { call('doVote', 'vote'); return true; },
		'vote-results': function () { call('doVote', 'results'); return true; },
		'poll-vote': function (el) { call('doPoll', 'vote', data(el, 'news-id')); return true; },
		'poll-results': function (el) { call('doPoll', 'results', data(el, 'news-id')); return true; },
		'check-login': function () { call('CheckLogin'); return true; },
		'find-relates': function () { call('find_relates'); return true; },
		'news-preview': function () { call('preview'); return false; },
		'comments-page': function (el) { call('findCommentsPage', el, data(el, 'id'), data(el, 'news-id')); return true; },
		'follow': function (el) { return method('follow', 'toggle', el, +data(el, 'news-id')) === false; },
		'echat-room': function (el) { return method('echat', 'setRoom', el, data(el, 'room')) === false; },
		'echat-alive': function () { return method('echat', 'imAlive') === false; },
		'echat-edit': function (el) { return method('echat', 'editMessage', +data(el, 'id')) === false; },
		'echat-delete': function (el) { return method('echat', 'deleteMessage', +data(el, 'id')) === false; },
		'echat-delete-user': function (el) { return method('echat', 'deleteUserMessages', +data(el, 'id')) === false; },
		'echat-ban': function (el) { return method('echat', 'banUser', +data(el, 'id')) === false; },
		'echat-report': function (el) { return method('echat', 'reportMessage', +data(el, 'id')) === false; },
		'avatar-save': function () { return method('avaCrop', 'save') === false; },
		'profile-edit': function () { call('openProfileEditor'); return false; },
		/* «Отправить» комментарий снимает флажок спойлера (как раньше) */
		'comment-submit': function () {
			var s = document.getElementById('comm_spoiler');
			if (s) s.checked = false;
			return false;
		},
		/* Загрузка главы: свернуть/развернуть страницы и панель инструментов */
		'mc-images-toggle': function () {
			call('ShowOrHide', 'publish-images');
			var t = document.getElementById('mcimg-toolbar');
			if (t) t.style.display = t.style.display === 'none' ? 'flex' : 'none'; /* inline-style-ok: панель скрыта style="display:none", её же открывает скрипт publish.tpl */
			return false;
		},
		'orderdesc-delete': function () {
			var n = document.querySelectorAll('.orderdesc-mass:checked').length;
			return !window.confirm('Really delete all ' + n + ' selected requests?');
		},
		'vote-all': function () { call('ShowAllVotes'); return true; },
		'print': function () { setTimeout(function () { window.print(); }, 100); return false; }
	};

	document.addEventListener('click', function (e) {
		var el = closest(e.target, '[data-action],[data-confirm]');
		if (!el) return;
		var text = data(el, 'confirm');
		if (text !== null) {
			if (!window.confirm(text)) e.preventDefault();
			return;
		}
		var fn = actions[data(el, 'action')];
		if (fn && fn(el)) e.preventDefault();
	});

	/* Поля с BB-редактором: панель кнопок DLE вставляет код в поле, которое было в фокусе последним */
	document.addEventListener('focusin', function (e) {
		var el = e.target;
		if (el.hasAttribute && el.hasAttribute('data-bb-field')) call('setFieldName', el.name);
	});

	/* Флажок, который запоминается в cookie (data-cookie="имя") */
	document.addEventListener('change', function (e) {
		var el = e.target, name = el.getAttribute && el.getAttribute('data-cookie');
		if (name) call('setcookie', name, el.checked ? 1 : 0);
	});

	/* Кликабельные не-кнопки с role="button": Enter и пробел работают как клик */
	/* на window — после всех обработчиков страницы; уже обработанное (preventDefault) не дублируем */
	window.addEventListener('keydown', function (e) {
		var el = e.target;
		if (!e.defaultPrevented && (e.key === 'Enter' || e.key === ' ') && el.getAttribute && el.getAttribute('role') === 'button'
			&& el.tagName !== 'BUTTON' && el.tagName !== 'A' && el.tagName !== 'LABEL') {
			e.preventDefault();
			el.click();
		}
	});
	/* Регистрация (do=regin): после ошибки сервер отдаёт форму пустой — имя и почту возвращаем
	   из памяти вкладки. Пароль не храним. Форму и поля задаёт ядро (engine/modules/register.php). */
	(function () {
		var form = document.getElementById('registration'), key = 'bc_reg_prefill', saved;
		if (!form || !form.elements.submit_reg || !form.elements.email) return;
		try { saved = JSON.parse(sessionStorage.getItem(key) || 'null'); } catch (err) { saved = null; }
		if (saved) {
			['name', 'email'].forEach(function (n) {
				var el = form.elements[n];
				if (el && !el.value && saved[n]) el.value = saved[n];
			});
		}
		form.addEventListener('submit', function () {
			try {
				sessionStorage.setItem(key, JSON.stringify({ name: form.elements.name.value, email: form.elements.email.value }));
			} catch (err) { /* приватный режим без sessionStorage — просто не запоминаем */ }
		});
	})();
})();
