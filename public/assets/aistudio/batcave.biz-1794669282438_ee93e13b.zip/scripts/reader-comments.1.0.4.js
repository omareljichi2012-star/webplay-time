/**
 * Комментарии к главам читалки.
 *
 * Отдельное Vue-приложение, как vue.yalert.js: основное приложение читалки
 * собрано в libs.min.js и добавить в него компонент после mount нельзя.
 *
 * Загрузка ленивая: до попадания блока в поле зрения запросов нет вообще.
 * Триггером служит IntersectionObserver, есть и ручная кнопка.
 *
 * Транспорт: engine/ajax/controller.php?mod=api&action=reader/<method>
 * Все изменяющие запросы несут user_hash — серверная сторона его проверяет.
 */
(function () {
	'use strict';

	var root = document.getElementById('reader-comments');
	if (!root || typeof Vue === 'undefined') return;

	var DATA = window.__DATA__ || {};

	/* Тумблер из настроек читалки. Ключ общий с Vue-приложением читалки. */
	function commentsEnabled() {
		try {
			var s = JSON.parse(localStorage.getItem('reader__settings') || '{}');
			return s.showComments !== 0;
		} catch (e) {
			return true;
		}
	}

	function api(method, payload) {
		var body = new URLSearchParams();
		Object.keys(payload || {}).forEach(function (k) {
			body.append(k, payload[k]);
		});

		return fetch('/engine/ajax/controller.php?mod=api&action=reader/' + method, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		})
			.then(function (r) { return r.json(); })
			.then(function (json) {
				if (!json || json.success !== true) {
					throw new Error((json && json.error) || 'Request failed');
				}
				return json.data;
			});
	}

	function toast(text, type) {
		if (window.yalert && typeof window.yalert.push === 'function') {
			window.yalert.push({ type: type || 'error', text: text, time: 6000 });
		}
	}

	var app = Vue.createApp({
		/* Шаблон берём из <script type="text/x-template" id="rc-app">, а не из
		   контейнера: контейнер лежит внутри .reader-root и его содержимое
		   успело бы перемолоть основное приложение читалки. */
		template: '#rc-app',

		data: function () {
			return {
				enabled:  commentsEnabled(),
				isLogged: !!DATA.is_logged,
				/* Запрет на комментарии для новых аккаунтов: готовый текст с остатком
				   времени приходит с сервера, пустая строка — ограничения нет. */
				commRestrict: DATA.comm_restrict || '',
				newsId:   parseInt(DATA.news_id, 10) || 0,
				chapterId: parseInt(DATA.chapter_id, 10) || 0,
				userHash: DATA.user_hash || '',

				loaded:   false,
				loading:  false,
				error:    '',

				list:     [],
				count:    0,
				page:     1,
				hasMore:  false,

				form:     { text: '', spoiler: false, sending: false },
				replyTo:  0,
				replyText: '',
				replySpoiler: false,
				replySending: false,
				busyId:   0
			};
		},

		mounted: function () {
			if (!this.enabled || this.chapterId < 1) return;

			var self = this;

			/* Ленивая загрузка: пока блок не показался на экране, сети нет */
			if ('IntersectionObserver' in window) {
				var io = new IntersectionObserver(function (entries) {
					entries.forEach(function (entry) {
						if (entry.isIntersecting) {
							io.disconnect();
							self.load(false);
						}
					});
				}, { rootMargin: '200px 0px' });
				/* Наблюдаем за блоком с кнопкой «Show comments»: он и есть
				   граница, ниже которой читателю нужны комментарии */
				io.observe(this.$refs.lazyTrigger || root);
			}

			/* Переключение тумблера в настройках читалки — без перезагрузки */
			document.addEventListener('click', function (e) {
				var t = e.target.closest && e.target.closest('[data-cmt-pref]');
				if (!t) return;
				self.enabled = t.getAttribute('data-cmt-pref') === '1';
				if (self.enabled && !self.loaded && !self.loading) self.load(false);
			});
		},

		methods: {
			load: function (more) {
				if (this.loading) return;

				this.loading = true;
				this.error   = '';

				var self = this;
				var page = more ? this.page + 1 : 1;

				api('commentsList', {
					news_id:    this.newsId,
					chapter_id: this.chapterId,
					page:       page,
					limit:      20
				}).then(function (d) {
					self.list    = more ? self.list.concat(d.list) : d.list;
					self.count   = d.count;
					self.page    = d.page;
					self.hasMore = d.has_more;
					self.loaded  = true;
				}).catch(function (e) {
					self.error = e.message || 'Could not load comments.';
				}).then(function () {
					self.loading = false;
				});
			},

			submit: function () {
				var text = (this.form.text || '').trim();
				if (text.length < 5) {
					toast('Comment is too short (min 5 characters).');
					return;
				}
				if (this.form.sending) return;

				this.form.sending = true;

				var self = this;
				api('commentsAdd', {
					news_id:    this.newsId,
					chapter_id: this.chapterId,
					comments:   text,
					spoiler:    this.form.spoiler ? 1 : 0,
					parent:     0,
					user_hash:  this.userHash
				}).then(function (d) {
					self.form.text = '';
					self.form.spoiler = false;
					if (d.pending) {
						toast('Your comment was sent for moderation.', 'info');
						return;
					}
					self.list.unshift(d.comment);
					self.count++;
				}).catch(function (e) {
					toast(e.message);
				}).then(function () {
					self.form.sending = false;
				});
			},

			openReply: function (id) {
				this.replyTo      = (this.replyTo === id) ? 0 : id;
				this.replyText    = '';
				this.replySpoiler = false;
			},

			sendReply: function (parent) {
				var text = (this.replyText || '').trim();
				if (text.length < 5) {
					toast('Reply is too short (min 5 characters).');
					return;
				}
				if (this.replySending) return;

				this.replySending = true;

				var self = this;
				api('commentsAdd', {
					news_id:    this.newsId,
					chapter_id: this.chapterId,
					comments:   text,
					spoiler:    this.replySpoiler ? 1 : 0,
					parent:     parent,
					user_hash:  this.userHash
				}).then(function (d) {
					self.replyTo      = 0;
					self.replyText    = '';
					self.replySpoiler = false;
					if (d.pending) {
						toast('Your reply was sent for moderation.', 'info');
						return;
					}
					var host = self.findById(self.list, parent);
					if (host) {
						host.replies = host.replies || [];
						host.replies.push(d.comment);
					}
					self.count++;
				}).catch(function (e) {
					toast(e.message);
				}).then(function () {
					self.replySending = false;
				});
			},

			remove: function (comment) {
				if (this.busyId) return;
				if (!window.confirm('Delete this comment?')) return;

				this.busyId = comment.id;

				var self = this;
				api('commentsDelete', { id: comment.id, user_hash: this.userHash })
					.then(function () {
						self.removeById(self.list, comment.id);
						self.count = Math.max(0, self.count - 1);
					})
					.catch(function (e) { toast(e.message); })
					.then(function () { self.busyId = 0; });
			},

			rate: function (comment, value) {
				if (!this.isLogged) {
					toast('Sign in to rate comments.');
					return;
				}
				if (this.busyId) return;

				this.busyId = comment.id;

				var self = this;
				api('commentsRate', { id: comment.id, rate: value, user_hash: this.userHash })
					.then(function (d) {
						comment.rating   = d.rating;
						comment.vote_num = d.vote_num;
					})
					.catch(function (e) { toast(e.message); })
					.then(function () { self.busyId = 0; });
			},

			/* Поиск и удаление в дереве — ответы вложены в replies */
			findById: function (list, id) {
				for (var i = 0; i < list.length; i++) {
					if (list[i].id === id) return list[i];
					if (list[i].replies && list[i].replies.length) {
						var found = this.findById(list[i].replies, id);
						if (found) return found;
					}
				}
				return null;
			},

			removeById: function (list, id) {
				for (var i = 0; i < list.length; i++) {
					if (list[i].id === id) { list.splice(i, 1); return true; }
					if (list[i].replies && list[i].replies.length && this.removeById(list[i].replies, id)) return true;
				}
				return false;
			},

			ratingClass: function (comment) {
				if (comment.rating > 0) return 'is-up';
				if (comment.rating < 0) return 'is-down';
				return '';
			}
		}
	});

	/* Рекурсивный компонент ветки: шаблон лежит в разметке (#rc-item).
	   К состоянию и методам обращается через $root — передавать инстанс
	   пропом через каждый уровень вложенности незачем. */
	app.component('rc-item', {
		name: 'rc-item',
		template: '#rc-item',
		props: {
			comment: { type: Object, required: true },
			indent:  { type: Number, default: 0 }
		}
	});

	app.mount('#reader-comments');
})();
