/**
 * reader-ux.js — Progressive UX layer for the comic reader.
 * No dependencies on Vue internals — hooks via DOM events only.
 *
 * Features:
 *  1. Chapter progress bar (inside sticky header)
 *  2. Auto-hide header on scroll-down, reveal on scroll-up
 *  3. Keyboard shortcuts: ← → Space = page nav, F = fullscreen
 *  4. Swipe left/right = page nav (paginated mode only)
 *  5. Double-tap = zoom 2.2× at tap point
 *  6. Long-press image = context menu (open in tab / cancel)
 *  7. Fullscreen button injected into header actions
 *  8. Haptic feedback (navigator.vibrate) on page navigation
 *  9. Reading streak counter via localStorage + yalert toast
 * 10. Prefetch next chapter HTML when user reaches last 2 pages
 */
(function () {
  'use strict';

  /* ── Utilities ────────────────────────────────────────────────────────────── */

  function vib(p) { if (navigator.vibrate) navigator.vibrate(p); }

  function getPageInfo() {
    var span = document.querySelector('.nav__pages span');
    if (!span) return null;
    var m = span.textContent.match(/(\d+)\s*\/\s*(\d+)/);
    return m ? { current: +m[1], total: +m[2] } : null;
  }

  /* Признак вертикальных режимов (Web/Infinite) — тот же, что использует свайп. */
  function isVerticalMode() {
    return !!document.querySelector('.chapter__selector-footer.chapter__selector-pad');
  }

  /* Кнопок [title="Next Page"] / [title="Previous Page"] в разметке нет: обе
     .nav__paginate-item — это «Scroll to Top». Старый navClick поэтому всегда
     возвращал false, из-за чего свайп на телефоне не листал вообще, а Space
     гасился preventDefault'ом и не делал ничего.
     Листает клик по самой странице (@click="readerClick" в main.tpl), он же
     выбирает направление по половине картинки — эмулируем именно его. */
  function navClick(dir) {
    var title = dir > 0 ? 'Next Page' : 'Previous Page';
    var btn = document.querySelector('.nav__paginate-item[title="' + title + '"]');
    if (btn && !btn.classList.contains('disabled')) { btn.click(); vib(10); return true; }

    /* readerClick в вертикальных режимах возвращает false — там листать нечем. */
    if (isVerticalMode()) return false;

    var list = document.querySelectorAll('.reader__item-wrap.active .reader__item');
    var img = null, bestVisible = 0;
    for (var i = 0; i < list.length; i++) {
      var r = list[i].getBoundingClientRect();
      if (r.width < 1 || r.height < 1) continue;
      var visible = Math.min(r.bottom, window.innerHeight) - Math.max(r.top, 0);
      if (visible > bestVisible) { bestVisible = visible; img = list[i]; }
    }
    if (!img) return false;

    var b = img.getBoundingClientRect();
    var x = b.left + b.width * (dir > 0 ? 0.75 : 0.25);
    var y = Math.min(Math.max(b.top + b.height / 2, 1), window.innerHeight - 1);
    img.dispatchEvent(new MouseEvent('click', {
      bubbles: true, cancelable: true, view: window, clientX: x, clientY: y
    }));
    vib(10);
    return true;
  }

  function isPopupOpen() {
    var pr = document.querySelector('.popup-root');
    return pr && getComputedStyle(pr).display !== 'none';
  }

  function getShareData() {
    var data = window.__DATA__ || {};
    var title = document.title || (data.post && data.post.title) || 'BatCave.biz';
    return {
      title: title,
      text: 'Experience the adventure - this comic awaits at Batcave.biz!',
      url: window.location.href.split('#')[0]
    };
  }

  function showShareToast(text, type) {
    if (window.yalert && typeof window.yalert.push === 'function') {
      window.yalert.push({ text: text, type: type || 'ok' });
      return;
    }

    var toast = document.createElement('div');
    toast.className = 'reader-share-toast';
    toast.textContent = text;
    toast.style.cssText = 'position:fixed;left:50%;bottom:24px;z-index:1900;transform:translateX(-50%);max-width:calc(100vw - 32px);padding:10px 14px;border-radius:4px;background:#161719;color:#fff;font:600 14px/1.35 Arial,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.35)';
    document.body.appendChild(toast);
    setTimeout(function () {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity .2s ease';
      setTimeout(function () {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 220);
    }, 1800);
  }

  function copyShareUrl(url, done, fail) {
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(url).then(done).catch(fail);
      return;
    }

    var input = document.createElement('textarea');
    input.value = url;
    input.setAttribute('readonly', '');
    input.style.cssText = 'position:fixed;top:-1000px;left:-1000px';
    document.body.appendChild(input);
    input.select();

    try {
      if (document.execCommand('copy')) done();
      else fail();
    } catch (e) {
      fail();
    }

    document.body.removeChild(input);
  }

  function initShareButton() {
    var btn = document.getElementById('shareButton');
    if (!btn || btn.dataset.shareReady === '1') return;

    btn.dataset.shareReady = '1';
    btn.addEventListener('click', function (e) {
      e.preventDefault();

      var shareData = getShareData();
      var copied = function () { showShareToast('Link copied', 'ok'); };
      var failed = function () { showShareToast('Share is not available here', 'error'); };

      if (navigator.share) {
        navigator.share(shareData).then(function () {
          showShareToast('Thanks for sharing', 'ok');
        }).catch(function (err) {
          if (err && err.name === 'AbortError') return;
          copyShareUrl(shareData.url, copied, failed);
        });
        return;
      }

      copyShareUrl(shareData.url, copied, failed);
    });
  }

  var installPromptEvent = null;

  function registerServiceWorker() {
    if (!('serviceWorker' in navigator)) return;
    /* Тот же URL, что у libs.js на остальном сайте: разные URL на одном scope переустанавливают SW,
       а снятие регистрации удаляло бы и push-подписку. SW не кэширует страницу читалки и картинки. */
    navigator.serviceWorker.register('/sw.js?1.0.1').catch(function () {});
  }

  function isStandaloneApp() {
    return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) ||
           window.navigator.standalone === true;
  }

  function isIosDevice() {
    return /iPad|iPhone|iPod/.test(navigator.userAgent) ||
           (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  }

  function isSafariBrowser() {
    return /Safari/i.test(navigator.userAgent) &&
           !/Chrome|CriOS|FxiOS|EdgiOS|OPiOS|Android/i.test(navigator.userAgent);
  }

  function canShowSafariInstallHelp() {
    return isSafariBrowser() && !isStandaloneApp();
  }

  function setInstallButtonVisible(visible) {
    var btn = document.getElementById('installBtn');
    if (!btn) return;

    btn.style.display = visible ? 'inline' : 'none';
  }

  function updateInstallButton() {
    setInstallButtonVisible((!!installPromptEvent || canShowSafariInstallHelp()) && !isStandaloneApp());
  }

  function closeInstallSheet() {
    var sheet = document.getElementById('reader-install-sheet');
    if (!sheet) return;

    sheet.classList.remove('visible');
    setTimeout(function () {
      if (sheet.parentNode) sheet.parentNode.removeChild(sheet);
    }, 220);
  }

  function showSafariInstallHelp() {
    closeInstallSheet();

    var ios = isIosDevice();
    var sheet = document.createElement('div');
    sheet.id = 'reader-install-sheet';
    sheet.className = 'reader-install-sheet';
    sheet.setAttribute('role', 'dialog');
    sheet.setAttribute('aria-modal', 'true');
    sheet.setAttribute('aria-labelledby', 'reader-install-title');

    var steps = ios
      ? [
          ['fa-share-square-o', 'Tap Share in Safari'],
          ['fa-plus-square-o', 'Choose Add to Home Screen'],
          ['fa-check', 'Tap Add']
        ]
      : [
          ['fa-safari', 'Open Safari menu'],
          ['fa-plus-square-o', 'Choose Add to Dock'],
          ['fa-check', 'Confirm Add']
        ];

    sheet.innerHTML =
      '<button type="button" class="reader-install-sheet__backdrop" data-install-close aria-label="Close"></button>' +
      '<div class="reader-install-sheet__panel">' +
        '<div class="reader-install-sheet__head">' +
          '<div id="reader-install-title" class="reader-install-sheet__title">Install BatCave</div>' +
          '<button type="button" class="reader-install-sheet__close" data-install-close>Done</button>' +
        '</div>' +
        '<ol class="reader-install-sheet__steps">' +
          steps.map(function (step) {
            return '<li><span class="reader-install-sheet__icon fa ' + step[0] + '"></span><span>' + step[1] + '</span></li>';
          }).join('') +
        '</ol>' +
      '</div>';

    sheet.addEventListener('click', function (e) {
      if (e.target && e.target.hasAttribute('data-install-close')) closeInstallSheet();
    });

    document.addEventListener('keydown', function esc(e) {
      if (e.key !== 'Escape') return;
      document.removeEventListener('keydown', esc);
      closeInstallSheet();
    });

    document.body.appendChild(sheet);
    requestAnimationFrame(function () {
      sheet.classList.add('visible');
    });
  }

  function initInstallButton() {
    var btn = document.getElementById('installBtn');
    if (!btn || btn.dataset.installReady === '1') return;

    btn.dataset.installReady = '1';
    btn.addEventListener('click', function (e) {
      e.preventDefault();

      if (!installPromptEvent) {
        updateInstallButton();
        if (canShowSafariInstallHelp()) {
          showSafariInstallHelp();
          return;
        }
        showShareToast('Install is not available in this browser', 'error');
        return;
      }

      var promptEvent = installPromptEvent;
      installPromptEvent = null;
      setInstallButtonVisible(false);

      promptEvent.prompt();
      promptEvent.userChoice.then(function (choiceResult) {
        if (choiceResult && choiceResult.outcome === 'accepted') {
          showShareToast('Install started', 'ok');
        }
      }).catch(function () {
        showShareToast('Install is not available here', 'error');
      });
    });

    updateInstallButton();
  }

  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    installPromptEvent = e;
    updateInstallButton();
  });

  window.addEventListener('appinstalled', function () {
    installPromptEvent = null;
    updateInstallButton();
    showShareToast('App installed', 'ok');
  });

  registerServiceWorker();

  /* ── Main setup (runs after Vue has mounted) ───────────────────────────────── */

  function setup() {
    var header     = document.querySelector('.header');
    var readerView = document.querySelector('.reader-view');
    var actionsEl  = document.querySelector('.actions');
    var navPages   = document.querySelector('.nav__pages');

    /* Guard: abort silently if critical elements are missing */
    if (!header || !readerView) return;

    /* ── 1. Reveal-on-scroll-up header (перенесено с com-x) ─────────────────
       Шапка sticky и спрятана над экраном (body.css: top:-54px).
       Скролл вверх — выезжает (.visible), скролл вниз — прячется.
       Тумблер settings.showHeader: 0 = не показывать никогда.
       Значение читаем из того же localStorage-ключа, что и Vue, и
       обновляем по клику на кнопки [data-hdr-pref] в попапе настроек —
       так libs.min.js править не приходится.                            */
    var headerPref = 1;
    try {
      var s = JSON.parse(localStorage.getItem('reader__settings') || '{}');
      if (s && s.showHeader !== undefined) headerPref = s.showHeader ? 1 : 0;
    } catch (e) {}

    function showHeaderBar(on) {
      header.classList.toggle('visible', !!on && headerPref === 1);
    }

    document.addEventListener('click', function (e) {
      var t = e.target.closest && e.target.closest('[data-hdr-pref]');
      if (!t) return;
      headerPref = +t.getAttribute('data-hdr-pref') ? 1 : 0;
      showHeaderBar(headerPref === 1);
    });

    /* Уводим шапку, когда курсор её покинул — как на com-x */
    header.addEventListener('mouseleave', function () { showHeaderBar(false); });

    var lastY = window.scrollY, ticking = false;
    window.addEventListener('scroll', function () {
      if (!ticking) {
        requestAnimationFrame(function () {
          var y = window.scrollY;
          // Прокрутку сделало перелистывание (libs.min.js scrollPage, #118): картинка у верха экрана,
          // шапку не показываем, иначе она закроет начало страницы
          if (Date.now() - (window.__rdrScrollAt || 0) < 400) { showHeaderBar(false); lastY = y; ticking = false; return; }
          if      (y > lastY + 8 && y > 60) showHeaderBar(false);
          else if (y < lastY - 8)           showHeaderBar(true);
          lastY = y;
          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });

    /* На старте показываем, если пользователь не отключил */
    showHeaderBar(true);

    /* ── 1b. Webtoon-детект (перенесено с com-x) ───────────────────────────
       Длинная вертикальная полоса вместо страницы: высота ≥3000 и
       отношение высоты к ширине ≥5 — критерий взят у эталона. Для таких
       страниц режим «Разворот» бессмыслен, поэтому гасим его кнопку.
       Помечаем body, чтобы правило жило в CSS и переживало перерисовку
       попапа настроек (он рендерится по v-if только при открытии).        */
    function detectWebtoon() {
      if (document.body.dataset.webtoon) return;
      var img = readerView.querySelector('.reader__item');
      if (!img || !img.naturalWidth) return;
      var w = img.naturalWidth, h = img.naturalHeight;
      if (w > 0 && h >= 3000 && (h / w) >= 5) document.body.dataset.webtoon = '1';
    }
    readerView.addEventListener('load', detectWebtoon, true);
    setTimeout(detectWebtoon, 1500);

    /* ── 1c. Фоновый звук в попапе настроек (перенесено с com-x) ───────────
       На com-x звук живёт в Vue-настройках (ambientSound/Type/Volume).
       У нас он — самостоятельный модуль reader-sounds.js со своим
       состоянием, поэтому не переносим его в Vue (переписывание рабочего
       звука ради единообразия — лишний риск), а дотягиваемся до его
       публичного API window.readerAmbientSounds.                          */
    function paintSoundRow() {
      var row = document.querySelector('[data-snd-row]');
      if (!row || !window.readerAmbientSounds) return;
      var on = false;
      try { on = !!window.readerAmbientSounds.state().enabled; } catch (e) {}
      var btnOn = row.querySelector('[data-snd="on"]');
      var btnOff = row.querySelector('[data-snd="off"]');
      if (btnOn)  btnOn.classList.toggle('active', on);
      if (btnOff) btnOff.classList.toggle('active', !on);
    }

    document.addEventListener('click', function (e) {
      var t = e.target.closest && e.target.closest('[data-snd]');
      if (t) {
        e.preventDefault();
        var api = window.readerAmbientSounds;
        if (!api) return;
        var act = t.getAttribute('data-snd');
        if      (act === 'on')   api.play();
        else if (act === 'off')  api.stop();
        else if (act === 'pick') api.open();
        setTimeout(paintSoundRow, 60);
        return;
      }
      /* Попап настроек рендерится по v-if — подсвечиваем ряд после отрисовки */
      if (e.target.closest && e.target.closest('[title="Reader Settings"]')) {
        setTimeout(paintSoundRow, 120);
      }
    });

    /* ── 3. Keyboard shortcuts ─────────────────────────────────────────────── */
    document.addEventListener('keydown', function (e) {
      var tag = document.activeElement.tagName;
      if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
      if (isPopupOpen()) return;
      /* Стрелки обрабатывает само приложение (window keyup 37/39 → goToPage),
         поэтому здесь их трогать нельзя — иначе одно нажатие даёт два шага. */
      if (e.key === ' ') {
        /* Space листает только постранично. В Web/Infinite его нельзя
           перехватывать — там он обязан прокручивать страницу нативно. */
        if (!isVerticalMode()) { e.preventDefault(); navClick(1); }
      }
      else if (e.key === 'f' || e.key === 'F')           { e.preventDefault(); toggleFS();  }
    });

    /* ── 4 + 5. Touch: swipe / double-tap / long-press ─────────────────────── */
    var tx0 = 0, ty0 = 0, tt0 = 0;
    var lastTapTime = 0, lastTapEl = null, lastTapX = 0, lastTapY = 0;
    var lpTimer = null, lpFired = false;
    var zoomEl = null, zoomed = false;
    /* Flag: true while ≥2 fingers are on screen (pinch-to-zoom gesture).
       Prevents swipe/double-tap/long-press from firing during pinch. */
    var isMultiTouch = false;

    readerView.addEventListener('touchstart', function (e) {
      /* ── Multi-touch (pinch): abort all single-touch logic ── */
      if (e.touches.length > 1) {
        isMultiTouch = true;
        clearTimeout(lpTimer); lpTimer = null;
        return;
      }
      isMultiTouch = false;

      var t = e.touches[0];
      tx0 = t.clientX; ty0 = t.clientY; tt0 = Date.now();
      lpFired = false;

      lpTimer = setTimeout(function () {
        /* Extra guard: don't fire if a second finger was added later */
        if (isMultiTouch) return;
        lpFired = true;
        var img = e.target.closest('.reader__item');
        if (img) showImgMenu(img, t.clientX, t.clientY);
      }, 600);
    }, { passive: true });

    readerView.addEventListener('touchmove', function (e) {
      /* If a second finger appeared mid-gesture, cancel single-touch logic */
      if (e.touches.length > 1) {
        isMultiTouch = true;
        clearTimeout(lpTimer); lpTimer = null;
      } else {
        clearTimeout(lpTimer); lpTimer = null;
      }
    }, { passive: true });

    readerView.addEventListener('touchend', function (e) {
      clearTimeout(lpTimer); lpTimer = null;

      /* Skip if this was part of a multi-touch gesture.
         Reset only when ALL fingers are lifted. */
      if (isMultiTouch) {
        if (e.touches.length === 0) isMultiTouch = false;
        return;
      }
      if (lpFired) return;

      var t  = e.changedTouches[0];
      var dx = t.clientX - tx0;
      var dy = t.clientY - ty0;
      var dt = Date.now() - tt0;

      /* Horizontal swipe → page navigation.
         Skip: multi-touch, zoomed image, vertical reading mode. */
      var isVertical = document.querySelector('.chapter__selector-footer.chapter__selector-pad');
      if (!zoomed && !isVertical &&
          Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 70 && dt < 400) {
        navClick(dx < 0 ? 1 : -1);
        return;
      }

      /* Double-tap → zoom (skip if panned significantly) */
      if (Math.abs(dx) > 20 || Math.abs(dy) > 20) return;
      var img = e.target.closest('.reader__item');
      var now = Date.now();
      var tapDist = Math.sqrt(
        Math.pow(t.clientX - lastTapX, 2) + Math.pow(t.clientY - lastTapY, 2)
      );
      if (img && now - lastTapTime < 300 && lastTapEl === img && tapDist < 40) {
        e.preventDefault();
        toggleZoom(img, t.clientX, t.clientY);
        lastTapTime = 0; lastTapX = 0; lastTapY = 0;
      } else {
        lastTapTime = now;
        lastTapEl   = img;
        lastTapX    = t.clientX;
        lastTapY    = t.clientY;
      }
    });

    /* ── 5. Double-tap zoom implementation ─────────────────────────────────── */
    /* Обёртка обрезает увеличенную страницу: без этого transform выносил её за
       свою коробку и она закрывала соседнюю — жалоба про наложение на разворотах. */
    function clipWrap(img, on) {
      var w = img && img.closest ? img.closest('.reader__item-wrap') : null;
      if (w) w.classList.toggle('is-zoomed', !!on);
    }

    function clearZoom() {
      if (!zoomEl) return;
      zoomEl.style.transform = '';
      clipWrap(zoomEl, false);
      zoomed = false; zoomEl = null;
    }

    function toggleZoom(img, cx, cy) {
      if (zoomed && zoomEl === img) {
        clearZoom();
      } else {
        clearZoom();
        var r = img.getBoundingClientRect();
        img.style.transformOrigin =
          ((cx - r.left) / r.width  * 100) + '% ' +
          ((cy - r.top)  / r.height * 100) + '%';
        img.style.transform = 'scale(2.2)';
        clipWrap(img, true);
        zoomed = true; zoomEl = img;
        vib(8);
      }
    }

    /* Reset zoom when navigating pages.
       Страницы листают кликом по самой картинке, поэтому одиночный клик по
       ЛЮБОЙ картинке снимает зум (двойной тап до этого места не доходит —
       touchend вызывает toggleZoom и гасит событие). */
    document.addEventListener('click', function (e) {
      if (!zoomEl) return;
      if (e.target.closest('.reader__item, .nav__paginate-item, .chapter__selector-footer__item, .chapter__selector-trigger, .popup__chapters a')) {
        clearZoom();
      }
    }, true);

    /* Смена страницы стрелками/селектом зум тоже снимает. */
    document.addEventListener('keyup', function (e) {
      if (zoomEl && (e.key === 'ArrowLeft' || e.key === 'ArrowRight' || e.key === 'Escape')) clearZoom();
    });

    /* ── 5b. Широкий разворот в spread-режиме занимает всю строку ───────────
       Двухстраничный скан одним файлом попадал в колонку 50% и рисовался вдвое
       мельче обычной страницы рядом. Пропорции берём из самой картинки. */
    var wideRaf = 0;
    function markWideSpreads() {
      wideRaf = 0;
      var view = document.querySelector('.reader-view');
      if (!view) return;
      var spread = view.classList.contains('spread-mode');
      var imgs = view.querySelectorAll('.reader__item');
      for (var i = 0; i < imgs.length; i++) {
        var img = imgs[i];
        var wrap = img.closest ? img.closest('.reader__item-wrap') : null;
        if (!wrap) continue;
        var w = img.naturalWidth, h = img.naturalHeight;
        wrap.classList.toggle('is-wide', spread && w > 0 && h > 0 && (w / h) > 1.2);
        wrap.classList.remove('is-wide-neighbour');
      }
      /* Строка spread не переносится, поэтому доли обеих страниц пары должны
         укладываться в 100%: соседа широкой ужимаем, иначе разворот уезжает
         за край экрана. */
      if (spread) {
        var act = view.querySelectorAll('.reader__item-wrap.active');
        if (act.length === 2) {
          if (act[0].classList.contains('is-wide') && !act[1].classList.contains('is-wide')) {
            act[1].classList.add('is-wide-neighbour');
          } else if (act[1].classList.contains('is-wide') && !act[0].classList.contains('is-wide')) {
            act[0].classList.add('is-wide-neighbour');
          }
        }
      }
    }
    function scheduleWideScan() {
      if (wideRaf) return;
      wideRaf = requestAnimationFrame(markWideSpreads);
    }
    document.addEventListener('load', function (e) {
      if (e.target && e.target.classList && e.target.classList.contains('reader__item')) scheduleWideScan();
    }, true);
    (function () {
      var view = document.querySelector('.reader-view');
      if (!view || typeof MutationObserver === 'undefined') return;
      new MutationObserver(scheduleWideScan).observe(view, {
        attributes: true, attributeFilter: ['class'], subtree: true, childList: true
      });
      scheduleWideScan();
    })();

    /* ── 6. Long-press image context menu ──────────────────────────────────── */
    /* contextmenu is NOT prevented — suppression broke Google Lens native integration */

    var imgMenu = document.createElement('div');
    imgMenu.id = 'reader-img-menu';
    imgMenu.innerHTML =
      '<a id="img-tab"><i class="fa fa-external-link fa-fw"></i> Open in New Tab</a>' +
      '<a id="img-cancel"><i class="fa fa-times fa-fw"></i> Cancel</a>';
    document.body.appendChild(imgMenu);

    var imgTarget = null;

    function showImgMenu(img, x, y) {
      imgTarget = img;
      imgMenu.classList.add('visible');
      imgMenu.style.left = Math.min(x, window.innerWidth  - 220) + 'px';
      imgMenu.style.top  = Math.min(y, window.innerHeight - 110) + 'px';
      vib([10, 40, 10]);
    }

    function hideImgMenu() { imgMenu.classList.remove('visible'); }

    document.getElementById('img-tab').addEventListener('click', function () {
      if (imgTarget) window.open(imgTarget.src, '_blank');
      hideImgMenu();
    });

    document.getElementById('img-cancel').addEventListener('click', hideImgMenu);

    document.addEventListener('touchstart', function (e) {
      if (!imgMenu.contains(e.target)) hideImgMenu();
    }, { passive: true });

    /* ── 7. Fullscreen button (desktop only) ───────────────────────────────── */
    if (actionsEl) {
      var fsBtn = document.createElement('a');
      fsBtn.id        = 'reader-fs-btn';
      fsBtn.className = 'action__item';
      fsBtn.href      = '#';
      fsBtn.title     = 'Fullscreen (F)';
      fsBtn.innerHTML = '<i class="fa fa-expand" id="fs-icon"></i>';
      fsBtn.addEventListener('click', function (e) { e.preventDefault(); toggleFS(); });

      var settingsBtn = actionsEl.querySelector('[title="Reader Settings"]');
      actionsEl.insertBefore(fsBtn, settingsBtn || null);
    }

    function toggleFS() {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(function () {});
        vib(15);
      } else {
        document.exitFullscreen();
      }
    }

    document.addEventListener('fullscreenchange', function () {
      var ic = document.getElementById('fs-icon');
      if (ic) ic.className = document.fullscreenElement ? 'fa fa-compress' : 'fa fa-expand';
    });

    initShareButton();
    initInstallButton();

    /* ── 8. Haptic feedback on existing nav buttons ─────────────────────────── */
    document.querySelectorAll('.nav__paginate-item').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (!this.classList.contains('disabled')) vib(10);
      });
    });


    /* ── 10. Prefetch next chapter when near the end ────────────────────────── */
    function prefetchNext() {
      var nextIcon = document.querySelector(
        '.chapter__selector .chapter__selector-icon:last-child:not(.disabled)'
      );
      if (!nextIcon) return;
      var href = nextIcon.getAttribute('href');
      if (!href || href === '#' || href === 'undefined' || href === 'null') return;
      if (document.querySelector('link[rel="prefetch"][href="' + href + '"]')) return;
      var lnk = document.createElement('link');
      lnk.rel = 'prefetch'; lnk.href = href;
      document.head.appendChild(lnk);
    }

    if (navPages) {
      new MutationObserver(function () {
        var info = getPageInfo();
        if (info && info.current >= info.total - 1) prefetchNext();
      }).observe(navPages, { subtree: true, childList: true, characterData: true });
    }
  }

  /* ── Boot: poll until Vue has mounted ──────────────────────────────────────── */
  function boot(n) {
    var root = document.querySelector('.reader-root');
    if (root && !root.hasAttribute('v-cloak') && document.querySelector('.nav__paginate-item')) {
      setup();
    } else if ((n || 0) < 60) {
      setTimeout(function () { boot((n || 0) + 1); }, 150);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { boot(); });
  } else {
    boot();
  }

})();

/* ── Reader Feedback popup handlers ───────────────────────────────────────────
   Используют global sendAjax / window.__DATA__ / reader (Vue app) из libs.min.js.
   Делаем native DOM вместо Vue-component, чтобы не пересобирать libs.min.js. */
window.readerFeedbackPick = function (el) {
  var row = document.getElementById('feedback-reasons-row');
  if (!row) return;
  Array.prototype.forEach.call(row.querySelectorAll('.settings__row-item'), function (a) {
    a.classList.remove('active');
  });
  el.classList.add('active');
};

window.readerFeedbackCaptchaChanged = function (input) {
  var btn = document.getElementById('feedback-submit-btn');
  var data = window.__DATA__ || {};
  if (!btn) return;
  if (btn.dataset.sending === '1') return;
  if ((input.value || '').trim() && data.feedback_challenge && data.feedback_challenge.token) {
    btn.classList.remove('disabled');
  } else {
    btn.classList.add('disabled');
  }
};

window.readerFeedbackSubmit = function () {
  var btn  = document.getElementById('feedback-submit-btn');
  var msg  = document.getElementById('feedback-status-msg');
  var row  = document.getElementById('feedback-reasons-row');
  var area = document.getElementById('feedback-text');
  var cap  = document.getElementById('feedback-captcha');
  var hp   = document.getElementById('feedback-homepage');
  if (!btn || !msg || !row || !area || !cap) return;
  if (btn.dataset.sending === '1') return;

  var pick = row.querySelector('.settings__row-item.active');
  var reason = pick ? pick.getAttribute('data-reason') : 'broken';
  var text   = (area.value || '').trim();
  var data   = window.__DATA__ || {};
  var challenge = data.feedback_challenge || {};
  var captchaAnswer = (cap.value || '').trim();
  var payload = {
    news_id:    data.news_id    || 0,
    chapter_id: data.chapter_id || 0,
    reason:     reason,
    text:       text,
    captcha_answer: captchaAnswer,
    captcha_a: challenge.a || 0,
    captcha_b: challenge.b || 0,
    captcha_expires: challenge.expires || 0,
    captcha_nonce: challenge.nonce || '',
    captcha_token: challenge.token || '',
    feedback_homepage: hp ? hp.value : ''
  };
  if (!payload.news_id) {
    showMsg('Cannot submit — page data missing', 'error');
    return;
  }
  if (!payload.captcha_token) {
    showMsg('Anti-spam check is not ready. Reload the page.', 'error');
    return;
  }
  if (!captchaAnswer) {
    showMsg('Please solve the anti-spam question.', 'error');
    cap.focus();
    return;
  }

  btn.classList.add('disabled');
  btn.dataset.sending = '1';
  showMsg('Sending...', 'info');

  if (typeof axios !== 'function') {
    showMsg('Error: AJAX layer not loaded. Reload the page.', 'error');
    btn.classList.remove('disabled');
    delete btn.dataset.sending;
    return;
  }

  axios({
    method: 'POST',
    url: '/engine/ajax/controller.php?mod=api&action=reader/submitFeedback',
    responseType: 'json',
    data: payload,
    timeout: 15000
  }).then(function (resp) {
    var body = resp && resp.data ? resp.data : {};
    if (!body.success) {
      showMsg(body.error || 'Could not send report. Try again.', 'error');
      delete btn.dataset.sending;
      btn.classList.remove('disabled');
      return;
    }

    showMsg(body.data && body.data.message ? body.data.message : 'Thanks!', 'ok');
    area.value = '';
    cap.value = '';
    btn.classList.add('disabled');
    setTimeout(function () {
      // Окно Report после отправки не закрывалось: у app нет closePopup, а _instance в прод-Vue пуст.
      // Корневой компонент берём через контейнер, как share-prompt.js getVm().
      try {
        var rootEl = document.querySelector('.reader-root');
        var vm = rootEl && rootEl._vnode && rootEl._vnode.component && rootEl._vnode.component.proxy;
        if (vm && vm.closePopup) vm.closePopup();
      } catch (e) {}
      var msgEl = document.getElementById('feedback-status-msg');
      if (msgEl) msgEl.style.display = 'none';
      delete btn.dataset.sending;
    }, 1600);
  }).catch(function (error) {
    console.log(error);
    showMsg('Request failed. Try again in a minute.', 'error');
    delete btn.dataset.sending;
    btn.classList.remove('disabled');
  });

  function showMsg(text, type) {
    msg.style.display = 'block';
    msg.textContent   = text;
    msg.style.color   = type === 'error' ? '#ff7a7a'
                      : type === 'ok'    ? '#7aff8a'
                                         : '';
  }
};
