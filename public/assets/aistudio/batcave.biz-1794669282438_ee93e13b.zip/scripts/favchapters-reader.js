/*
 * Favourite chapters in the reader — standalone, no framework.
 * Markup differs per site, so the anchors come from window.__FAVCH_CFG__:
 *   navBefore  — the node the end-of-chapter block is inserted before
 *   tocItem    — chapter links in the table of contents
 * Data comes from window.__FAVCH__ (text reader) or window.__DATA__ (Vue reader).
 */
(function () {
	var D = window.__FAVCH__ || window.__DATA__;
	if (!D || !D.chapter_id) return;

	var C = window.__FAVCH_CFG__ || {};
	var sel = {
		navBefore: C.navBefore || '.reader-root .nav',
		slot: C.slot || '.favch-slot',
		infiniteMark: C.infiniteMark || '.chapter-separator',
		observe: C.observe || '.reader-root',
		page: C.page || '.reader__item-wrap',
		pageAttr: C.pageAttr || 'data-page',
		tocItem: C.tocItem || '.chapters__item'
	};
	var L = window.__FAVCH_LANG__ || {};
	var t = function (k, d) { return L[k] || d; };

	var favs = D.fav_chapters || {};
	function isFav(id) { return favs[id] !== undefined; }

	function post(action, data, done, fail) {
		data.user_hash = D.user_hash || (typeof dle_login_hash !== 'undefined' ? dle_login_hash : '');
		return fetch('/engine/ajax/controller.php?mod=api&action=favchapters/' + action, {
			method: 'POST', credentials: 'same-origin',
			headers: {'Content-Type': 'application/json'}, body: JSON.stringify(data)
		}).then(function (r) { return r.json(); }).then(function (d) {
			if (d && d.success) done(d.data);
			else { fail && fail(); alert((d && d.error) || 'Error'); }
		}).catch(function () {
			fail && fail();
			alert(t('net_error', 'No connection, please try again'));
		});
	}

	var busy = false;

	function toggle(id, after) {
		if (!D.is_logged) { alert(t('guest', 'Sign in to save favourite chapters')); return; }
		if (busy) return;                       // двойной тап иначе добавляет и сразу убирает
		busy = true;
		post('toggle', {news_id: D.news_id, chapter_id: id}, function (res) {
			busy = false;
			if (res.active) favs[id] = ''; else delete favs[id];
			render();
			after && after();
		}, function () { busy = false; });
	}

	/* Кнопка «в любимые» уместна в конце главы, а не на каждой странице:
	   в постраничном режиме показываем только на последней, в вертикальном и
	   бесконечном блок и так стоит под всеми страницами. */
	function atChapterEnd() {
		// в бесконечной ленте подгружены соседние главы, а карточка одна и знает
		// только первую — чтобы не сохранить чужую главу, прячем её
		if (document.querySelector(sel.infiniteMark)) return false;
		var active = document.querySelectorAll(sel.page + '.active');
		if (!active.length) return true;          // текстовая читалка: страниц нет
		var total = parseInt(D.pages, 10) || 0;
		if (!total) return true;

		// в развороте активны сразу две страницы, поэтому «много активных» само по
		// себе не означает конец главы — смотрим максимальный видимый номер
		var last = 0;
		for (var i = 0; i < active.length; i++) {
			last = Math.max(last, parseInt(active[i].getAttribute(sel.pageAttr), 10) || 0);
		}
		if (!last) return true;                   // вертикальный/бесконечный: номеров нет
		return last >= total;
	}

	function endBlock() {
		// Слот объявлен в шаблоне с v-pre: Vue его не перерисовывает, и карточка
		// переживает смену страницы. Нет слота — запасной путь, вставка перед .nav
		var slot = document.querySelector(sel.slot);
		var nav = slot ? null : document.querySelector(sel.navBefore);
		if (!slot && !nav) return null;
		if (!atChapterEnd()) {
			var gone = document.querySelector('.favch-end');
			gone && gone.remove();
			return null;
		}
		var el = document.querySelector('.favch-end');
		if (!el) {
			el = document.createElement('div');
			el.className = 'favch-end';
			el.innerHTML =
				'<div class="favch-end__row">' +
					'<div class="favch-end__icon" aria-hidden="true"><i class="fa fa-heart"></i></div>' +
					'<div class="favch-end__text"><div class="favch-end__title"></div><div class="favch-end__sub"></div></div>' +
					'<button type="button" class="favch-end__cta" aria-pressed="false"></button>' +
				'</div>' +
				'<input class="favch-end__note" type="text" maxlength="' + (parseInt(D.note_length, 10) || 200) + '" placeholder="' + t('note', 'Chapter note (optional)') + '" aria-label="' + t('note', 'Chapter note (optional)') + '">' +
				'<a class="favch-end__link" href="/favchapters/">' + t('all', 'All favourites') + '</a>';
			el.querySelector('.favch-end__cta').addEventListener('click', function () {
				toggle(D.chapter_id, function () { isFav(D.chapter_id) && el.querySelector('.favch-end__note').focus(); });
			});
			var note = el.querySelector('.favch-end__note');
			note.addEventListener('change', function () {
				if (!isFav(D.chapter_id)) return;   // поле скрыто, но событие могло долететь
				if (note.dataset.busy) return;
				note.dataset.busy = '1';
				post('note', {chapter_id: D.chapter_id, note: note.value}, function (res) {
					delete note.dataset.busy;
					favs[D.chapter_id] = note.value = (res && typeof res.note === 'string') ? res.note : note.value;
					note.classList.remove('is-error');
					note.classList.add('is-saved');
					setTimeout(function () { note.classList.remove('is-saved'); }, 1200);
				}, function () {
					// текст не трогаем: пользователь видит ошибку и может повторить
					delete note.dataset.busy;
					note.classList.add('is-error');
				});
			});
			note.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); note.blur(); } });
		}
		if (slot) {
			if (el.parentNode !== slot) slot.appendChild(el);
		} else if (el.parentNode !== nav.parentNode || el.nextSibling !== nav) {
			nav.parentNode.insertBefore(el, nav);
		}
		return el;
	}

	function toc() {
		var items = document.querySelectorAll(sel.tocItem);
		for (var i = 0; i < items.length; i++) {
			var a = items[i], m = (a.getAttribute('href') || '').match(/\/(\d+)\/?$/);
			var on = m && isFav(+m[1]);
			var mark = a.querySelector('.chapters__fav');
			if (on && !mark) {
				mark = document.createElement('i');
				mark.className = 'fa fa-heart chapters__fav';
				mark.setAttribute('aria-hidden', 'true');
				a.insertBefore(mark, a.firstChild);
			} else if (!on && mark) mark.remove();
		}
	}

	/* Пишем только при фактическом изменении: наблюдатель слушает тот же DOM,
	   и безусловная перезапись textContent/класса будит render() по кругу. */
	function setText(el, v) { if (el && el.textContent !== v) el.textContent = v; }
	function setAttr(el, k, v) { if (el && el.getAttribute(k) !== v) el.setAttribute(k, v); }
	function setClass(el, cls, on) { if (el && el.classList.contains(cls) !== on) el.classList.toggle(cls, on); }

	function render() {
		var on = isFav(D.chapter_id);
		var end = endBlock();
		if (end) {
			setClass(end, 'is-on', on);
			setText(end.querySelector('.favch-end__title'), on ? t('end_title_on', 'Chapter saved') : t('end_title_off', 'Enjoyed this chapter?'));
			setText(end.querySelector('.favch-end__sub'), on ? t('end_sub_on', 'Find it in Favourite Chapters') : t('end_sub_off', 'Save it to re-read later'));
			var cta = end.querySelector('.favch-end__cta');
			setText(cta, on ? t('end_cta_on', 'Remove') : t('end_cta_off', 'Save'));
			setAttr(cta, 'aria-pressed', on ? 'true' : 'false');
			var note = end.querySelector('.favch-end__note');
			var val = favs[D.chapter_id] || '';
			if (document.activeElement !== note && note.value !== val) note.value = val;
		}
		toc();
	}

	/* Текстовая читалка рендерится до инициализации DLE: авторизации и хеша там нет,
	   поэтому состояние спрашиваем отдельным read-only запросом. */
	function loadState(next) {
		// needs_state ставит только текстовая читалка: она рендерится до инициализации
		// DLE, и её is_logged/user_hash недостоверны. На Vue-читалках данные точные.
		if (D.user_hash || !D.needs_state || D.has_auth === false) { next(); return; }
		fetch('/engine/ajax/controller.php?mod=api&action=favchapters/state', {
			method: 'POST', credentials: 'same-origin',
			headers: {'Content-Type': 'application/json'}, body: JSON.stringify({news_id: D.news_id})
		}).then(function (r) { return r.json(); }).then(function (d) {
			if (d && d.success && d.data) {
				D.is_logged = !!d.data.is_logged;
				D.user_hash = d.data.user_hash || '';
				favs = d.data.fav_chapters || {};
			}
		}).catch(function () {}).then(next);
	}

	function boot() {
		render();
		/* В читалке мутации идут потоком (ленивые картинки, реклама), поэтому
		   чистый debounce никогда не срабатывал бы: держим верхний предел ожидания. */
		var last = 0;
		function schedule(obs) {
			var now = Date.now();
			if (now - last > 400) { last = now; render(); return; }
			clearTimeout(obs._t);
			obs._t = setTimeout(function () { last = Date.now(); render(); }, 80);
		}
		var obs = new MutationObserver(function () { schedule(obs); });
		var scope = document.querySelector(sel.observe) || document.body;
		obs.observe(scope, {childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'data-page']});
		window.addEventListener('hashchange', render);
	}

	function start() { loadState(boot); }
	document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', function () { setTimeout(start, 300); }) : setTimeout(start, 300);
})();
