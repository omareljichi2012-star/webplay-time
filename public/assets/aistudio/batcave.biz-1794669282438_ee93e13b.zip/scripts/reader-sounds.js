(function() {
	'use strict';

	var script = document.currentScript || {};
	var lang = ((script.dataset && script.dataset.lang) || document.documentElement.lang || 'en').toLowerCase();
	var isRu = lang.indexOf('ru') === 0;
	var labels = isRu ? {
		button: '\u0424\u043e\u043d\u043e\u0432\u044b\u0439 \u0437\u0432\u0443\u043a',
		title: '\u0424\u043e\u043d\u043e\u0432\u044b\u0439 \u0437\u0432\u0443\u043a',
		close: '\u0413\u043e\u0442\u043e\u0432\u043e',
		volume: '\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c',
		off: '\u0412\u044b\u043a\u043b',
		room: '\u041a\u043e\u043c\u043d\u0430\u0442\u0430',
		rain: '\u0414\u043e\u0436\u0434\u044c',
		fire: '\u041a\u0430\u043c\u0438\u043d',
		forest: '\u041b\u0435\u0441',
		sea: '\u041c\u043e\u0440\u0435',
		wind: '\u0412\u0435\u0442\u0435\u0440',
		train: '\u041f\u043e\u0435\u0437\u0434',
		cave: '\u041f\u0435\u0449\u0435\u0440\u0430',
		thunder: '\u0413\u0440\u043e\u0437\u0430',
		gale: '\u0411\u0443\u0440\u044f \u0437\u0430 \u043e\u043a\u043d\u043e\u043c',
		city: '\u041d\u043e\u0447\u043d\u043e\u0439 \u0433\u043e\u0440\u043e\u0434',
		dark: '\u041c\u0440\u0430\u043a',
		unavailable: '\u0417\u0432\u0443\u043a \u043d\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044f \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u043e\u043c',
		blocked: '\u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u0435\u0449\u0435 \u0440\u0430\u0437, \u0447\u0442\u043e\u0431\u044b \u0437\u0430\u043f\u0443\u0441\u0442\u0438\u0442\u044c \u0437\u0432\u0443\u043a'
	} : {
		button: 'Background sound',
		title: 'Background Sound',
		close: 'Done',
		volume: 'Volume',
		off: 'Off',
		room: 'Room',
		rain: 'Rain',
		fire: 'Fireplace',
		forest: 'Forest',
		sea: 'Sea',
		wind: 'Wind',
		train: 'Train',
		cave: 'Cave',
		thunder: 'Thunderstorm',
		gale: 'Storm outside',
		city: 'Night city',
		dark: 'Darkness',
		unavailable: 'Background sound is not supported by this browser',
		blocked: 'Tap again to start sound'
	};
	var basePath = (script.dataset && script.dataset.audioBase) || '/templates/Default/modules/reader/assets/audio/ambient/';
	var storageKey = 'reader_ambient_settings';
	var resumeKey = 'reader_ambient_resume';
	var defaultType = 'room';
	var options = [
		{type: '', label: labels.off},
		{type: 'room', label: labels.room},
		{type: 'rain', label: labels.rain},
		{type: 'fire', label: labels.fire},
		{type: 'forest', label: labels.forest},
		{type: 'sea', label: labels.sea},
		{type: 'wind', label: labels.wind},
		{type: 'train', label: labels.train},
		{type: 'cave', label: labels.cave},
		{type: 'thunder', label: labels.thunder},
		{type: 'gale', label: labels.gale},
		{type: 'city', label: labels.city},
		{type: 'dark', label: labels.dark}
	];
	var sounds = {};
	var current = null;
	var panel = null;
	var existingOverlay = null;
	var statusNode = null;
	var volumeNode = null;
	var triggersBound = false;
	var state = {
		enabled: false,
		type: defaultType,
		volume: 25
	};

	function clampVolume(value) {
		value = parseInt(value, 10);
		if (!value && value !== 0) value = 25;
		return Math.max(10, Math.min(100, value));
	}

	function getOption(type) {
		for (var i = 0; i < options.length; i++) {
			if (options[i].type === type) return options[i];
		}
		return null;
	}

	function readJSON(storage, key) {
		try {
			var raw = storage.getItem(key);
			return raw ? JSON.parse(raw) : null;
		} catch (e) {
			return null;
		}
	}

	function writeJSON(storage, key, value) {
		try {
			storage.setItem(key, JSON.stringify(value));
		} catch (e) {}
	}

	function removeKey(storage, key) {
		try {
			storage.removeItem(key);
		} catch (e) {}
	}

	function loadState() {
		var saved = readJSON(localStorage, storageKey);
		if (saved) {
			if (getOption(saved.type)) state.type = saved.type || defaultType;
			state.volume = clampVolume(saved.volume);
		}
		var resume = readJSON(sessionStorage, resumeKey);
		var referrerIsSameHost = false;
		try {
			referrerIsSameHost = document.referrer && new URL(document.referrer).host === location.host;
		} catch (e) {}
		if (resume && resume.enabled && getOption(resume.type) && Date.now() - resume.ts < 12 * 60 * 60 * 1000 && referrerIsSameHost) {
			state.enabled = true;
			state.type = resume.type || defaultType;
			state.volume = clampVolume(resume.volume);
		}
	}

	function persistState() {
		writeJSON(localStorage, storageKey, {
			type: state.type,
			volume: state.volume
		});
		if (state.enabled) {
			writeJSON(sessionStorage, resumeKey, {
				enabled: true,
				type: state.type,
				volume: state.volume,
				ts: Date.now()
			});
		} else {
			removeKey(sessionStorage, resumeKey);
		}
	}

	function hasHowler() {
		return typeof window.Howl === 'function';
	}

	function showStatus(text) {
		if (!statusNode) return;
		statusNode.textContent = text || '';
		statusNode.hidden = !text;
	}

	function getSound(type) {
		if (!type || !getOption(type) || !hasHowler()) return null;
		if (sounds[type]) return sounds[type];
		var sound = new Howl({
			src: [basePath + type + '.opus', basePath + type + '.mp3'],
			format: ['opus', 'mp3'],
			loop: true,
			html5: true,
			preload: true,
			volume: 0,
			onplayerror: function() {
				showStatus(labels.blocked);
				sound.once('unlock', function() {
					if (state.enabled && state.type === type) playSound(type, state.volume / 100);
				});
			},
			onloaderror: function() {
				showStatus(labels.unavailable);
			}
		});
		sounds[type] = sound;
		return sound;
	}

	function stopSound() {
		if (!current || !current.sound) return;
		var sound = current.sound;
		var id = current.id;
		try {
			var from = sound.volume(id);
			sound.fade(from || 0, 0, 450, id);
			setTimeout(function() {
				try { sound.stop(id); } catch (e) {}
			}, 500);
		} catch (e) {
			try { sound.stop(id); } catch (ignore) {}
		}
		current = null;
	}

	function playSound(type, volume) {
		var sound = getSound(type);
		if (!sound) {
			showStatus(labels.unavailable);
			return false;
		}
		if (current && current.type !== type) stopSound();
		if (current && current.type === type) {
			try { current.sound.volume(volume, current.id); } catch (e) { current.sound.volume(volume); }
			return true;
		}
		var id;
		try {
			sound.volume(0);
			id = sound.play();
		} catch (e) {
			showStatus(labels.blocked);
			return false;
		}
		if (typeof id === 'undefined' || id === null) {
			showStatus(labels.blocked);
			return false;
		}
		current = {sound: sound, id: id, type: type};
		try { sound.fade(0, volume, 650, id); } catch (e) { sound.volume(volume, id); }
		showStatus('');
		return true;
	}

	function selectSound(type) {
		if (!type) {
			state.enabled = false;
			stopSound();
			persistState();
			updateUI();
			return;
		}
		state.type = type;
		state.enabled = true;
		if (!playSound(type, state.volume / 100)) state.enabled = false;
		persistState();
		updateUI();
	}

	function setVolume(value) {
		state.volume = clampVolume(value);
		if (current && current.sound) {
			try { current.sound.volume(state.volume / 100, current.id); } catch (e) { current.sound.volume(state.volume / 100); }
		}
		persistState();
		updateUI();
	}

	function injectStyles() {
		if (document.getElementById('reader-ambient-style')) return;
		var style = document.createElement('style');
		style.id = 'reader-ambient-style';
		style.textContent = ''
			+ '.reader-ambient-panel{position:fixed;inset:0;z-index:1700;display:none;align-items:stretch;justify-content:flex-end;background:rgba(0,0,0,.38);color:var(--body-color,var(--rl-text,#f2f2f7))}'
			+ '.reader-ambient-panel[data-open="true"]{display:flex}'
			+ '.reader-ambient-sheet{width:min(360px,100vw);height:100%;background:var(--popup-bg,var(--rl-surface,#1c1c1e));box-shadow:-20px 0 50px rgba(0,0,0,.28);display:flex;flex-direction:column}'
			+ '.reader-ambient-head{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:16px 18px;border-bottom:1px solid rgba(255,255,255,.1);font-weight:700}'
			+ '.reader-ambient-close{border:0;background:transparent;color:inherit;min-width:44px;min-height:44px;padding:0 10px;cursor:pointer;font:inherit}'
			+ '.reader-ambient-body{padding:18px;overflow:auto}'
			+ '.reader-ambient-options{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}'
			+ '.reader-ambient-option{min-height:58px;border:1px solid rgba(255,255,255,.14);border-radius:8px;background:rgba(255,255,255,.055);color:inherit;cursor:pointer;font:700 13px/1.2 Arial,sans-serif;display:flex;align-items:center;justify-content:center;text-align:center;padding:8px;transition:background .16s,border-color .16s,color .16s}'
			+ '.reader-ambient-option:hover{background:var(--nav-button-hover,var(--rl-fill,rgba(255,255,255,.12)))}'
			+ '.reader-ambient-option.active{border-color:var(--accent,var(--rl-accent,#f5a623));color:var(--accent,var(--rl-accent,#f5a623));background:rgba(245,166,35,.12)}'
			+ '.reader-ambient-volume{margin-top:18px;display:flex;align-items:center;gap:12px;font:600 13px/1.3 Arial,sans-serif;color:inherit}'
			+ '.reader-ambient-volume input{flex:1;min-width:0}'
			+ '.reader-ambient-status{margin-top:12px;font:600 12px/1.4 Arial,sans-serif;color:var(--accent,var(--rl-accent,#f5a623))}'
			+ '.reader-sound-toggle.active{color:var(--accent,var(--rl-accent,#f5a623))}'
			+ '@media(max-width:640px){.reader-ambient-panel{justify-content:center}.reader-ambient-sheet{width:100%;height:auto;max-height:88vh;margin-top:auto;border-radius:16px 16px 0 0}.reader-ambient-options{grid-template-columns:repeat(2,minmax(0,1fr))}}';
		document.head.appendChild(style);
	}

	function createPanel() {
		if (panel) return panel;
		injectStyles();
		panel = document.createElement('div');
		panel.className = 'reader-ambient-panel';
		panel.setAttribute('role', 'dialog');
		panel.setAttribute('aria-modal', 'true');
		panel.setAttribute('aria-label', labels.title);
		panel.innerHTML = '<div class="reader-ambient-sheet">'
			+ '<div class="reader-ambient-head"><span>' + labels.title + '</span><button type="button" class="reader-ambient-close">' + labels.close + '</button></div>'
			+ '<div class="reader-ambient-body"><div class="reader-ambient-options"></div>'
			+ '<label class="reader-ambient-volume"><span>' + labels.volume + '</span><input type="range" min="10" max="100" step="5" value="' + state.volume + '"></label>'
			+ '<div class="reader-ambient-status" hidden></div></div></div>';
		var optionsNode = panel.querySelector('.reader-ambient-options');
		options.forEach(function(option) {
			var button = document.createElement('button');
			button.type = 'button';
			button.className = 'reader-ambient-option';
			button.dataset.sound = option.type;
			button.textContent = option.label;
			optionsNode.appendChild(button);
		});
		panel.addEventListener('click', function(event) {
			if (event.target === panel || event.target.classList.contains('reader-ambient-close')) closePanel();
		});
		document.body.appendChild(panel);
		bindPanel(panel);
		return panel;
	}

	function bindPanel(scope) {
		statusNode = scope.querySelector('.reader-ambient-status') || statusNode;
		volumeNode = scope.querySelector('input[type="range"]') || document.getElementById('sound-volume') || volumeNode;
		Array.prototype.forEach.call(scope.querySelectorAll('[data-sound]'), function(button) {
			button.addEventListener('click', function() {
				selectSound(button.dataset.sound || '');
			});
		});
		if (volumeNode) {
			volumeNode.addEventListener('input', function() {
				setVolume(volumeNode.value);
			});
		}
	}

	function useExistingOverlay() {
		var overlay = document.getElementById('sounds-overlay');
		if (!overlay || !overlay.querySelector('[data-sound]')) return false;
		existingOverlay = overlay;
		statusNode = overlay.querySelector('.reader-ambient-status');
		if (!statusNode) {
			statusNode = document.createElement('div');
			statusNode.className = 'reader-ambient-status';
			statusNode.hidden = true;
			var body = overlay.querySelector('.r-sheet__body') || overlay;
			body.appendChild(statusNode);
		}
		bindPanel(overlay);
		return true;
	}

	function openPanel(event) {
		if (event) event.preventDefault();
		if (existingOverlay) {
			Array.prototype.forEach.call(document.querySelectorAll('.r-overlay.open'), function(node) {
				node.classList.remove('open');
			});
			existingOverlay.classList.add('open');
		} else {
			createPanel().setAttribute('data-open', 'true');
		}
		updateUI();
	}

	function closePanel() {
		if (panel) panel.setAttribute('data-open', 'false');
	}

	function updateUI() {
		Array.prototype.forEach.call(document.querySelectorAll('.reader-sound-toggle,[data-reader-ambient]'), function(button) {
			button.classList.toggle('active', !!state.enabled);
			button.setAttribute('aria-pressed', state.enabled ? 'true' : 'false');
			button.setAttribute('title', labels.button + ': ' + (state.enabled ? (getOption(state.type) || {}).label : labels.off));
			var icon = button.querySelector('.fa');
			if (icon) {
				icon.classList.toggle('fa-volume-up', !!state.enabled);
				icon.classList.toggle('fa-volume-off', !state.enabled);
			}
		});
		Array.prototype.forEach.call(document.querySelectorAll('[data-sound]'), function(button) {
			var type = button.dataset.sound || '';
			button.classList.toggle('active', type ? state.enabled && state.type === type : !state.enabled);
		});
		if (volumeNode) volumeNode.value = state.volume;
	}

	function closestTrigger(node) {
		while (node && node !== document) {
			if (node.matches && node.matches('.reader-sound-toggle,[data-reader-ambient]')) return node;
			node = node.parentNode;
		}
		return null;
	}

	function bindTriggers() {
		if (triggersBound) return;
		triggersBound = true;
		document.addEventListener('click', function(event) {
			var button = closestTrigger(event.target);
			if (!button) return;
			openPanel(event);
		});
		document.addEventListener('keydown', function(event) {
			if (event.key === 'Escape') closePanel();
		});
	}

	function scheduleResume() {
		if (!state.enabled || !getOption(state.type)) return;
		var started = false;
		var removeListeners = function() {
			['pointerdown', 'touchstart', 'keydown', 'wheel'].forEach(function(name) {
				window.removeEventListener(name, start, true);
			});
		};
		var start = function() {
			if (started || !state.enabled) return;
			started = true;
			playSound(state.type, state.volume / 100);
			removeListeners();
			updateUI();
		};
		setTimeout(start, 250);
		['pointerdown', 'touchstart', 'keydown', 'wheel'].forEach(function(name) {
			window.addEventListener(name, start, {capture: true, passive: true, once: true});
		});
	}

	function init() {
		loadState();
		injectStyles();
		useExistingOverlay();
		bindTriggers();
		updateUI();
		scheduleResume();
		window.addEventListener('pagehide', persistState);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

	window.readerAmbientSounds = {
		open: openPanel,
		stop: function() { selectSound(''); },
		play: function(type) { selectSound(type || state.type || defaultType); },
		state: function() {
			return {
				enabled: state.enabled,
				type: state.type,
				volume: state.volume
			};
		}
	};
})();
