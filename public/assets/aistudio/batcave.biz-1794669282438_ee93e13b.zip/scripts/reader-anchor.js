/**
 * reader-anchor — якорь #page-N в вертикальном (ленточном) режиме читалки.
 *
 * Постраничный режим пишет якорь сам (setPage -> replaceState в libs.min.js),
 * а лента — нет: setPage при прокрутке не вызывается, поэтому адрес всегда
 * указывал на начало главы и «поделиться»/закладка вели не туда.
 *
 * Здесь две половины:
 *   1) при прокрутке пишем #page-N (replaceState, чтобы не засорять историю);
 *   2) при открытии ссылки с #page-N прокручиваем к этой странице — иначе
 *      ссылка нерабочая (в вертикальном режиме ядро скролл не делает).
 *
 * Отдельным файлом, а не методом Vue: логика читалки лежит в собранном вручную
 * libs.min.js без сборки, править минификат рискованно. Всё держится на DOM.
 */
(function () {
	'use strict';

	/* Только страницы текущей главы: в бесконечном режиме дочитанные главы
	   дорисовываются без data-page, их нумерация к этому адресу не относится. */
	var WRAP = '.reader-view .reader__item-wrap[data-page]';

	var restoring = false;   // фаза перехода по ссылке, см. блок 2

	function visibleWraps() {
		var all = document.querySelectorAll(WRAP), out = [];
		for (var i = 0; i < all.length; i++) {
			if (all[i].getBoundingClientRect().height > 0) out.push(all[i]);
		}
		return out;
	}

	/* Неактивные страницы скрыты (display:none), поэтому в постраничном режиме
	   видима одна, в развороте — две. Больше двух = лента. Дешевле и надёжнее,
	   чем читать localStorage: режим переключается в рантайме через setMode. */
	function isVertical() {
		return visibleWraps().length > 2;
	}

	function pageOf(el) {
		return parseInt(el.getAttribute('data-page'), 10) || 0;
	}

	/* ---------- 1. Запись якоря при прокрутке ----------------------------- */
	/**
	 * Текущей считаем страницу, чей блок пересекает верхнюю треть экрана —
	 * та же метрика, что у эталона, совпадает с ощущением «сейчас читаю это».
	 */
	function currentPage() {
		var wraps = visibleWraps();
		if (!wraps.length) return 0;

		var mark = window.innerHeight / 3, best = 0, bestDist = Infinity;
		for (var i = 0; i < wraps.length; i++) {
			var r = wraps[i].getBoundingClientRect();
			if (r.top <= mark && r.bottom >= mark) return pageOf(wraps[i]);
			var d = Math.abs(r.top - mark);
			if (d < bestDist) { bestDist = d; best = pageOf(wraps[i]); }
		}
		return best;
	}

	var lastPage = 0, ticking = false;

	function syncHash() {
		ticking = false;
		if (restoring || !isVertical()) return;

		var p = currentPage();
		if (!p || p === lastPage) return;
		lastPage = p;

		var base = window.location.pathname + window.location.search;
		var hash = p > 1 ? '#page-' + p : '';
		try { window.history.replaceState(null, document.title, base + hash); } catch (e) {}
	}

	function onScroll() {
		if (ticking) return;
		ticking = true;
		window.requestAnimationFrame(syncHash);
	}

	/* Мобильные браузеры показывают свою панель при каждой смене адреса, даже через
	   replaceState: панель пряталась при прокрутке и выскакивала на каждой новой
	   странице (жалоба 12.10.2026). На сенсорных экранах адрес пишем только при
	   уходе со страницы; прогресс чтения от этого не зависит (bookmark — отдельно). */
	var touch = !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches);

	if (touch) {
		document.addEventListener('visibilitychange', function () {
			if (document.visibilityState === 'hidden') syncHash();
		});
		window.addEventListener('pagehide', syncHash);
	} else {
		window.addEventListener('scroll', onScroll, { passive: true });
		window.addEventListener('resize', onScroll, { passive: true });
	}

	/* ---------- 2. Переход по ссылке с #page-N ---------------------------- */
	/**
	 * Картинки ленивые: нужный блок появляется не сразу и высота ленты растёт
	 * по мере загрузки страниц выше — одного scrollIntoView мало, позиция
	 * уезжает. Поэтому доводим цель до конца окна восстановления, пока адресат
	 * не тронул страницу сам. Запись якоря на это время подавлена (restoring),
	 * иначе промежуточная позиция затёрла бы номер из ссылки.
	 */
	var RESTORE_MS = 8000, TICK_MS = 200;

	var m = /^#page-(\d+)$/.exec(window.location.hash || '');
	var wantPage = m ? parseInt(m[1], 10) : 0;
	restoring = wantPage > 1;

	function stopRestore() {
		restoring = false;
		lastPage = wantPage;
	}

	if (restoring) {
		['wheel', 'touchstart', 'keydown', 'mousedown'].forEach(function (ev) {
			window.addEventListener(ev, stopRestore, { passive: true, once: true });
		});

		var deadline = Date.now() + RESTORE_MS;
		var timer = setInterval(function () {
			if (!restoring || Date.now() > deadline) {
				clearInterval(timer);
				stopRestore();
				return;
			}
			if (!isVertical()) return;   // постраничный режим — там скроллит ядро

			var el = document.querySelector(WRAP + '[data-page="' + wantPage + '"]');
			if (!el || el.getBoundingClientRect().height <= 0) return;

			/* Цель — не top:0, а scroll-margin-top блока: sticky-шапка иначе
			   накрывает верх страницы (см. body.css .reader__item-wrap). */
			var goal = parseFloat(getComputedStyle(el).scrollMarginTop) || 0;
			if (Math.abs(el.getBoundingClientRect().top - goal) > 4) {
				el.scrollIntoView({ block: 'start' });
			}
		}, TICK_MS);
	}
})();
