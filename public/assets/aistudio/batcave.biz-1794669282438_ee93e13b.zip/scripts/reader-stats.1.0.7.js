/* Reader page statistics: records new windows/tabs opened by third-party scripts on reader pages.
 * Passive: native window.open / anchor click are always called and their result returned unchanged.
 * Load synchronously before third-party tags. Endpoint: Reader pageStat (alias adEvent).
 */
(function () {
	'use strict';
	if (window.__rdrStats || window.__adMeter) return;
	window.__rdrStats = 1;

	var HIST_KEY = 'rdr_st_hist', PID_KEY = 'rdr_st_pid';
	var OLD_HIST = 'rdr_ad_hist', OLD_PID = 'rdr_ad_pid';
	var HOUR = 3600000, DEDUP = 2000;
	/* batcave: mod=api&action=…; com-x: mod=reader + POST "method" (data-route="reader"). */
	var cs = document.currentScript;
	var VIA_READER = !!(cs && cs.getAttribute('data-route') === 'reader');
	var ENDPOINT = VIA_READER
		? '/engine/ajax/controller.php?mod=reader'
		: '/engine/ajax/controller.php?mod=api&action=reader/pageStat';
	var host = location.hostname;
	/* Own frames are skipped by this file's own path, so renaming the file never breaks it. */
	var SELF = '/reader-stats';
	try { if (cs && cs.src) SELF = new URL(cs.src).pathname; } catch (e) {}

	function store(key, val) {
		try {
			if (val === undefined) return localStorage.getItem(key);
			localStorage.setItem(key, val);
		} catch (e) {}
		return null;
	}

	/* Keep the same browser id and history after the key rename. */
	(function migrate() {
		if (!store(PID_KEY) && store(OLD_PID)) store(PID_KEY, store(OLD_PID));
		if (!store(HIST_KEY) && store(OLD_HIST)) store(HIST_KEY, store(OLD_HIST));
	})();

	/* Random browser id: mobile IPs change, the browser stays. */
	function pid() {
		var id = store(PID_KEY);
		if (!id || !/^[a-z0-9]{12}$/.test(id)) {
			id = '';
			while (id.length < 12) id += Math.random().toString(36).slice(2);
			id = id.slice(0, 12);
			store(PID_KEY, id);
		}
		return id;
	}

	/* Opened by the site's own code (e.g. image viewer in reader-ux.js)? */
	function fromOurCode() {
		try {
			var lines = String((new Error()).stack || '').split('\n'), i, l;
			for (i = 0; i < lines.length; i++) {
				l = lines[i];
				if (l.indexOf(SELF) !== -1) continue;
				if (l.indexOf(host) !== -1 && (l.indexOf('/templates/') !== -1 || l.indexOf('/engine/') !== -1)) return true;
			}
		} catch (e) {}
		return false;
	}

	function hostOf(url) {
		try { return new URL(String(url || ''), location.href).hostname; } catch (e) { return ''; }
	}

	/* History is shared by all tabs (localStorage). A repeat within 2 s is the same open
	   arriving by a second path (click + window.open) and is not recorded. */
	function record(method, url, opened, feat, kind) {
		var now = Date.now(), hist = [];
		try { hist = JSON.parse(store(HIST_KEY) || '[]'); } catch (e) {}
		if (!Array.isArray(hist)) hist = [];
		hist = hist.filter(function (t) { return typeof t === 'number' && t <= now && now - t < HOUR; });
		var prev = hist.length ? hist[hist.length - 1] : 0;
		if (prev && now - prev < DEDUP) return;
		hist.push(now);
		store(HIST_KEY, JSON.stringify(hist.slice(-50)));

		var target = hostOf(url);
		try {
			var fd = new FormData();
			if (VIA_READER) fd.append('method', 'reader/pageStat');
			fd.append('pid', pid());
			fd.append('via', method);
			fd.append('kind', target === host ? 'tabunder' : (kind || 'popup'));
			fd.append('target', target.slice(0, 100));
			fd.append('url', String(url || '').slice(0, 500));
			var z = document.querySelector('script[data-clocid]');
			fd.append('zone', z ? String(z.getAttribute('data-clocid')).slice(0, 20) : '');
			fd.append('gap', prev ? String(now - prev) : '-1');
			fd.append('n1h', String(hist.length));
			fd.append('opened', opened === 1 || opened === 0 ? String(opened) : '-1');
			/* With "noopener" window.open() always returns null, so opened=0 does not mean blocked. */
			fd.append('feat', String(feat || '').slice(0, 80));
			fd.append('page', (location.pathname + location.hash).slice(0, 200));
			navigator.sendBeacon(ENDPOINT, fd);
		} catch (e) {}
	}

	var nativeOpen = window.open;
	window.open = function (url) {
		var w = nativeOpen.apply(this, arguments);
		if (!fromOurCode()) record('open', url, w ? 1 : 0, arguments[2]);
		return w;
	};

	var A = window.HTMLAnchorElement && HTMLAnchorElement.prototype;
	if (A && A.click) {
		var nativeClick = A.click;
		A.click = function () {
			if (this.target && this.target !== '_self' && !fromOurCode()) record('anchor', this.href);
			return nativeClick.apply(this, arguments);
		};
	}

	/* Same via dispatchEvent(new MouseEvent('click')) on a link in the document. */
	document.addEventListener('click', function (ev) {
		if (ev.isTrusted) return;
		var a = ev.target && ev.target.closest ? ev.target.closest('a[target]') : null;
		if (a && a.target !== '_self' && !fromOurCode()) record('dispatch', a.href);
	}, true);

	/* open() of a blank same-origin iframe (iframe.contentWindow.open.call(window, …)) is the frame's
	   own native function, so the window.open hook above never sees it. Hook it when the frame is read. */
	function hookFrame(w) {
		try {
			if (!w || w === window || w.__rdrStats) return;
			var frameOpen = w.open;
			if (typeof frameOpen !== 'function') return;
			w.__rdrStats = 1;
			w.open = function (url) {
				var r = frameOpen.apply(this, arguments);
				if (!fromOurCode()) record('iframe', url, r ? 1 : 0, arguments[2]);
				return r;
			};
		} catch (e) {} /* cross-origin frame: not reachable */
	}
	var F = window.HTMLIFrameElement && HTMLIFrameElement.prototype;
	var cw = F && Object.getOwnPropertyDescriptor(F, 'contentWindow');
	if (cw && cw.get && cw.configurable) {
		Object.defineProperty(F, 'contentWindow', {
			configurable: true,
			enumerable: cw.enumerable,
			get: function () {
				var w = cw.get.call(this);
				hookFrame(w);
				return w;
			}
		});
	}

	/* Hidden GET form with target=_blank (used when an ad blocker is detected). */
	var FP = window.HTMLFormElement && HTMLFormElement.prototype;
	if (FP && FP.submit) {
		var nativeSubmit = FP.submit;
		FP.submit = function () {
			try {
				var t = this.getAttribute('target'), u = new URL(this.getAttribute('action') || '', location.href);
				if (t && t !== '_self' && u.hostname !== host && !fromOurCode()) {
					new FormData(this).forEach(function (v, k) { if (typeof v === 'string') u.searchParams.append(k, v); });
					record('form', u.href);
				}
			} catch (e) {}
			return nativeSubmit.apply(this, arguments);
		};
	}

	/* This tab sent to another site by script (location.href = …): Navigation API, where the browser has it.
	   Links the reader clicks are userInitiated and not counted. */
	if (window.navigation && navigation.addEventListener) {
		navigation.addEventListener('navigate', function (ev) {
			try {
				if (ev.userInitiated || ev.hashChange || !ev.destination) return;
				var to = ev.destination.url, h = hostOf(to);
				if (h && h !== host && !fromOurCode()) record('redirect', to, -1, '', 'redirect');
			} catch (e) {}
		});
	}
})();
