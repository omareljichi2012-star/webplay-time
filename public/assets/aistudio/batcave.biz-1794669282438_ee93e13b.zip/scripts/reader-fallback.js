/**
 * reader-fallback.js — ES5 image gallery for legacy browsers.
 * Loaded only via <script nomodule> — modern browsers never fetch this.
 *
 * Renders all chapter images in a vertical strip using window.__DATA__.
 * Does not require Vue, axios, or any ES6+ features.
 */
(function () {
  'use strict';

  var data = window.__DATA__;
  if (!data || !data.images || !data.images.length) return;

  var shell = document.getElementById('ssr-shell');
  if (!shell) return;

  function buildNav() {
    var wrap = document.createElement('div');
    wrap.className = 'fb-nav';

    var prev = document.createElement('a');
    prev.href = data.prev || '#';
    prev.className = 'fb-btn';
    prev.textContent = '\u2039 Prev';

    var info = document.createElement('span');
    info.className = 'fb-info';
    info.textContent = data.pages + ' pages';

    var next = document.createElement('a');
    next.href = data.next || '#';
    next.className = 'fb-btn';
    next.textContent = 'Next \u203a';

    wrap.appendChild(prev);
    wrap.appendChild(info);
    wrap.appendChild(next);
    return wrap;
  }

  while (shell.firstChild) { shell.removeChild(shell.firstChild); }

  var frag = document.createDocumentFragment();
  var topNav = buildNav();
  frag.appendChild(topNav);

  for (var i = 0; i < data.images.length; i++) {
    var img = document.createElement('img');
    img.alt = 'Page ' + (i + 1);
    if (i >= 2) { img.setAttribute('loading', 'lazy'); }
    img.src = data.images[i];
    frag.appendChild(img);
  }

  frag.appendChild(topNav.cloneNode(true));
  shell.appendChild(frag);
}());
