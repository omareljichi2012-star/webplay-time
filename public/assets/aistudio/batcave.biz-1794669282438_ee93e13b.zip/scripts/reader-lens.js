/**
 * reader-lens — лупа в читалке (suggestion #39, 12.10.2026).
 *
 * Только компьютер: на телефоне уже есть двойной тап и жест увеличения. Без новой
 * кнопки на экране: включается клавишей Z или в настройках («Magnifier»). Сервер не
 * нагружает — увеличивает уже загруженную страницу (тот же URL, из кэша браузера).
 * Клавиши при включённой лупе: + / − увеличение (1.5–5×), [ / ] размер (120–360 px).
 * Отдельный файл на голом DOM, как reader-anchor: логика читалки в libs.min.js без сборки.
 */
(function () {
	'use strict';

	if (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) return;

	var KEY = 'reader_lens';
	var on = false, zoom = 2.5, size = 200;
	var lens = null, curImg = null;

	try {
		var s = JSON.parse(localStorage.getItem(KEY) || '{}');
		on = !!s.on;
		if (s.zoom >= 1.5 && s.zoom <= 5) zoom = s.zoom;
		if (s.size >= 120 && s.size <= 360) size = s.size;
	} catch (e) {}

	function save() {
		try { localStorage.setItem(KEY, JSON.stringify({ on: on, zoom: zoom, size: size })); } catch (e) {}
	}

	function ensure() {
		if (lens) return;
		lens = document.createElement('div');
		lens.className = 'rlens';
		lens.hidden = true;
		lens.setAttribute('aria-hidden', 'true');
		document.body.appendChild(lens);
	}

	function hide() {
		if (lens) lens.hidden = true;
	}

	function setOn(v) {
		on = !!v;
		document.documentElement.classList.toggle('rlens-on', on);
		if (!on) hide();
		save();
		updateRows();
	}

	function move(e) {
		if (!on) return;
		var img = e.target && e.target.closest ? e.target.closest('.reader__item') : null;
		if (!img || !img.complete || !img.naturalWidth) { hide(); return; }
		var r = img.getBoundingClientRect();
		var x = e.clientX - r.left, y = e.clientY - r.top;
		if (x < 0 || y < 0 || x > r.width || y > r.height) { hide(); return; }
		ensure();
		if (curImg !== img) {
			curImg = img;
			lens.style.backgroundImage = 'url("' + String(img.currentSrc || img.src).replace(/"/g, '%22') + '")'; // inline-style-ok: картинка лупы — текущая страница, известна только в рантайме
		}
		// inline-style-ok: размер, масштаб и положение лупы считаются от курсора на каждом движении
		Object.assign(lens.style, { width: size + 'px', height: size + 'px', left: (e.clientX - size / 2) + 'px', top: (e.clientY - size / 2) + 'px', backgroundSize: (r.width * zoom) + 'px ' + (r.height * zoom) + 'px', backgroundPosition: (size / 2 - x * zoom) + 'px ' + (size / 2 - y * zoom) + 'px' }); // inline-style-ok: см. выше
		lens.hidden = false;
	}

	document.addEventListener('mousemove', move, { passive: true });
	document.addEventListener('mouseleave', hide);
	window.addEventListener('scroll', hide, { passive: true });

	document.addEventListener('keydown', function (e) {
		var t = e.target, tag = t && t.tagName;
		if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (t && t.isContentEditable)) return;
		if (e.ctrlKey || e.metaKey || e.altKey) return;
		if (e.key === 'z' || e.key === 'Z' || e.key === 'я' || e.key === 'Я') { setOn(!on); return; }
		if (!on) return;
		if (e.key === '+' || e.key === '=') { zoom = Math.min(5, zoom + 0.5); save(); }
		else if (e.key === '-' || e.key === '_') { zoom = Math.max(1.5, zoom - 0.5); save(); }
		else if (e.key === ']') { size = Math.min(360, size + 40); save(); }
		else if (e.key === '[') { size = Math.max(120, size - 40); save(); }
	});

	/* Пункт «Magnifier» в настройках: попап рисует Vue заново при каждом открытии,
	   поэтому обработчик — делегированием, а подсветку обновляем, когда строка появилась. */
	function updateRows() {
		var rows = document.querySelectorAll('[data-lens]');
		for (var i = 0; i < rows.length; i++) {
			rows[i].classList.toggle('active', (rows[i].getAttribute('data-lens') === '1') === on);
		}
	}

	document.addEventListener('click', function (e) {
		var a = e.target && e.target.closest ? e.target.closest('[data-lens]') : null;
		if (!a) return;
		e.preventDefault();
		setOn(a.getAttribute('data-lens') === '1');
	});

	if (window.MutationObserver) {
		new MutationObserver(function () { if (document.querySelector('[data-lens]')) updateRows(); })
			.observe(document.querySelector('.popup-root') || document.body, { childList: true, subtree: true });
	}

	document.documentElement.classList.toggle('rlens-on', on);
})();
