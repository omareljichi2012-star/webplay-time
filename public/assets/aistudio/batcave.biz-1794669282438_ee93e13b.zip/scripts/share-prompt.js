/**
 * Post-chapter share prompt.
 *
 * navigator.share() needs transient user activation — calling it from a timer or
 * a watcher throws NotAllowedError. So nothing here opens the sheet by itself:
 * we surface a prompt at the emotional peak, and the user's own tap opens it.
 *
 * caught up (no next chapter)   -> modal; there is nowhere to go, it blocks nothing
 * binge (3+ chapters a session) -> toast; the reader is still moving, never sit
 *                                  on the path to the next chapter
 *
 * Self-contained on purpose: some sites ship modal.js but never wire it in, and
 * pulling it in would also switch on its reader-guide popup.
 */
var SharePrompt = (function() {
	'use strict';

	var LS = 'share_prompt';        // {shown, lastTs, dismissed, until, off}
	var SS = 'sp_read_ch';          // chapter ids finished in this tab

	var DAY          = 86400000;
	var MAX_SHOWN    = 3;
	var DISMISS_DAYS = [14, 60];    // after 1st / 2nd dismiss; the 3rd turns it off for good
	var SHARED_DAYS  = 90;
	var MIN_GAP_DAYS = 7;           // floor between any two prompts, whatever fired them
	var BINGE        = 3;
	var TOAST_MS     = 9000;
	var DELAY_MS     = 900;         // let the last page settle before asking

	/* Language comes from data-lang on the script tag — same pattern the reader
	   already uses for reader-sounds.js — so one file serves every site. */
	var LANG = (function() {
		var s = document.querySelector('script[src*="share-prompt"]');
		var l = (s && s.getAttribute('data-lang')) || document.documentElement.lang || 'en';
		return l.slice(0, 2).toLowerCase();
	})();

	function plural(n, one, few, many) {
		var a = Math.abs(n) % 100, b = a % 10;
		if (a > 10 && a < 20) return many;
		if (b > 1 && b < 5) return few;
		if (b === 1) return one;
		return many;
	}

	var I18N = {
		en: {
			kick: 'Caught up',
			stat: function(n) { return n + ' / ' + n + ' chapters · nothing left'; },
			ask:  'Know someone who&#39;d binge it too?',
			go:   function(name) { return 'Send ' + name + ' to a friend'; },
			no:   'Not now',
			tl1:  function(n, name) { return n + ' chapters of ' + name + ' tonight'; },
			tl2:  'Know someone who&#39;d get hooked?',
			tgo:  'Share',
			copy: 'Copy the link',
			done: 'Link copied ✓',
			sUp:  function(name) { return 'I just caught up on ' + name + '. Now I wait. You should suffer too.'; },
			sBin: function(name) { return 'I lost my evening to ' + name + '. Your turn.'; }
		},
		/* Безлично — иначе пришлось бы выбирать род («догнал/догнала»). */
		ru: {
			kick: 'Всё прочитано',
			stat: function(n) { return n + ' / ' + n + ' ' + plural(n, 'глава', 'главы', 'глав') + ' · продолжения нет'; },
			ask:  'Знаете, кому это зайдёт?',
			go:   function() { return 'Отправить другу'; },
			no:   'Не сейчас',
			tl1:  function(n, name) { return n + ' ' + plural(n, 'глава', 'главы', 'глав') + ' за вечер'; },
			tl2:  'Знаете, кому это зайдёт?',
			tgo:  'Поделиться',
			copy: 'Скопировать ссылку',
			done: 'Ссылка скопирована ✓',
			sUp:  function(name) { return '«' + name + '» — глав больше нет, дальше только ждать. Составишь компанию?'; },
			sBin: function(name) { return '«' + name + '» — не оторваться. Затягивает.'; }
		}
	};
	var T = I18N[LANG] || I18N.en;

	function read()   { try { return JSON.parse(localStorage.getItem(LS)) || {}; } catch (e) { return {}; } }
	function write(s) { try { localStorage.setItem(LS, JSON.stringify(s)); } catch (e) {} }

	/** Survives the reload that "next chapter" does, dies with the tab. */
	function sessionCount(id) {
		try {
			var a = JSON.parse(sessionStorage.getItem(SS) || '[]');
			if (a.indexOf(id) === -1) { a.push(id); sessionStorage.setItem(SS, JSON.stringify(a)); }
			return a.length;
		} catch (e) { return 0; }
	}

	/* Web Share exists on phones, on Windows Chrome/Edge and on macOS — but not in
	   Firefox or Chrome/Linux. There we fall back to copying the link, same as the
	   site's own share button in fullstory.tpl already does. */
	function hasSheet() { return typeof navigator.share === 'function'; }
	function hasClipboard() { return !!(navigator.clipboard && navigator.clipboard.writeText); }
	function canShare() { return hasSheet() || hasClipboard(); }

	function copyLink(url) {
		if (hasClipboard()) return navigator.clipboard.writeText(url);
		return new Promise(function(resolve, reject) {   // http:// or an old browser
			try {
				var ta = document.createElement('textarea');
				ta.value = url;
				ta.setAttribute('readonly', '');
				ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
				document.body.appendChild(ta);
				ta.select();
				var ok = document.execCommand('copy');
				document.body.removeChild(ta);
				ok ? resolve() : reject();
			} catch (e) { reject(e); }
		});
	}

	function allowed() {
		if (!canShare()) return false;   // can neither share nor copy -> never ask
		var s = read(), now = Date.now();
		if (s.off) return false;
		if ((s.shown || 0) >= MAX_SHOWN) return false;
		if (s.until && now < s.until) return false;
		if (s.lastTs && now - s.lastTs < MIN_GAP_DAYS * DAY) return false;
		return true;
	}

	function onShown()  { var s = read(); s.shown = (s.shown || 0) + 1; s.lastTs = Date.now(); write(s); }
	function onShared() { var s = read(); s.until = Date.now() + SHARED_DAYS * DAY; write(s); }
	function onDismiss() {
		var s = read(), n = (s.dismissed || 0) + 1;
		s.dismissed = n;
		if (n >= 3) s.off = 1; else s.until = Date.now() + DISMISS_DAYS[n - 1] * DAY;
		write(s);
		closeAll();
	}

	/* Escapes quotes too: these values also land inside attributes (src="..."),
	   where a textContent-based escape would let `x" onerror=` through. */
	function esc(v) {
		return String(v == null ? '' : v)
			.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
	}

	function byId(id) { return document.getElementById(id); }

	function closeAll() {
		var o = byId('sp-ov'), t = byId('sp-toast');
		o && o.parentNode && o.parentNode.removeChild(o);
		t && t.parentNode && t.parentNode.removeChild(t);
		document.removeEventListener('keyup', onEsc);
		document.documentElement.style.overflow = '';
	}
	function onEsc(e) { e.key === 'Escape' && onDismiss(); }

	/* Runs inside a click handler, so activation is intact and share() is allowed.
	   btn is echoed back to for the copy path — closing instantly would leave the
	   user wondering whether anything happened at all. */
	function fire(vm, caughtUp, btn) {
		var d = vm.data, name = d.post_title || document.title;
		var url = d.post_link || location.origin + location.pathname;

		if (hasSheet()) {
			navigator.share({ title: name, text: caughtUp ? T.sUp(name) : T.sBin(name), url: url })
				.then(onShared, function() { /* AbortError = sheet closed; not a dismiss */ })
				.then(closeAll, closeAll);
			return;
		}

		copyLink(url).then(function() {
			onShared();
			if (btn) { btn.textContent = T.done; btn.disabled = true; }
			setTimeout(closeAll, 1200);
		}, closeAll);
	}

	/* onerror: covers can 404 (ranobe re-uploads them under a new hash and leaves the
	   old URL in xfields). Drop the image rather than show a broken frame. */
	function posterTag(d, cls) {
		if (!d.post_poster) return '';
		return '<img class="' + cls + '" src="' + esc(d.post_poster) + '" alt=""'
			+ ' onerror="this.parentNode &amp;&amp; this.parentNode.removeChild(this)">';
	}

	function openModal(vm) {
		if (byId('sp-ov')) return;
		var d = vm.data, total = (d.chapters && d.chapters.length) || 0;
		onShown();

		var ov = document.createElement('div');
		ov.id = 'sp-ov';
		ov.className = 'sp-ov';
		ov.innerHTML = '<div class="sp-card">'
			+ '<div class="sp-row">' + posterTag(d, 'sp-img')
			+ '<div class="sp-meta">'
			+ '<div class="sp-kick">' + T.kick + '</div>'
			+ '<div class="sp-name">' + esc(d.post_title || '') + '</div>'
			+ (total ? '<div class="sp-stat">' + esc(T.stat(total)) + '</div>' : '')
			+ '</div></div>'
			+ '<p class="sp-ask">' + T.ask + '</p>'
			+ '<div class="sp-acts">'
			+ '<button type="button" class="sp-go">' + esc(hasSheet() ? T.go(d.post_title || 'it') : T.copy) + '</button>'
			+ '<button type="button" class="sp-no">' + T.no + '</button>'
			+ '</div></div>';
		document.body.appendChild(ov);
		document.documentElement.style.overflow = 'hidden';

		var go = ov.querySelector('.sp-go');
		go.onclick = function() { fire(vm, true, go); };
		ov.querySelector('.sp-no').onclick = onDismiss;
		ov.onclick = function(e) { e.target === ov && onDismiss(); };
		document.addEventListener('keyup', onEsc);
	}

	function openToast(vm) {
		if (byId('sp-toast')) return;
		var d = vm.data;
		onShown();

		var t = document.createElement('div');
		t.id = 'sp-toast';
		t.className = 'sp-toast';
		t.innerHTML = posterTag(d, 'sp-img')
			+ '<div class="sp-toast-txt">'
			+ '<div class="sp-toast-l1">' + esc(T.tl1(BINGE, d.post_title || 'this')) + '</div>'
			+ '<div class="sp-toast-l2">' + T.tl2 + '</div>'
			+ '</div>'
			+ '<button type="button" class="sp-toast-go">' + (hasSheet() ? T.tgo : T.copy) + '</button>'
			+ '<button type="button" class="sp-toast-x" aria-label="Dismiss">✕</button>';
		document.body.appendChild(t);

		var tgo = t.querySelector('.sp-toast-go');
		tgo.onclick = function() { fire(vm, false, tgo); };
		t.querySelector('.sp-toast-x').onclick = onDismiss;
		setTimeout(function() {
			var el = byId('sp-toast');
			el && el.parentNode && el.parentNode.removeChild(el);   // silent timeout is not a dismiss
		}, TOAST_MS);
	}

	/**
	 * Some sites ship a trimmed libs.min.js (~4.5KB vs ~26KB) with no engagement
	 * telemetry and no getNextChapterId. Use the reader's own signals when they
	 * exist, otherwise count it ourselves — same thresholds either way.
	 */
	function makeEngaged(vm) {
		if (typeof vm._isEngaged === 'function') return function() { return vm._isEngaged(); };
		var start = Date.now(), navs = 0;
		vm.$watch(function() { return vm.page; }, function() { navs++; });
		return function() { return navs >= 5 && Date.now() - start >= 15000; };
	}

	/* Event pages (data.is_last_step, set by Events/index.php) carry no /reader/
	   link at all — data.next is always /event/... — so getNextChapterId()'s
	   "/reader/ substring" heuristic reads every event step as caught-up.
	   Prefer the server's own verdict when it's there; fall back to the
	   reader's own signals for everything else, same as before. */
	function makeCaughtUp(vm) {
		if (vm.data && typeof vm.data.is_last_step !== 'undefined') return function() { return !!vm.data.is_last_step; };
		if (typeof vm.getNextChapterId === 'function') return function() { return vm.getNextChapterId() === 0; };
		return function() {
			var n = vm.data && vm.data.next;
			return !n || n.indexOf('/reader/') === -1;
		};
	}

	var armed = false;

	/**
	 * Fires once the reader reaches the end of a chapter.
	 *
	 * Engagement can arrive AFTER the chapter ends — finish in 10s, then sit on the
	 * last page — and by then nothing moves any more: no page change, no scroll, so
	 * no second event. Waiting here instead of bailing out is the whole point.
	 */
	function atChapterEnd(vm, isEngaged, isCaughtUp) {
		if (armed) return;
		var caughtUp = isCaughtUp();
		var binge = sessionCount(vm.data.chapter_id) >= BINGE;
		if (!caughtUp && !binge) return;
		if (!allowed()) return;

		armed = true;
		var tries = 0;
		(function attempt() {
			if (!isEngaged()) {
				if (++tries > 24) return;          // ~72s, then give up quietly
				return void setTimeout(attempt, 3000);
			}
			if (!allowed()) return;
			setTimeout(function() {
				if (!allowed()) return;
				caughtUp ? openModal(vm) : openToast(vm);
			}, DELAY_MS);
		})();
	}

	/* Paginated: page is reactive and reaches data.pages on the last page. */
	function watchPaged(vm, isEngaged, isCaughtUp) {
		vm.$watch(function() { return vm.page; }, function() {
			vm.page === vm.data.pages && atChapterEnd(vm, isEngaged, isCaughtUp);
		});
		vm.page === vm.data.pages && atChapterEnd(vm, isEngaged, isCaughtUp);
	}

	/* Vertical/infinite: page never advances on scroll, so watch the last image.
	   Images may arrive via AJAX, so re-arm until one shows up. */
	function watchScrolled(vm, isEngaged, isCaughtUp) {
		if (!window.IntersectionObserver) return;
		var tries = 0;
		(function arm() {
			var imgs = document.querySelectorAll('.reader-view .reader__item');
			if (!imgs.length) {
				if (++tries > 20) return;
				return void setTimeout(arm, 500);
			}
			var io = new IntersectionObserver(function(entries) {
				entries.forEach(function(e) {
					if (!e.isIntersecting) return;
					io.disconnect();
					atChapterEnd(vm, isEngaged, isCaughtUp);
				});
			}, { threshold: 0.6 });
			io.observe(imgs[imgs.length - 1]);
		})();
	}

	/**
	 * Root component instance, taken from the DOM rather than from mount()'s
	 * return value — on some sites mount() runs inside libs.min.js and the result
	 * is unreachable.
	 *
	 * Verified on Vue 3.0.10 prod build: app._instance is dev/devtools-only and is
	 * absent there, but the container's root vnode does carry the proxy.
	 */
	function getVm() {
		var el = document.querySelector('.reader-root');
		var vn = el && el._vnode;
		return (vn && vn.component && vn.component.proxy) || null;
	}

	/**
	 * Text reader (ranobe): no Vue, no libs.min.js, so none of the reader's own
	 * signals exist here. window.__SP__ is emitted by engine/mods/ranobelib/reader.php;
	 * "chapter finished" is scroll progress, and engagement is time on page plus how
	 * much was actually scrolled — the paginated _navCount has no equivalent.
	 */
	function bootText(cfg) {
		var start = Date.now(), maxPct = 0, fired = false;
		var vm = { data: {
			post_link:   cfg.link,
			post_title:  cfg.title,
			post_poster: cfg.poster,
			chapters:    { length: cfg.total || 0 },
			chapter_id:  cfg.chapter_id
		} };

		function pct() {
			var h = document.documentElement;
			var max = h.scrollHeight - h.clientHeight;
			return max > 40 ? Math.round(h.scrollTop / max * 100) : 100;   // short chapter = read on open
		}
		function engaged() { return Date.now() - start >= 15000 && maxPct >= 40; }

		/* Hand off to atChapterEnd, which waits for engagement instead of bailing —
		   here it matters even more: finish the text and you stop scrolling, so
		   this listener would never fire again. */
		function onScroll() {
			var p = pct();
			if (p > maxPct) maxPct = p;
			if (fired || p < 95) return;
			fired = true;
			window.removeEventListener('scroll', onScroll);
			atChapterEnd(vm, engaged, function() { return !!cfg.caught_up; });
		}

		window.addEventListener('scroll', onScroll, { passive: true });
		onScroll();
	}

	function boot() {
		if (!canShare()) return;   // neither sheet nor clipboard — stay out of the way
		if (window.__SP__) return void bootText(window.__SP__);
		var tries = 0;
		(function wait() {
			var vm = getVm();
			if (!vm || !vm.data || !vm.settings) {
				if (++tries > 20) return;   // reader never mounted; leave the page alone
				return void setTimeout(wait, 250);
			}
			var isEngaged = makeEngaged(vm), isCaughtUp = makeCaughtUp(vm);
			(vm.settings.vertical || vm.settings.infinite)
				? watchScrolled(vm, isEngaged, isCaughtUp)
				: watchPaged(vm, isEngaged, isCaughtUp);
		})();
	}

	return {
		init: boot,
		/* exposed for the test harness */
		_state: read,
		_allowed: allowed,
		_vm: getVm,

		/**
		 * Manual check: SharePrompt.test() -> modal, SharePrompt.test('toast') -> toast.
		 * Ignores cooldown and engagement on purpose — it answers "does it render
		 * here", not "would it fire now".
		 */
		test: function(kind) {
			var vm = getVm();
			if (!vm && window.__SP__) {
				var c = window.__SP__;
				vm = { data: {
					post_link: c.link, post_title: c.title, post_poster: c.poster,
					chapters: { length: c.total || 0 }, chapter_id: c.chapter_id
				} };
			}
			if (!vm || !vm.data) return 'reader not found';
			try { localStorage.removeItem(LS); } catch (e) {}
			closeAll();
			kind === 'toast' ? openToast(vm) : openModal(vm);
			return 'shown: ' + (kind === 'toast' ? 'toast' : 'modal')
				+ ' | sheet=' + hasSheet() + ' clipboard=' + hasClipboard();
		}
	};
})();

document.readyState === 'loading'
	? document.addEventListener('DOMContentLoaded', SharePrompt.init)
	: SharePrompt.init();
