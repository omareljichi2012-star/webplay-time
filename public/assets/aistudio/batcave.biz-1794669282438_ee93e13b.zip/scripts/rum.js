(function () {
  'use strict';
  // 1. Сэмплинг 10%, стабильно на сессию
  var KEY = 'rum_s';
  var s;
  try { s = sessionStorage.getItem(KEY); } catch (e) { s = undefined; }
  if (s === null || s === undefined) {
    s = (Math.random() < 0.10) ? '1' : '0';
    try { sessionStorage.setItem(KEY, s); } catch (e) {}
  }
  if (s !== '1') return;

  // 2. page_type по pathname
  function pageType(p) {
    if (p === '/' || p === '') return 'home';
    if (/^\/video\//i.test(p)) return 'player';
    if (/^\/(reader|read|chapter|glava)\//i.test(p)) return 'reader';
    if (/^\/\d+-/.test(p)) return 'fullstory';
    if (/^\/(page\/|xfsearch|tags\/|lastnews|category|films|serials|filmy|search|actors|hub|comix|comiclist|folder|watched)/i.test(p)) return 'catalog';
    return 'other';
  }

  // 2a. Тип страницы от DLE (data-pt из [available=...] в main.tpl) — URL у шаблонов разные.
  // Карточку берём из DLE всегда; 'other' по URL уточняем данными DLE.
  var me = document.currentScript;
  var dlePt = (me && me.getAttribute('data-pt')) || '';
  function pt(p) {
    var u = pageType(p);
    if (dlePt === 'fullstory') return 'fullstory';
    if (u === 'other' && dlePt) return (dlePt === 'home' && p !== '/') ? 'catalog' : dlePt;
    return u;
  }

  // 3. device + network
  var dev = (matchMedia('(pointer:coarse)').matches || innerWidth < 768) ? 'mobile' : 'desktop';
  var net = (navigator.connection && navigator.connection.effectiveType) || '';

  var CLIP = 120;
  function clip(x) { return (x || '').toString().slice(0, CLIP); }

  var metrics = [];
  function push(n, m, attr, x) {
    var o = { n: n, v: Math.round(m.value * (n === 'CLS' ? 1000 : 1)) / (n === 'CLS' ? 1000 : 1), r: m.rating, a: clip(attr) };
    if (x) o.x = x;
    metrics.push(o);
  }
  function ms(v) { return typeof v === 'number' ? Math.round(v) : -1; }
  // Скрипт из LoAF коротко: хост+хвост пути без query; инлайн (sourceURL = сама страница или пусто) -> 'inline'.
  function scriptName(s) {
    var u = (s.sourceURL || '').split('?')[0].split('#')[0];
    if (!u || u === location.href.split('?')[0].split('#')[0]) u = 'inline';
    else u = u.replace(/^https?:\/\//, '').replace(location.host, '');
    if (u.length > 60) u = u.slice(0, 20) + '…' + u.slice(-39);
    return u + (s.sourceFunctionName ? ' ' + s.sourceFunctionName.slice(0, 30) : '') + ' [' + (s.invokerType || '') + ']';
  }

  // 4. Подписки после загрузки web-vitals
  var sc = document.createElement('script');
  sc.src = me ? me.src.replace('rum.js', 'web-vitals.attribution.iife.js').split('?')[0] + '?v=1' : '/templates/Default/js/web-vitals.attribution.iife.js?v=1';
  sc.onload = function () {
    var wv = window.webVitals; if (!wv) return;
    wv.onLCP(function (m) { var a = m.attribution || {}; push('LCP', m, (a.element || '') + '|' + (a.url || '')); });
    wv.onINP(function (m) {
      var a = m.attribution || {};
      var loaf = a.longAnimationFrameEntries || [];
      var worst = null;
      for (var i = 0; i < loaf.length; i++) {
        var scripts = loaf[i] && loaf[i].scripts;
        if (!scripts) continue;
        for (var j = 0; j < scripts.length; j++) {
          var sc2 = scripts[j];
          if (sc2 && typeof sc2.duration === 'number' && (!worst || sc2.duration > worst.duration)) worst = sc2;
        }
      }
      // sv6: фазы INP (ожидание / обработчики / отрисовка) и самый долгий скрипт кадра — чей код держит поток
      push('INP', m, a.interactionTarget || '', {
        it: a.interactionType || '', ls: a.loadState || '',
        id: ms(a.inputDelay), pd: ms(a.processingDuration), ps: ms(a.presentationDelay),
        s: worst ? scriptName(worst) : '', sd: worst ? ms(worst.duration) : -1
      });
    });
    wv.onCLS(function (m) { var a = m.attribution || {}; push('CLS', m, a.largestShiftTarget || '', { t: ms(a.largestShiftTime), ls: a.loadState || '' }); });
    // sv7: из чего сложилось ожидание — фазы браузера + Server-Timing звеньев (px = прокси, up = ожидание origin прокси, ce/co = Cloudflare на Pro).
    wv.onTTFB(function (m) {
      var a = m.attribution || {}, ne = a.navigationEntry || {}, st = ne.serverTiming || [];
      var x = { wd: ms(a.waitingDuration), ch: ms(a.cacheDuration), dn: ms(a.dnsDuration), cn: ms(a.connectionDuration), rq: ms(a.requestDuration), pr: clip(ne.nextHopProtocol).slice(0, 8) };
      for (var i = 0; i < st.length; i++) {
        if (st[i].name === 'px') { x.px = ms(st[i].duration); x.pc = clip(st[i].description).slice(0, 12); }
        else if (st[i].name === 'up') x.up = ms(st[i].duration);
        else if (st[i].name === 'cfEdge') x.ce = ms(st[i].duration); // CF сам (только платный тариф зоны)
        else if (st[i].name === 'cfOrigin') x.co = ms(st[i].duration); // CF ждал прокси/origin
      }
      push('TTFB', m, '', x);
    });
    wv.onFCP(function (m) { push('FCP', m, ''); });

    // 5. Регистрация после подписок web-vitals: их visibilitychange/pagehide
    // должны сработать раньше нашего flush, иначе INP/CLS финализируются поздно.
    addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });
    addEventListener('pagehide', flush);
  };
  document.head.appendChild(sc);

  // 5. Отправка beacon по официальному паттерну web-vitals: без latch,
  // очищаем накопленное после отправки, разрешаем повторный flush
  // (onCLS/onINP финализируются на visibilitychange:hidden — латч терял их при tab-switch).
  function flush() {
    if (!metrics.length) return;
    var payload = { sv: 7, pt: pt(location.pathname), p: clip(location.pathname), dev: dev, net: net, m: metrics.slice() };
    try { navigator.sendBeacon('/rum-beacon?d=' + encodeURIComponent(JSON.stringify(payload))); } catch (e) {}
    metrics.length = 0;
  }
})();
